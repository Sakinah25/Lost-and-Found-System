<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Items Model
 *
 * @property \App\Model\Table\UsersTable&\Cake\ORM\Association\BelongsTo $Users
 *
 * @method \App\Model\Entity\Item newEmptyEntity()
 * @method \App\Model\Entity\Item newEntity(array $data, array $options = [])
 * @method array<\App\Model\Entity\Item> newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Item get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \App\Model\Entity\Item findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \App\Model\Entity\Item patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\App\Model\Entity\Item> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Item|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \App\Model\Entity\Item saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\App\Model\Entity\Item>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Item>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Item>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Item> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Item>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Item>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Item>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Item> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ItemsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('items');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER',
        ]);
		$this->addBehavior('AuditStash.AuditLog');
		$this->addBehavior('Search.Search');
		$this->searchManager()
			->value('id')
				->add('search', 'Search.Like', [
					//'before' => true,
					//'after' => true,
					'fieldMode' => 'OR',
					'multiValue' => true,
					'multiValueSeparator' => '|',
					'comparison' => 'LIKE',
					'wildcardAny' => '*',
					'wildcardOne' => '?',
					'fields' => ['id'],
				]);

                $this->addBehavior('Josegonzalez/Upload.Upload', [
            'image' => [
                'fields' => [
                    'dir' => 'image_dir', // defaults to `dir`
                    //'size' => 'photo_size', // defaults to `size`
                    //'type' => 'photo_type', // defaults to `type`
                ],
                //'path' => 'webroot{DS}files{DS}{model}{DS}{field}{DS}{field-value:slug}',
            ],
        ]);

    }
    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        // $validator
        //     ->integer('user_id')
        //     ->notEmptyString('user_id');

        // $validator
        //     ->scalar('name')
        //     ->maxLength('name', 255)
        //     ->requirePresence('name', 'create')
        //     ->notEmptyString('name');

        // $validator
        //     ->scalar('item_category')
        //     ->maxLength('item_category', 255)
        //     ->requirePresence('item_category', 'create')
        //     ->notEmptyString('item_category');

        // $validator
        //     ->scalar('status')
        //     ->maxLength('status', 255)
        //     ->notEmptyString('status');

        // $validator
        //     ->scalar('image')
        //     ->maxLength('image', 255)
        //     ->requirePresence('image', 'create')
        //     ->notEmptyFile('image');

        // $validator
        //     ->scalar('image_dir')
        //     ->maxLength('image_dir', 255)
        //     ->requirePresence('image_dir', 'create')
        //     ->notEmptyString('image_dir');

        // $validator
        //     ->scalar('brand')
        //     ->maxLength('brand', 255)
        //     ->requirePresence('brand', 'create')
        //     ->notEmptyString('brand');

        // $validator
        //     ->scalar('color')
        //     ->maxLength('color', 255)
        //     ->requirePresence('color', 'create')
        //     ->notEmptyString('color');

        // $validator
        //     ->scalar('lost_found_category')
        //     ->maxLength('lost_found_category', 255)
        //     ->requirePresence('lost_found_category', 'create')
        //     ->notEmptyString('lost_found_category');

        // $validator
        //     ->date('lost_found_date')
        //     ->requirePresence('lost_found_date', 'create')
        //     ->notEmptyDate('lost_found_date');

        // $validator
        //     ->scalar('description')
        //     ->requirePresence('description', 'create')
        //     ->notEmptyString('description');

        // $validator
        //     ->scalar('location')
        //     ->maxLength('location', 255)
        //     ->requirePresence('location', 'create')
        //     ->notEmptyString('location');

        // $validator
        //     ->scalar('unique_mark')
        //     ->maxLength('unique_mark', 255)
        //     ->requirePresence('unique_mark', 'create')
        //     ->notEmptyString('unique_mark');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'), ['errorField' => 'user_id']);

        return $rules;
    }
}
