<?php
declare(strict_types=1);

namespace App\Controller;

class ContactsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();

        $this->loadComponent('Search.Search', [
            'actions' => ['search', 'check', 'index'],
        ]);
    }

    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);

        // Allow public access to contact pages
        $this->Authentication->allowUnauthenticated(['index', 'add', 'check']);
    }

    // Make /contacts go to the form page (index)
    public function index()
    {
        $this->set('title', 'Lost & Found Mall – Contact');

        $contact = $this->Contacts->newEmptyEntity();

        if ($this->request->is('post')) {
            $data = $this->request->getData();

            // Auto fields (follow your DB columns)
            $data['ip'] = $this->request->clientIp();
            $data['ticket'] = 'LFS-' . date('YmdHis') . '-' . rand(100, 999);
            $data['status'] = 1;       // your old code uses 1
            $data['is_replied'] = 0;

            // Logged-in user (optional)
            $identity = $this->request->getAttribute('identity');
            if ($identity) {
                $data['user_id'] = $identity->id;
            }

            $contact = $this->Contacts->patchEntity($contact, $data);

            if ($this->Contacts->save($contact)) {
                $this->Flash->success(__('Your Lost & Found inquiry has been submitted.'));
                return $this->redirect(['action' => 'check', '?' => ['ticket' => $data['ticket']]]);
            }

            $this->Flash->error(__('The inquiry could not be submitted. Please try again.'));
        }

        $categories = [
            'Lost Item' => 'Lost Item',
            'Found Item' => 'Found Item',
            'General Inquiry' => 'General Inquiry',
        ];

        // If you want the form in templates/Contacts/index.php, use this:
        $this->set(compact('contact', 'categories'));
        $this->render('index');
    }

    // Optional: keep /contacts/add working too (just redirect to index)
    public function add()
    {
        return $this->redirect(['action' => 'index']);
    }

    public function check()
    {
        $this->set('title', 'Contact Ticket Response Check');

        $query = $this->Contacts->find('search', search: $this->request->getQueryParams());
        $contacts = $this->paginate($query);

        $ticket = $this->request->getQuery('ticket');
        if ($ticket !== null && $ticket !== '') {
            $this->set('count_ticket', $this->Contacts->find()->where(['ticket' => $ticket])->count());
        } else {
            $this->set('count_ticket', '0');
        }

        $this->set(compact('contacts'));
        $this->set('_serialize', ['contacts']);
    }
}