<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\Http\Response;
use Cake\View\Exception\MissingTemplateException;

class PagesController extends AppController
{
    /**
     * Static pages (/pages/*)
     * Example: /pages/home -> templates/Pages/home.php
     */
    public function display(string ...$path): ?Response
    {
        if (!$path) {
            return $this->redirect('/');
        }

        if (in_array('..', $path, true) || in_array('.', $path, true)) {
            throw new ForbiddenException();
        }

        $page = $subpage = null;

        if (!empty($path[0])) {
            $page = $path[0];
        }
        if (!empty($path[1])) {
            $subpage = $path[1];
        }

        $this->set(compact('page', 'subpage'));

        try {
            return $this->render(implode('/', $path));
        } catch (MissingTemplateException $e) {
            if (Configure::read('debug')) {
                throw $e;
            }
            throw new NotFoundException();
        }
    }

    /**
     * FAQ Page
     * URL: /pages/faqs (we will route it in config/routes.php)
     */
    public function faq(): ?Response
    {
        $this->set('title', 'Frequently Asked Questions');

        $Items = $this->fetchTable('Items');

        $lostCount = $Items->find()
            ->where(['lost_found_category' => 'lost'])
            ->count();

        $foundCount = $Items->find()
            ->where(['lost_found_category' => 'found'])
            ->count();

        $claimedCount = $Items->find()
            ->where(['status' => 'claimed'])
            ->count();

        $this->set(compact('lostCount', 'foundCount', 'claimedCount'));

        // This will render templates/Pages/faq.php
        return null;
    }
}
