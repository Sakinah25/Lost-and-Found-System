<?php
declare(strict_types=1);

namespace App\Controller;

class FaqsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();
        // REMOVE Search component if not used
        // $this->loadComponent('Search.Search');
    }

    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);
        $this->Authentication->allowUnauthenticated(['index']);
    }

    public function index()
    {
        $this->set('title', 'Frequently Asked Questions');

        $faqs = $this->fetchTable('Faqs')->find()
            ->where(['status' => 1])
            ->orderBy(['category' => 'ASC', 'id' => 'ASC'])
            ->all()
            ->toList();

        // Normalize categories
        foreach ($faqs as $faq) {
            $cat = strtolower(trim((string)$faq->category));

            if ($cat === 'other') $cat = 'general';

            $allowed = ['general', 'reporting', 'claiming', 'account'];
            if (!in_array($cat, $allowed)) $cat = 'general';

            $faq->category = $cat;
        }

        $this->set(compact('faqs'));
    }
}
