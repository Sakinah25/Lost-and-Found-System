<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\I18n\FrozenTime;

class DashboardsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();
    }

    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);
        // $this->Authentication->allowUnauthenticated(['index']);
    }

    public function index()
    {
        $this->set('title', 'Dashboard');

        // Auth user
        $identity = $this->request->getAttribute('identity');
        if (!$identity) {
            $this->Flash->error(__('Please log in to access the dashboard.'));
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }

        // Tables
        $itemsTable     = $this->fetchTable('Items');
        $usersTable     = $this->fetchTable('Users');
        $contactsTable  = $this->fetchTable('Contacts');
        $auditLogsTable = $this->fetchTable('AuditLogs');

        // =========================
        // USERS
        // =========================
        $totalUser  = $usersTable->find()->count();
        $activeUser = $usersTable->find()->where(['status' => 1])->count();
        $userPercent = $totalUser > 0 ? round(($activeUser * 100) / $totalUser, 2) : 0;

        // =========================
        // CONTACTS
        // =========================
        $totalContact = $contactsTable->find()->count();
        $pendingContact = $contactsTable->find()->where(['status' => 0])->count();
        $pendingContactPercent = $totalContact > 0 ? round(($pendingContact * 100) / $totalContact, 2) : 0;

        // =========================
        // AUDIT LOGS
        // =========================
        $totalAuditlog = $auditLogsTable->find()->count();

        // =========================
        // ITEMS COUNTS (MATCH YOUR DB)
        // lost_found_category values in DB = 'lost' / 'found'
        // status values (based on your table screenshots) = 'pending', 'approved', 'retrieved' (etc)
        // =========================
        $totalItems = $itemsTable->find()->count();

        // ✅ Lost total (all lost)
        $totalLostItems = $itemsTable->find()
            ->where(['lost_found_category' => 'lost'])
            ->count();

        // ✅ Found total (all found)
        $totalFoundItems = $itemsTable->find()
            ->where(['lost_found_category' => 'found'])
            ->count();

        // ✅ Returned/Retrieved (adjust to your real returned status)
        // In your table screenshot you used "retrieved"
        $totalReturnedItems = $itemsTable->find()
            ->where(['status' => 'retrieved'])
            ->count();

        $lostItemsPercent = $totalItems > 0 ? round(($totalLostItems * 100) / $totalItems, 2) : 0;
        $foundItemsPercent = $totalItems > 0 ? round(($totalFoundItems * 100) / $totalItems, 2) : 0;
        $returnedPercent = $totalItems > 0 ? round(($totalReturnedItems * 100) / $totalItems, 2) : 0;

        // =========================
        // RECENT ITEMS
        // =========================
        $recentLostItems = $itemsTable->find()
            ->where(['lost_found_category' => 'lost'])
            ->orderBy(['created' => 'DESC'])
            ->limit(5)
            ->all();

        $recentFoundItems = $itemsTable->find()
            ->where(['lost_found_category' => 'found'])
            ->orderBy(['created' => 'DESC'])
            ->limit(5)
            ->all();

        // =========================
        // CHART 1: Items by item_category
        // =========================
        $qCat = $itemsTable->find();
        $categoryData = $qCat
            ->select([
                'category' => 'item_category',
                'count' => $qCat->func()->count('*')
            ])
            ->groupBy(['item_category'])
            ->orderBy(['count' => 'DESC'])
            ->enableHydration(false)
            ->toArray();

        // =========================
        // CHART 2: Lost vs Found trends (last 6 months)
        // =========================
        $months = [];
        $lostByMonth = [];
        $foundByMonth = [];

        $now = FrozenTime::now();

        for ($i = 5; $i >= 0; $i--) {
            $m = $now->subMonths($i);
            $months[] = $m->format('M Y');
            $key = $m->format('Y-m');
            $lostByMonth[$key] = 0;
            $foundByMonth[$key] = 0;
        }

        $fromDate = $now->subMonths(6)->format('Y-m-01 00:00:00');

        // Lost rows
        $qLost = $itemsTable->find();
        $lostRows = $qLost
            ->select([
                'ym' => $qLost->func()->date_format(['created' => 'identifier', '%Y-%m']),
                'count' => $qLost->func()->count('*')
            ])
            ->where(['lost_found_category' => 'lost', 'created >=' => $fromDate])
            ->groupBy(['ym'])
            ->enableHydration(false)
            ->toArray();

        foreach ($lostRows as $r) {
            if (isset($lostByMonth[$r['ym']])) {
                $lostByMonth[$r['ym']] = (int)$r['count'];
            }
        }

        // Found rows
        $qFound = $itemsTable->find();
        $foundRows = $qFound
            ->select([
                'ym' => $qFound->func()->date_format(['created' => 'identifier', '%Y-%m']),
                'count' => $qFound->func()->count('*')
            ])
            ->where(['lost_found_category' => 'found', 'created >=' => $fromDate])
            ->groupBy(['ym'])
            ->enableHydration(false)
            ->toArray();

        foreach ($foundRows as $r) {
            if (isset($foundByMonth[$r['ym']])) {
                $foundByMonth[$r['ym']] = (int)$r['count'];
            }
        }

        // Send to view
        $this->set(compact(
            'totalUser',
            'activeUser',
            'userPercent',
            'totalContact',
            'pendingContact',
            'pendingContactPercent',
            'totalAuditlog',

            'totalItems',
            'totalLostItems',
            'totalFoundItems',
            'totalReturnedItems',
            'lostItemsPercent',
            'foundItemsPercent',
            'returnedPercent',

            'recentLostItems',
            'recentFoundItems',

            'categoryData',
            'months',
            'lostByMonth',
            'foundByMonth'
        ));
    }
}
