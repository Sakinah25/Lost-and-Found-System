<?php
declare(strict_types=1);

namespace App\Controller;

use AuditStash\Meta\RequestMetadata;
use Cake\Event\EventManager;
use Cake\Routing\Router;
use Cake\Event\EventInterface;

/**
 * Items Controller
 *
 * @property \App\Model\Table\ItemsTable $Items
 */
class ItemsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();

        $this->loadComponent('Search.Search', [
            'actions' => ['index'],
        ]);
    }

    public function beforeFilter(EventInterface $event)
    {
        parent::beforeFilter($event);
    }

    public function json()
    {
        $this->viewBuilder()->setLayout('json');
        $this->set('items', $this->paginate());
        $this->viewBuilder()->setOption('serialize', 'items');
    }

    public function csv()
    {
        $this->response = $this->response->withDownload('items.csv');
        $items = $this->Items->find();
        $_serialize = 'items';

        $this->viewBuilder()->setClassName('CsvView.Csv');
        $this->set(compact('items', '_serialize'));
    }

    public function pdfList()
    {
        $this->viewBuilder()->enableAutoLayout(false);

        $type = strtolower((string)$this->request->getQuery('type', ''));
        $where = [];
        if ($type === 'lost') {
            $where = ['lost_found_category' => 'lost'];
        } elseif ($type === 'found') {
            $where = ['lost_found_category' => 'found'];
        }


        $query = $this->Items->find()
            ->contain(['Users'])
            ->where($where);

        $this->paginate = [
            'maxLimit' => 10,
        ];

        $items = $this->paginate($query);

        $this->viewBuilder()->setClassName('CakePdf.Pdf');
        $this->viewBuilder()->setOption('pdfConfig', [
            'orientation' => 'portrait',
            'download' => true,
            'filename' => ($type ? $type . '_items.pdf' : 'items_List.pdf'),
        ]);

        $title = ($type === 'found') ? 'Found Items List' : (($type === 'lost') ? 'Lost Items List' : 'Items List');
        $this->set(compact('items', 'type', 'title'));
        return $this->render('pdf_list');
    }

    public function exportPdf()
    {
        return $this->pdfList();
    }


    public function lostLetter($id = null)
    {
        $this->request->allowMethod(['get']);

        $item = $this->Items->get($id, [
            'contain' => ['Users'],
        ]);

        if (strtolower((string)$item->lost_found_category) !== 'lost') {
            $this->Flash->error('This item is not marked as Lost.');
            return $this->redirect(['action' => 'index', '?' => ['type' => 'found']]);
        }

        $this->viewBuilder()->enableAutoLayout(false);
        $this->viewBuilder()->setClassName('CakePdf.Pdf');

        $this->viewBuilder()->setOption('pdfConfig', [
            'orientation' => 'portrait',
            'download' => true,
            'filename' => 'lost_item_' . $item->id . '.pdf'
        ]);

        $title = 'Lost Item Report Letter';
        $this->set(compact('item', 'title'));
        return $this->render('lost_letter');
    }


    public function foundLetter($id = null)
    {
        $this->request->allowMethod(['get']);

        $item = $this->Items->get($id, [
            'contain' => ['Users'],
        ]);

        if (strtolower((string)$item->lost_found_category) !== 'found') {
            $this->Flash->error('This item is not marked as Found yet.');
            return $this->redirect(['action' => 'index', '?' => ['type' => 'lost']]);
        }

        $this->viewBuilder()->enableAutoLayout(false);
        $this->viewBuilder()->setClassName('CakePdf.Pdf');

        $this->viewBuilder()->setOption('pdfConfig', [
            'orientation' => 'portrait',
            'download' => true,
            'filename' => 'found_item_' . $item->id . '.pdf'
        ]);

        $title = 'Found Item Confirmation Letter';
        $this->set(compact('item', 'title'));
        return $this->render('found_letter');
    }

    public function index()
    {
        $this->set('title', 'Items List');
        $type = strtolower((string)$this->request->getQuery('type', 'lost'));
        if (!in_array($type, ['lost', 'found'], true)) {
            $type = 'lost';
        }
        $this->set(compact('type'));

        $this->paginate = [
            'maxLimit' => 10,
        ];

        $query = $this->Items->find('search', search: $this->request->getQueryParams())
            ->contain(['Users']);
        if ($type === 'lost') {
            $query->where(['lost_found_category' => 'lost']);
        } else {
            $query->where(['lost_found_category' => 'found']);
        }

        $items = $this->paginate($query);

        //count
        $this->set('total_items', $this->Items->find()->count());
        $this->set('total_items_archived', $this->Items->find()->where(['status' => 2])->count());
        $this->set('total_items_active', $this->Items->find()->where(['status' => 1])->count());
        $this->set('total_items_disabled', $this->Items->find()->where(['status' => 0])->count());

        //Count By Month
        $this->set('january', $this->Items->find()->where(['MONTH(created)' => date('1'), 'YEAR(created)' => date('Y')])->count());
        $this->set('february', $this->Items->find()->where(['MONTH(created)' => date('2'), 'YEAR(created)' => date('Y')])->count());
        $this->set('march', $this->Items->find()->where(['MONTH(created)' => date('3'), 'YEAR(created)' => date('Y')])->count());
        $this->set('april', $this->Items->find()->where(['MONTH(created)' => date('4'), 'YEAR(created)' => date('Y')])->count());
        $this->set('may', $this->Items->find()->where(['MONTH(created)' => date('5'), 'YEAR(created)' => date('Y')])->count());
        $this->set('jun', $this->Items->find()->where(['MONTH(created)' => date('6'), 'YEAR(created)' => date('Y')])->count());
        $this->set('july', $this->Items->find()->where(['MONTH(created)' => date('7'), 'YEAR(created)' => date('Y')])->count());
        $this->set('august', $this->Items->find()->where(['MONTH(created)' => date('8'), 'YEAR(created)' => date('Y')])->count());
        $this->set('september', $this->Items->find()->where(['MONTH(created)' => date('9'), 'YEAR(created)' => date('Y')])->count());
        $this->set('october', $this->Items->find()->where(['MONTH(created)' => date('10'), 'YEAR(created)' => date('Y')])->count());
        $this->set('november', $this->Items->find()->where(['MONTH(created)' => date('11'), 'YEAR(created)' => date('Y')])->count());
        $this->set('december', $this->Items->find()->where(['MONTH(created)' => date('12'), 'YEAR(created)' => date('Y')])->count());

        $query2 = $this->Items->find();

        $expectedMonths = [];
        for ($i = 11; $i >= 0; $i--) {
            $expectedMonths[] = date('M-Y', strtotime("-$i months"));
        }

        $query2->select([
            'count' => $query2->func()->count('*'),
            'date' => $query2->func()->date_format(['created' => 'identifier', "%b-%Y"]),
            'month' => 'MONTH(created)',
            'year' => 'YEAR(created)'
        ])
            ->where([
                'created >=' => date('Y-m-01', strtotime('-11 months')),
                'created <=' => date('Y-m-t')
            ])
            ->groupBy(['year', 'month'])
            ->orderBy(['year' => 'ASC', 'month' => 'ASC']);

        $results = $query2->all()->toArray();

        $totalByMonth = [];
        foreach ($expectedMonths as $expectedMonth) {
            $count = 0;
            foreach ($results as $result) {
                if ($expectedMonth === $result->date) {
                    $count = $result->count;
                    break;
                }
            }
            $totalByMonth[] = [
                'month' => $expectedMonth,
                'count' => $count
            ];
        }

        $this->set([
            'results' => $totalByMonth,
            '_serialize' => ['results']
        ]);

        $totalByMonthJson = json_encode($totalByMonth);
        $dataArray = json_decode($totalByMonthJson, true);
        $monthArray = [];
        $countArray = [];
        foreach ($dataArray as $data) {
            $monthArray[] = $data['month'];
            $countArray[] = $data['count'];
        }

        $this->set(compact('items', 'monthArray', 'countArray'));
    }

    public function lostItems()
    {
        $this->set('title', 'Lost Items');

        $this->paginate = [
            'maxLimit' => 10,
        ];

        $query = $this->Items->find()
            ->contain(['Users'])
            ->where(['lost_found_category' => 'lost']);

        $items = $this->paginate($query);

        $this->set(compact('items'));
        return $this->render('index');
    }

    public function foundItems()
    {
        $this->set('title', 'Found Items');

        $this->paginate = [
            'maxLimit' => 10,
        ];

        $query = $this->Items->find()
            ->contain(['Users'])
            ->where(['lost_found_category' => 'found']);

        $items = $this->paginate($query);

        $this->set(compact('items'));
        return $this->render('index');
    }


    public function view($id = null)
    {
        $this->set('title', 'Items Details');
        $item = $this->Items->get($id, contain: ['Users']);
        $this->set(compact('item'));
    }

    public function add()
    {
        $this->set('title', 'New Items');

        $type = strtolower((string)$this->request->getQuery('type', 'lost'));
        if (!in_array($type, ['lost', 'found'], true)) {
            $type = 'lost';
        }

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Add']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Items']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $item = $this->Items->newEmptyEntity();

        if ($this->request->is('post')) {
            $data = $this->request->getData();

            if (empty($data['lost_found_category'])) {
                $data['lost_found_category'] = $type;
            }

            $item = $this->Items->patchEntity($item, $data);

            if ($this->Items->save($item)) {
                $this->Flash->success(__('The item has been saved.'));
                return $this->redirect(['action' => 'index', '?' => ['type' => $type]]);
            }

            $this->Flash->error(__('The item could not be saved. Please, try again.'));
        }

        $users = $this->Items->Users->find('list', ['limit' => 200])->all();
        $this->set(compact('item', 'users', 'type'));
    }

    public function edit($id = null)
    {
        $this->set('title', 'Items Edit');

        $type = strtolower((string)$this->request->getQuery('type', 'lost'));
        if (!in_array($type, ['lost', 'found'], true)) {
            $type = 'lost';
        }

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Edit']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Items']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $item = $this->Items->get($id, [
            'contain' => [],
        ]);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $item = $this->Items->patchEntity($item, $this->request->getData());

            if ($this->Items->save($item)) {
                $this->Flash->success(__('The item has been saved.'));
                return $this->redirect(['action' => 'index', '?' => ['type' => $type]]);
            }

            $this->Flash->error(__('The item could not be saved. Please, try again.'));
        }

        $users = $this->Items->Users->find('list', limit: 200)->all();
        $this->set(compact('item', 'users', 'type'));
    }

    public function delete($id = null)
    {
        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Delete']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Items']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $this->request->allowMethod(['post', 'delete']);
        $item = $this->Items->get($id);

        if ($this->Items->delete($item)) {
            $this->Flash->success(__('The item has been deleted.'));
        } else {
            $this->Flash->error(__('The item could not be deleted. Please, try again.'));
        }

        return $this->redirect($this->referer());
    }

    public function archived($id = null)
    {
        $this->set('title', 'Items Edit');

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Archived']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Items']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $item = $this->Items->get($id, [
            'contain' => [],
        ]);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $item = $this->Items->patchEntity($item, $this->request->getData());
            $item->status = 2;

            if ($this->Items->save($item)) {
                $this->Flash->success(__('The item has been archived.'));
                return $this->redirect($this->referer());
            }

            $this->Flash->error(__('The item could not be archived. Please, try again.'));
        }

        $this->set(compact('item'));
    }
}
