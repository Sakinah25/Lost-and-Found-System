<?php
declare(strict_types=1);

namespace App\Controller;

class UsersController extends AppController
{
    public function login()
    {
        echo "UsersController login OK";
        exit;
    }

    public function adminLogin()
    {
        echo "UsersController adminLogin OK";
        exit;
    }

    public function logout()
    {
        echo "UsersController logout OK";
        exit;
    }
}
