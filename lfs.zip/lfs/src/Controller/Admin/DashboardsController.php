<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

class DashboardsController extends AppController
{
    public function index()
    {
        // Your code
    }
}