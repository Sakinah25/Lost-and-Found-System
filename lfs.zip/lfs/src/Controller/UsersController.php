<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Event\EventInterface;

class UsersController extends AppController
{
    public function beforeFilter(EventInterface $event)
    {
        parent::beforeFilter($event);

        $this->Authentication->addUnauthenticatedActions([
            'login',
            'adminLogin',
            'logout',
            'register',
        ]);
    }

    public function login()
    {
        $this->set('title', 'User Login');
        $this->viewBuilder()->disableAutoLayout();

        $result = $this->Authentication->getResult();

        // Already logged in
        if (!$this->request->is('post') && $result && $result->isValid()) {
            return $this->redirect(['controller' => 'Dashboards', 'action' => 'index']);
        }

        if ($this->request->is('post')) {
            $result = $this->Authentication->getResult();

            if ($result && $result->isValid()) {
                $redirect = $this->request->getQuery('redirect', [
                    'controller' => 'Dashboards',
                    'action' => 'index',
                ]);

                return $this->redirect($redirect);
            }

            $this->Flash->error('Invalid email or password.');
        }
    }

    public function adminLogin()
    {
        $this->set('title', 'Admin Login');
        $this->viewBuilder()->disableAutoLayout();

        // If you use the SAME combined login page template:
        // $this->viewBuilder()->setTemplate('login');

        $result = $this->Authentication->getResult();

        // Already logged in
        if (!$this->request->is('post') && $result && $result->isValid()) {
            return $this->redirect(['controller' => 'Dashboards', 'action' => 'index']);
        }

        if ($this->request->is('post')) {
            $result = $this->Authentication->getResult();

            if ($result && $result->isValid()) {
                $identity = $this->request->getAttribute('identity');

                // Admin-only check (user_group_id = 1)
                if ($identity && (int)($identity->user_group_id ?? 0) === 1) {
                    $this->Flash->success('Welcome, Admin!');
                    return $this->redirect(['controller' => 'Dashboards', 'action' => 'index']);
                }

                // Not admin → logout and block
                $this->Authentication->logout();
                $this->Flash->error('Admin access only.');
                return $this->redirect(['action' => 'login']);
            }

            $this->Flash->error('Invalid admin email or password.');
        }
    }

    public function logout()
    {
        $this->Authentication->logout();
        return $this->redirect(['action' => 'login']);
    }

    public function register()
    {
        $this->set('title', 'User Registration');
        $this->viewBuilder()->disableAutoLayout();

        $this->Users = $this->fetchTable('Users');
        $user = $this->Users->newEmptyEntity();

        if ($this->request->is('post')) {
            $data = $this->request->getData();

            $password = $data['password'] ?? '';
            $confirm  = $data['confirm_password'] ?? '';

            if ($password === '' || $password !== $confirm) {
                $this->Flash->error('Password and Confirm Password do not match.');
                $this->set(compact('user'));
                return;
            }

            if (empty($data['terms'])) {
                $this->Flash->error('Please agree to the registration terms & conditions.');
                $this->set(compact('user'));
                return;
            }

            unset($data['confirm_password'], $data['terms']);

            // defaults
            $data['status'] = 1;          // you use status as varchar(1)
            $data['user_group_id'] = 2;   // normal user

            $user = $this->Users->patchEntity($user, $data);

            if ($this->Users->save($user)) {
                $this->Flash->success('Registration successful! Please login.');
                return $this->redirect(['action' => 'login']);
            }

            $this->Flash->error('Registration failed. Please check your details.');
        }

        $this->set(compact('user'));
    }

    public function profile()
{
    $this->set('title', 'My Profile');

    // if you use custom layout, keep it
    // $this->viewBuilder()->disableAutoLayout(); // <- DON’T disable if you want sidebar/layout

    $identity = $this->request->getAttribute('identity');

    if (!$identity) {
        $this->Flash->error('Please login to view your profile.');
        return $this->redirect(['action' => 'login']);
    }

    $this->Users = $this->fetchTable('Users');

    // Get logged-in user from DB (latest data)
    $user = $this->Users->get($identity->id);

    // Update profile
    if ($this->request->is(['patch', 'post', 'put'])) {
        $data = $this->request->getData();

        // optional: prevent user changing role/status
        unset($data['user_group_id'], $data['status']);

        $user = $this->Users->patchEntity($user, $data);

        if ($this->Users->save($user)) {
            $this->Flash->success('Profile updated successfully.');
            return $this->redirect(['action' => 'profile']);
        }

        $this->Flash->error('Profile update failed. Please check your input.');
    }

    $this->set(compact('user'));
    
}

}