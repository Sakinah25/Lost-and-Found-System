<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

class AdminController extends AppController
{
    /**
     * Dashboard/index method for /admin route
     * 
     * This will be the default admin landing page
     */
    public function index()
    {
        // You can set variables to pass to the view here
        // $this->set('title', 'Admin Dashboard');
        
        // Example: load some admin stats and pass to view
        // $this->set('userCount', $this->Users->find()->count());
    }
}