<?php
declare(strict_types=1);

use Cake\Routing\Route\DashedRoute;
use Cake\Routing\RouteBuilder;

return static function (RouteBuilder $routes): void {

    // Use dashed URLs by default
    $routes->setRouteClass(DashedRoute::class);

    /**
     * PUBLIC ROUTES
     */
    $routes->scope('/', function (RouteBuilder $builder): void {

        // Your dashboard home
        $builder->connect('/', [
            'controller' => 'Dashboards',
            'action' => 'index'
        ]);

        // Auth routes
        $builder->connect('/login', [
            'controller' => 'Users',
            'action' => 'login'
        ]);

        $builder->connect('/register', [
            'controller' => 'Users',
            'action' => 'register'
        ]);

        $builder->connect('/admin-login', [
            'controller' => 'Users',
            'action' => 'adminLogin'
        ]);

        $builder->connect('/logout', [
            'controller' => 'Users',
            'action' => 'logout'
        ]);

        /**
         * ✅ FAQS PAGE ROUTES
         * Use PagesController::display('faqs') with templates/Pages/faqs.php
         */
        $builder->connect('/pages/faqs', [
            'controller' => 'Pages',
            'action' => 'display',
            'faqs'
        ]);

        // Optional shorter alias: /faqs
        $builder->connect('/faqs', [
            'controller' => 'Pages',
            'action' => 'display',
            'faqs'
        ]);

        $builder->connect('/pages/faqs', ['controller' => 'Pages', 'action' => 'faq']);
$builder->connect('/faqs', ['controller' => 'Pages', 'action' => 'faq']); // optional

$builder->connect('/pages/faqs', ['controller' => 'Pages', 'action' => 'faq']);



        // Cake fallback routes
        $builder->fallbacks(DashedRoute::class);
    });

    /**
     * ADMIN PREFIX ROUTES
     */
    $routes->prefix('Admin', function (RouteBuilder $builder): void {

        $builder->connect('/settings/*', [
            'controller' => 'Settings',
            'action' => 'update'
        ]);

        $builder->connect('/users/*', [
            'controller' => 'Users',
            'action' => 'index'
        ]);

        $builder->fallbacks(DashedRoute::class);
    });

};
