<script src="https://js.hcaptcha.com/1/api.js" async defer></script>

<div class="container-fluid py-4">
    <div class="content-card" style="max-width:800px;margin:auto;">

        <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
                <h4 class="fw-bold mb-1">Contact Lost & Found (Mall)</h4>
                <p class="text-muted mb-0">
                    Please fill in the form below. Our mall Lost & Found team will contact you.
                </p>
            </div>

            <?= $this->Html->link(
                'Check Response',
                ['action' => 'check'],
                ['class' => 'btn btn-outline-primary btn-sm']
            ) ?>
        </div>

        <hr class="mb-4">

        <?= $this->Form->create($contact) ?>

        <?php
            $ticket = 'LFS-' . date('YmdHis');
            echo $this->Form->hidden('ticket', ['value' => $ticket]);
        ?>

        <div class="row g-3">
            <div class="col-md-6">
                <?= $this->Form->control('name', [
                    'label' => 'Full Name',
                    'class' => 'form-control',
                    'required' => true
                ]) ?>
            </div>

            <div class="col-md-6">
                <?= $this->Form->control('email', [
                    'label' => 'Email Address',
                    'class' => 'form-control',
                    'required' => true
                ]) ?>
            </div>

            <div class="col-12">
                <?= $this->Form->control('category', [
                    'type' => 'select',
                    'options' => $categories ?? [
                        'Lost Item' => 'Lost Item',
                        'Found Item' => 'Found Item',
                        'Claim Item' => 'Claim Item',
                        'General Inquiry' => 'General Inquiry',
                    ],
                    'empty' => '-- Select Inquiry Type --',
                    'class' => 'form-control',
                    'required' => true
                ]) ?>
            </div>

            <div class="col-12">
                <?= $this->Form->control('subject', [
                    'label' => 'Subject',
                    'class' => 'form-control',
                    'required' => false
                ]) ?>
            </div>

            <div class="col-12">
                <?= $this->Form->control('notes', [
                    'type' => 'textarea',
                    'rows' => 5,
                    'label' => 'Message / Details',
                    'class' => 'form-control',
                    'required' => true
                ]) ?>
            </div>

            <?php if (!empty($hcaptcha_sitekey)): ?>
                <div class="col-12">
                    <div class="h-captcha" data-sitekey="<?= h($hcaptcha_sitekey) ?>"></div>
                </div>
            <?php endif; ?>
        </div>

        <div class="mt-4">
            <?= $this->Form->button('Submit Inquiry', ['class' => 'btn btn-primary']) ?>
            <a href="<?= $this->Url->build(['controller'=>'Dashboards','action'=>'index']) ?>"
               class="btn btn-outline-secondary ms-2">Cancel</a>
        </div>

        <?= $this->Form->end() ?>
    </div>
</div>