<script src="https://js.hcaptcha.com/1/api.js" async defer></script>

<style>
/* Force white background for form card */
.content-card {
    background: #ffffff !important;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
}

/* Make text BLACK */
.content-card h4,
.content-card p,
.content-card label {
    color: #000000 !important;
}

/* Make input boxes WHITE */
.form-control,
.form-select,
textarea {
    background-color: #ffffff !important;
    color: #000000 !important;
    border: 1px solid #ced4da !important;
}

/* Placeholder text color */
.form-control::placeholder,
textarea::placeholder {
    color: #6c757d !important;
}

/* Fix select dropdown arrow */
select.form-control {
    background-color: #ffffff !important;
}
</style>


<div class="container-fluid py-4">
    <div class="content-card" style="max-width:800px;margin:auto;">

        <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
                <h4 class="fw-bold mb-1">Contact Lost & Found (Mall)</h4>
                <p class="mb-0">
                    Please fill in the form below. Our mall Lost & Found team will contact you.
                </p>
            </div>

            <?= $this->Html->link(
                'Check Response',
                ['action' => 'check'],
                ['class' => 'btn btn-outline-primary btn-sm']
            ) ?>
        </div>

        <hr class="mb-4">

        <?= $this->Form->create($contact) ?>

        <div class="row g-3">
            <div class="col-md-6">
                <?= $this->Form->control('name', [
                    'label' => 'Full Name',
                    'class' => 'form-control',
                    'required' => true
                ]) ?>
            </div>

            <div class="col-md-6">
                <?= $this->Form->control('email', [
                    'label' => 'Email Address',
                    'class' => 'form-control',
                    'required' => true
                ]) ?>
            </div>

            <div class="col-12">
                <?= $this->Form->control('category', [
                    'type' => 'select',
                    'options' => $categories,
                    'empty' => '-- Select Inquiry Type --',
                    'class' => 'form-control',
                    'required' => true
                ]) ?>
            </div>

            <div class="col-12">
                <?= $this->Form->control('subject', [
                    'label' => 'Subject',
                    'class' => 'form-control'
                ]) ?>
            </div>

            <div class="col-12">
                <?= $this->Form->control('notes', [
                    'type' => 'textarea',
                    'rows' => 5,
                    'label' => 'Message / Details',
                    'class' => 'form-control',
                    'required' => true
                ]) ?>
            </div>

            <?php if (!empty($hcaptcha_sitekey ?? null)): ?>
                <div class="col-12">
                    <div class="h-captcha" data-sitekey="<?= h($hcaptcha_sitekey) ?>"></div>
                </div>
            <?php endif; ?>
        </div>

        <div class="mt-4">
            <?= $this->Form->button('Submit Inquiry', ['class' => 'btn btn-primary']) ?>
            <a href="<?= $this->Url->build(['controller'=>'Dashboards','action'=>'index']) ?>"
               class="btn btn-outline-secondary ms-2">Cancel</a>
        </div>

        <?= $this->Form->end() ?>
    </div>
</div>
