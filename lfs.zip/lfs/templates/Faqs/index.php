<?php
/**
 * Enhanced FAQ Page
 * Modern design with categories and search
 */
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
    * {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }

    :root {
        --primary-color: #0ea5e9;
        --primary-dark: #0284c7;
        --text-dark: #111827;
        --text-muted: #64748b;
        --border-color: #e2e8f0;
        --bg-light: #f8fafc;
    }

    body {
        background: var(--bg-light);
    }

    /* Page Header */
    .page-header {
        margin-bottom: 0.75rem;
    }

    .page_title {
        font-size: 1.5rem;
        font-weight: 800;
        color: var(--text-dark);
        margin-bottom: 0.25rem;
        letter-spacing: -0.02em;
    }

    .sub_title {
        font-size: 0.8rem;
        color: var(--text-muted);
        font-weight: 500;
    }

    .line {
        height: 2px;
        background: linear-gradient(90deg, var(--primary-color) 0%, transparent 100%);
        border: none;
        margin-bottom: 0.75rem !important;
    }

    /* Hero Section */
    .faq-hero {
        background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
        border-radius: 20px;
        padding: 3.5rem 2.5rem;
        color: #fff;
        margin-bottom: 2rem;
        text-align: center;
        position: relative;
        overflow: hidden;
        box-shadow: 0 20px 60px rgba(14, 165, 233, 0.3);
    }

    .faq-hero::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -30%;
        width: 500px;
        height: 500px;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.2) 0%, transparent 70%);
        animation: float 8s ease-in-out infinite;
    }

    @keyframes float {
        0%, 100% { transform: translate(0, 0) rotate(0deg); }
        50% { transform: translate(20px, -20px) rotate(5deg); }
    }

    .faq-hero::after {
        content: '';
        position: absolute;
        bottom: -40%;
        left: -20%;
        width: 400px;
        height: 400px;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.15) 0%, transparent 70%);
        animation: float 10s ease-in-out infinite reverse;
    }

    .faq-hero h1 {
        font-size: 2.5rem;
        font-weight: 900;
        margin-bottom: 1rem;
        position: relative;
        z-index: 1;
        text-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        letter-spacing: -0.02em;
    }

    .faq-hero p {
        font-size: 1.15rem;
        opacity: 0.95;
        margin-bottom: 2.5rem;
        position: relative;
        z-index: 1;
        font-weight: 500;
    }

    /* Search Box */
    .search-container {
        max-width: 700px;
        margin: 0 auto;
        position: relative;
        z-index: 1;
    }

    .search-wrapper {
        position: relative;
        animation: slideUp 0.6s ease;
    }

    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .search-input {
        width: 100%;
        padding: 1.25rem 1.75rem 1.25rem 4rem;
        border-radius: 60px;
        border: none;
        font-size: 1.05rem;
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        font-weight: 500;
    }

    .search-input:focus {
        outline: none;
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.35);
        transform: translateY(-4px);
    }

    .search-input::placeholder {
        color: #94a3b8;
    }

    .search-icon {
        position: absolute;
        left: 1.75rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--text-muted);
        font-size: 1.5rem;
        pointer-events: none;
    }

    .search-results-badge {
        position: absolute;
        right: 1.75rem;
        top: 50%;
        transform: translateY(-50%);
        background: rgba(14, 165, 233, 0.1);
        color: var(--primary-color);
        padding: 0.4rem 1rem;
        border-radius: 999px;
        font-size: 0.8rem;
        font-weight: 700;
        display: none;
    }

    /* Category Filters */
    .category-filters {
        background: #fff;
        border-radius: 16px;
        padding: 1.5rem;
        margin-bottom: 2rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
        display: flex;
        gap: 0.75rem;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
    }

    .filter-label {
        font-weight: 700;
        font-size: 0.9rem;
        color: var(--text-dark);
    }

    .category-btn {
        padding: 0.75rem 1.5rem;
        border-radius: 12px;
        border: 2px solid var(--border-color);
        background: #fff;
        color: var(--text-dark);
        font-weight: 600;
        font-size: 0.9rem;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        display: inline-flex;
        align-items: center;
        gap: 0.6rem;
        position: relative;
        overflow: hidden;
    }

    .category-btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(14, 165, 233, 0.1), transparent);
        transition: left 0.5s ease;
    }

    .category-btn:hover::before {
        left: 100%;
    }

    .category-btn:hover {
        border-color: var(--primary-color);
        background: rgba(14, 165, 233, 0.05);
        color: var(--primary-color);
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(14, 165, 233, 0.15);
    }

    .category-btn.active {
        border-color: var(--primary-color);
        background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
        color: #fff;
        box-shadow: 0 8px 24px rgba(14, 165, 233, 0.35);
        transform: translateY(-2px);
    }

    .category-count {
        background: rgba(255, 255, 255, 0.25);
        padding: 0.2rem 0.6rem;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 800;
    }

    .category-btn.active .category-count {
        background: rgba(255, 255, 255, 0.3);
    }

    /* FAQ Cards */
    .faq-grid {
        display: grid;
        gap: 1rem;
    }

    .faq-category-section {
        margin-bottom: 2.5rem;
    }

    .category-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 2px solid var(--border-color);
    }

    .category-icon-box {
        width: 56px;
        height: 56px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .category-title {
        flex: 1;
    }

    .category-title h2 {
        font-size: 1.4rem;
        font-weight: 800;
        color: var(--text-dark);
        margin-bottom: 0.25rem;
        letter-spacing: -0.01em;
    }

    .category-subtitle {
        font-size: 0.85rem;
        color: var(--text-muted);
        font-weight: 500;
    }

    .faq-card {
        background: #fff;
        border-radius: 16px;
        border: 2px solid var(--border-color);
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
    }

    .faq-card:hover {
        border-color: var(--primary-color);
        box-shadow: 0 12px 32px rgba(14, 165, 233, 0.15);
        transform: translateX(4px);
    }

    .faq-question-btn {
        width: 100%;
        padding: 1.5rem 1.75rem;
        background: none;
        border: none;
        text-align: left;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1.5rem;
        transition: all 0.3s ease;
    }

    .faq-card.active .faq-question-btn {
        background: rgba(14, 165, 233, 0.05);
        border-bottom: 2px solid var(--border-color);
    }

    .question-content {
        flex: 1;
    }

    .question-text {
        font-weight: 700;
        font-size: 1rem;
        color: var(--text-dark);
        line-height: 1.5;
        letter-spacing: -0.01em;
    }

    .faq-card.active .question-text {
        color: var(--primary-color);
    }

    .question-icon {
        width: 40px;
        height: 40px;
        border-radius: 12px;
        background: rgba(14, 165, 233, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary-color);
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        flex-shrink: 0;
        font-size: 1.2rem;
    }

    .faq-card.active .question-icon {
        background: var(--primary-color);
        color: #fff;
        transform: rotate(180deg);
    }

    .faq-answer {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .faq-card.active .faq-answer {
        max-height: 800px;
    }

    .answer-content {
        padding: 1.75rem;
        color: var(--text-muted);
        line-height: 1.8;
        font-size: 0.95rem;
        font-weight: 500;
    }

    /* Sidebar */
    .sidebar-card {
        background: #fff;
        border-radius: 16px;
        border: 1px solid var(--border-color);
        padding: 1.75rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
        transition: all 0.3s ease;
    }

    .sidebar-card:hover {
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    }

    .sidebar-title {
        font-size: 1.15rem;
        font-weight: 800;
        color: var(--text-dark);
        margin-bottom: 1.25rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .sidebar-title i {
        color: var(--primary-color);
        font-size: 1.3rem;
    }

    .quick-link {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        border-radius: 12px;
        background: var(--bg-light);
        margin-bottom: 0.75rem;
        text-decoration: none;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .quick-link:hover {
        background: rgba(14, 165, 233, 0.05);
        border-color: var(--primary-color);
        transform: translateX(6px);
    }

    .quick-link-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .quick-link-text h6 {
        font-weight: 700;
        font-size: 0.9rem;
        color: var(--text-dark);
        margin-bottom: 0.25rem;
    }

    .quick-link-text p {
        font-size: 0.75rem;
        color: var(--text-muted);
        margin: 0;
    }

    /* Contact CTA */
    .contact-cta {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        border-radius: 16px;
        padding: 2rem;
        color: #fff;
        text-align: center;
        position: relative;
        overflow: hidden;
        box-shadow: 0 8px 24px rgba(16, 185, 129, 0.3);
    }

    .contact-cta::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.15) 0%, transparent 70%);
    }

    .contact-cta h3 {
        font-size: 1.5rem;
        font-weight: 900;
        margin-bottom: 0.75rem;
        position: relative;
        z-index: 1;
    }

    .contact-cta p {
        opacity: 0.95;
        margin-bottom: 1.5rem;
        position: relative;
        z-index: 1;
        font-weight: 500;
    }

    .btn {
        font-weight: 700;
        border-radius: 12px;
        padding: 0.875rem 2rem;
        transition: all 0.3s ease;
        border: none;
        font-size: 0.95rem;
    }

    .btn-light {
        background: #fff;
        color: #059669;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .btn-light:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
        color: #059669;
    }

    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 5rem 2rem;
        background: #fff;
        border-radius: 16px;
        border: 2px dashed var(--border-color);
    }

    .empty-state i {
        font-size: 5rem;
        color: var(--border-color);
        margin-bottom: 1.5rem;
        display: block;
    }

    .empty-state h4 {
        font-weight: 800;
        color: var(--text-dark);
        margin-bottom: 0.75rem;
    }

    .empty-state p {
        color: var(--text-muted);
        font-size: 1rem;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .faq-hero h1 {
            font-size: 2rem;
        }

        .category-filters {
            flex-direction: column;
            align-items: stretch;
        }

        .category-btn {
            justify-content: center;
        }
    }
</style>

<!--Header-->
<div class="row text-body-secondary page-header">
    <div class="col-12">
        <h1 class="my-0 page_title">Frequently Asked Questions</h1>
        <h6 class="sub_title">Everything you need to know about our Lost & Found system</h6>
    </div>
</div>
<div class="line"></div>

<!-- Hero Section -->
<div class="faq-hero">
    <h1>How can we help you today?</h1>
    <p>Search our knowledge base or browse by category</p>
    
    <div class="search-container">
        <div class="search-wrapper">
            <i class="bi bi-search search-icon"></i>
            <input type="text" class="search-input" id="faqSearch" placeholder="Search for answers...">
            <span class="search-results-badge" id="resultsCount">0 results</span>
        </div>
    </div>
</div>

<!-- Category Filters -->
<div class="category-filters">
    <span class="filter-label">Browse by:</span>
    <button class="category-btn active" data-category="all">
        <i class="bi bi-grid-fill"></i>
        All Questions
        <span class="category-count"><?= count($faqs ?? []) ?></span>
    </button>
    <button class="category-btn" data-category="general">
        <i class="bi bi-info-circle-fill"></i>
        General
        <span class="category-count"><?= count(array_filter($faqs ?? [], fn($f) => ($f->category ?? '') === 'general')) ?></span>
    </button>
    <button class="category-btn" data-category="reporting">
        <i class="bi bi-flag-fill"></i>
        Reporting
        <span class="category-count"><?= count(array_filter($faqs ?? [], fn($f) => ($f->category ?? '') === 'reporting')) ?></span>
    </button>
    <button class="category-btn" data-category="claiming">
        <i class="bi bi-hand-thumbs-up-fill"></i>
        Claiming
        <span class="category-count"><?= count(array_filter($faqs ?? [], fn($f) => ($f->category ?? '') === 'claiming')) ?></span>
    </button>
    <button class="category-btn" data-category="account">
        <i class="bi bi-person-circle"></i>
        Account
        <span class="category-count"><?= count(array_filter($faqs ?? [], fn($f) => ($f->category ?? '') === 'account')) ?></span>
    </button>
</div>

<div class="row g-4">
    <!-- Main Content -->
    <div class="col-lg-8">
        
        <?php if (!empty($faqs)): ?>
            <?php
            // Group FAQs by category
            $categories = [
                'general' => ['name' => 'General Questions', 'icon' => 'info-circle-fill', 'color' => '#dbeafe', 'text' => '#1e40af'],
                'reporting' => ['name' => 'Reporting Items', 'icon' => 'flag-fill', 'color' => '#fee2e2', 'text' => '#991b1b'],
                'claiming' => ['name' => 'Claiming Items', 'icon' => 'hand-thumbs-up-fill', 'color' => '#d1fae5', 'text' => '#065f46'],
                'account' => ['name' => 'Account & Settings', 'icon' => 'person-circle', 'color' => '#e0e7ff', 'text' => '#4338ca']
            ];

            $groupedFaqs = [];
            foreach ($faqs as $faq) {
                $cat = $faq->category ?? 'general';
                if (!isset($groupedFaqs[$cat])) {
                    $groupedFaqs[$cat] = [];
                }
                $groupedFaqs[$cat][] = $faq;
            }
            ?>

            <?php foreach ($categories as $catKey => $catInfo): ?>
                <?php if (!empty($groupedFaqs[$catKey])): ?>
                    <div class="faq-category-section" data-category="<?= $catKey ?>">
                        <div class="category-header">
                            <div class="category-icon-box" style="background: <?= $catInfo['color'] ?>;">
                                <i class="bi bi-<?= $catInfo['icon'] ?>" style="color: <?= $catInfo['text'] ?>;"></i>
                            </div>
                            <div class="category-title">
                                <h2><?= h($catInfo['name']) ?></h2>
                                <p class="category-subtitle"><?= count($groupedFaqs[$catKey]) ?> question(s)</p>
                            </div>
                        </div>

                        <div class="faq-grid">
                            <?php foreach ($groupedFaqs[$catKey] as $faq): ?>
                                <div class="faq-card" data-faq-id="<?= $faq->id ?>">
                                    <button class="faq-question-btn" onclick="toggleFaq(this)">
                                        <div class="question-content">
                                            <div class="question-text"><?= h($faq->question) ?></div>
                                        </div>
                                        <div class="question-icon">
                                            <i class="bi bi-chevron-down"></i>
                                        </div>
                                    </button>
                                    <div class="faq-answer">
                                        <div class="answer-content">
                                            <?= nl2br(h($faq->answer)) ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <i class="bi bi-question-circle"></i>
                <h4>No FAQs Available</h4>
                <p>We're working on adding helpful content. Check back soon!</p>
            </div>
        <?php endif; ?>

    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        
        <!-- Quick Links -->
        <div class="sidebar-card">
            <h5 class="sidebar-title">
                <i class="bi bi-lightning-charge-fill"></i>
                Quick Links
            </h5>

            <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'add']) ?>" class="quick-link">
                <div class="quick-link-icon" style="background: linear-gradient(135deg, #fee2e2, #fecaca);">
                    <i class="bi bi-plus-circle-fill" style="color: #dc2626;"></i>
                </div>
                <div class="quick-link-text">
                    <h6>Report Item</h6>
                    <p>Lost or found something?</p>
                </div>
            </a>

            <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'index']) ?>" class="quick-link">
                <div class="quick-link-icon" style="background: linear-gradient(135deg, #dbeafe, #bfdbfe);">
                    <i class="bi bi-search" style="color: #2563eb;"></i>
                </div>
                <div class="quick-link-text">
                    <h6>Browse Items</h6>
                    <p>View all items</p>
                </div>
            </a>

            <a href="<?= $this->Url->build(['controller' => 'Contacts', 'action' => 'add']) ?>" class="quick-link">
                <div class="quick-link-icon" style="background: linear-gradient(135deg, #d1fae5, #a7f3d0);">
                    <i class="bi bi-envelope-fill" style="color: #059669;"></i>
                </div>
                <div class="quick-link-text">
                    <h6>Contact Support</h6>
                    <p>Get personalized help</p>
                </div>
            </a>
        </div>

        <!-- Contact CTA -->
        <div class="contact-cta">
            <h3>Still have questions?</h3>
            <p>Can't find what you're looking for? Our support team is here to help!</p>
            <a href="<?= $this->Url->build(['controller' => 'Contacts', 'action' => 'add']) ?>" class="btn btn-light">
                <i class="bi bi-chat-dots-fill me-2"></i>Contact Us
            </a>
        </div>

    </div>
</div>

<script>
// Toggle FAQ
function toggleFaq(button) {
    const card = button.closest('.faq-card');
    const isActive = card.classList.contains('active');

    // Close all FAQs
    document.querySelectorAll('.faq-card').forEach(c => c.classList.remove('active'));

    // Open clicked FAQ if it wasn't active
    if (!isActive) {
        card.classList.add('active');
        setTimeout(() => {
            card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 100);
    }
}

// Category Filter (wait for DOM)
document.addEventListener('DOMContentLoaded', function () {

    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            const category = this.dataset.category;

            document.querySelectorAll('.faq-category-section').forEach(section => {
                if (category === 'all' || section.dataset.category === category) {
                    section.style.display = 'block';
                } else {
                    section.style.display = 'none';
                }
            });
        });
    });

    // Search Functionality
    const searchInput = document.getElementById('faqSearch');
    const resultsCount = document.getElementById('resultsCount');

    // Escape special regex chars so search won't crash on symbols like +, ?, (, )
    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    // Store original question text so highlight can be reset
    document.querySelectorAll('.faq-card .question-text').forEach(el => {
        el.dataset.original = el.textContent;
    });

    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = (e.target.value || '').toLowerCase();
            const allFaqs = document.querySelectorAll('.faq-card');
            let visibleCount = 0;

            // reset highlights first
            document.querySelectorAll('.faq-card .question-text').forEach(el => {
                if (el.dataset.original) el.textContent = el.dataset.original;
            });

            if (searchTerm === '') {
                allFaqs.forEach(faq => faq.style.display = 'block');
                if (resultsCount) resultsCount.style.display = 'none';
                return;
            }

            const safeTerm = escapeRegExp(searchTerm);
            const regex = new RegExp('(' + safeTerm + ')', 'gi');

            allFaqs.forEach(faq => {
                const questionEl = faq.querySelector('.question-text');
                const answerEl = faq.querySelector('.answer-content');

                const questionText = (questionEl?.dataset.original || '').toLowerCase();
                const answerText = (answerEl?.textContent || '').toLowerCase();

                if (questionText.includes(searchTerm) || answerText.includes(searchTerm)) {
                    faq.style.display = 'block';
                    visibleCount++;

                    // highlight in question
                    if (questionEl && questionEl.dataset.original) {
                        questionEl.innerHTML = questionEl.dataset.original.replace(
                            regex,
                            '<mark style="background:#fde047;padding:0 0.25rem;border-radius:4px;">$1</mark>'
                        );
                    }
                } else {
                    faq.style.display = 'none';
                }
            });

            // Show results count
            if (resultsCount) {
                resultsCount.textContent = visibleCount + ' result' + (visibleCount !== 1 ? 's' : '');
                resultsCount.style.display = 'block';
            }
        });
    }
});
</script>
