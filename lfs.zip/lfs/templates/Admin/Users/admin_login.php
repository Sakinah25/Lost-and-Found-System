<?php
/**
 * Admin Login Page
 * templates/Users/admin_login.php
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $title ?? 'Admin Login' ?></title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <style>
    body{
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      background: linear-gradient(135deg, #0f172a 0%, #111827 100%);
      padding:20px;
    }
    .card-box{
      width:100%;
      max-width:420px;
      border-radius:16px;
      overflow:hidden;
      box-shadow:0 20px 60px rgba(0,0,0,.35);
    }
    .header{
      background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      color:#fff;
      padding:28px 24px;
      text-align:center;
    }
    .icon{
      width:64px;height:64px;
      display:flex;
      align-items:center;
      justify-content:center;
      margin:0 auto 12px;
      border-radius:14px;
      background: rgba(255,255,255,.18);
      font-size:28px;
    }
    .body{ background:#fff; padding:26px 24px; }
    .form-control{ padding:12px 14px; border-radius:10px; }
    .btn-admin{
      width:100%;
      padding:12px 14px;
      border-radius:10px;
      border:none;
      background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      color:#fff;
      font-weight:600;
    }
    .link{
      text-decoration:none;
      font-weight:600;
    }
  </style>
</head>
<body>

  <div class="card-box">
    <div class="header">
      <div class="icon"><i class="bi bi-shield-lock"></i></div>
      <h4 class="mb-1">Admin Portal</h4>
      <div style="opacity:.9;font-size:.95rem;">Sign in with admin account only</div>
    </div>

    <div class="body">
      <?= $this->Flash->render() ?>

      <?= $this->Form->create(null) ?>

      <div class="mb-3">
        <label class="form-label fw-semibold">Email</label>
        <?= $this->Form->control('email', [
          'label' => false,
          'class' => 'form-control',
          'type' => 'email',
          'required' => true,
          'placeholder' => 'admin@localhost.com'
        ]) ?>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Password</label>
        <?= $this->Form->control('password', [
          'label' => false,
          'class' => 'form-control',
          'type' => 'password',
          'required' => true,
          'placeholder' => 'Enter password'
        ]) ?>
      </div>

      <button type="submit" class="btn-admin">
        <i class="bi bi-box-arrow-in-right"></i> Sign In (Admin)
      </button>

      <?= $this->Form->end() ?>

      <div class="text-center mt-3">
        <a class="link" href="<?= $this->Url->build(['controller' => 'Users', 'action' => 'login']) ?>">
          ← Back to User Login
        </a>
      </div>
    </div>
  </div>

</body>
</html>
