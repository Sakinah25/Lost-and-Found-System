[14:50, 1/13/2026] naziera PP: <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Item | Mall Lost & Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;

        }
        
        /* Smooth Animations */
        .smooth-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .smooth-hover:hover {
            transform: transla…
[15:00, 1/13/2026] naziera PP: <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Item | Mall Lost & Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;

        }
        
        /* Smooth Animations */
        .smooth-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .smooth-hover:hover {
            transform: translateY(-4px);
        }
        
        /* Pulse Animation */
        @keyframes pulse-glow {
            0%, 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4); }
            50% { box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); }
        }
        .pulse-glow {
            animation: pulse-glow 2s infinite;
        }
        
        /* Slide In Animation */
        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .slide-in-up {
            animation: slideInUp 0.5s ease-out;
        }
        
        /* Fade In Animation */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .fade-in {
            animation: fadeIn 0.6s ease-out;
        }
        
        /* Scale In Animation */
        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
        .scale-in {
            animation: scaleIn 0.4s ease-out;
        }
        
        /* Float Animation */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        .float-animation {
            animation: float 3s ease-in-out infinite;
        }
        
        /* Gradient Animation */
        @keyframes gradient-shift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        .animated-gradient {
            background-size: 200% 200%;
            animation: gradient-shift 3s ease infinite;
        }
        
        /* Shimmer Effect */
        @keyframes shimmer {
            0% { background-position: -1000px 0; }
            100% { background-position: 1000px 0; }
        }
        .shimmer {
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            background-size: 1000px 100%;
            animation: shimmer 2s infinite;
        }
        
        /* Custom Input Focus */
        .input-focus:focus {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(16, 185, 129, 0.2);
        }
        
        /* Image Upload Hover */
        .upload-zone:hover {
            background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        
        /* Progress Steps */
        .step-indicator {
            transition: all 0.3s ease;
        }
        .step-active {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            transform: scale(1.1);
        }
        
        /* Ripple Effect */
        .ripple {
            position: relative;
            overflow: hidden;
        }
        .ripple::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        .ripple:active::after {
            width: 300px;
            height: 300px;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-50 via-emerald-50/30 to-slate-50">

<div class="min-h-screen flex">

    <!-- SIDEBAR -->
    <aside class="hidden md:flex md:flex-col w-64 bg-white border-r border-slate-200 shadow-lg">
        <!-- Logo -->
        <div class="flex items-center gap-3 px-6 py-5 border-b border-slate-200">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center text-white font-bold shadow-lg pulse-glow">
                <i class="bi bi-shield-check text-xl"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-800">Mall Lost & Found</p>
                <p class="text-xs text-slate-500">User Panel</p>
            </div>
        </div>

        <!-- Navigation -->
        <nav class="flex-1 px-3 py-6 space-y-2">
            <a href="{{ route('user.dashboard') }}"
               class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-600 hover:bg-gradient-to-r hover:from-slate-100 hover:to-slate-50 smooth-hover group">
                <i class="bi bi-house-door text-xl group-hover:scale-110 transition-transform"></i>
                <span class="font-medium">Dashboard</span>
            </a>

            <a href="#"
               class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-600 hover:bg-gradient-to-r hover:from-slate-100 hover:to-slate-50 smooth-hover group">
                <i class="bi bi-file-text text-xl group-hover:scale-110 transition-transform"></i>
                <span class="font-medium">My Reports</span>
            </a>

            <a href="#"
               class="flex items-center gap-3 px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-semibold shadow-lg smooth-hover">
                <i class="bi bi-plus-circle text-xl"></i>
                <span>Report Item</span>
            </a>

            <a href="#"
               class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-600 hover:bg-gradient-to-r hover:from-slate-100 hover:to-slate-50 smooth-hover group">
                <i class="bi bi-search text-xl group-hover:scale-110 transition-transform"></i>
                <span class="font-medium">Browse Items</span>
            </a>

            <a href="#"
               class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-600 hover:bg-gradient-to-r hover:from-slate-100 hover:to-slate-50 smooth-hover group">
                <i class="bi bi-person-circle text-xl group-hover:scale-110 transition-transform"></i>
                <span class="font-medium">My Profile</span>
            </a>
        </nav>

        <!-- Footer -->
        <div class="px-6 py-4 border-t border-slate-200 bg-gradient-to-r from-slate-50 to-transparent">
            <p class="text-xs text-slate-500">© 2025 Mall Lost & Found</p>
            <p class="text-xs text-slate-400 mt-1">All rights reserved</p>
        </div>
    </aside>

    <!-- MAIN AREA -->
    <main class="flex-1 flex flex-col min-h-screen">

        <!-- TOP BAR -->
        <header class="bg-white/80 backdrop-blur-md border-b border-slate-200 px-4 md:px-8 py-4 sticky top-0 z-40 shadow-sm">
            <div class="flex items-center justify-between gap-4">
                <!-- Mobile Logo -->
                <div class="md:hidden flex items-center gap-3">
                    <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center text-white font-bold shadow-lg">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <div>
                        <p class="text-sm font-bold">Report Item</p>
                        <p class="text-xs text-slate-500">Submit Report</p>
                    </div>
                </div>

                <!-- Page Title (Desktop) -->
                <div class="hidden md:block">
                    <h1 class="text-xl font-bold text-slate-800 flex items-center gap-2">
                        <i class="bi bi-clipboard-plus text-emerald-600"></i>
                        Report Lost or Found Item
                    </h1>
                    <p class="text-sm text-slate-500 mt-0.5">
                        Help reunite people with their belongings
                    </p>
                </div>

                <!-- User Menu -->
                <div class="flex items-center gap-4">
                    <div class="hidden sm:flex items-center gap-3">
                        <div class="text-right">
                            <p class="text-sm font-semibold text-slate-800">
                                {{ auth()->user()->name ?? 'Mall User' }}
                            </p>
                            <p class="text-xs text-slate-500">User Account</p>
                        </div>
                        <div class="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white font-semibold shadow-lg">
                            {{ substr(auth()->user()->name ?? 'M', 0, 1) }}
                        </div>
                    </div>

                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="px-4 py-2 rounded-lg bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 smooth-hover shadow-lg">
                            <i class="bi bi-box-arrow-right mr-1"></i> Logout
                        </button>
                    </form>
                </div>
            </div>
        </header>

        <!-- CONTENT -->
        <section class="flex-1 px-4 md:px-8 py-8">

            <div class="max-w-5xl mx-auto">

                <!-- Progress Indicator -->
                <div class="mb-8 fade-in">
                    <div class="flex items-center justify-center gap-4">
                        <div class="flex items-center gap-2">
                            <div id="step1" class="step-indicator step-active w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
                                1
                            </div>
                            <span class="text-sm font-semibold text-slate-700">Choose Type</span>
                        </div>
                        <div class="w-16 h-1 bg-slate-200 rounded"></div>
                        <div class="flex items-center gap-2">
                            <div id="step2" class="step-indicator w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold">
                                2
                            </div>
                            <span class="text-sm font-semibold text-slate-400">Fill Details</span>
                        </div>
                    </div>
                </div>

                <!-- Success Message -->
                @if (session('success'))
                    <div class="mb-6 px-6 py-4 bg-gradient-to-r from-emerald-50 to-emerald-100 border-l-4 border-emerald-500 rounded-xl shadow-lg scale-in">
                        <div class="flex items-center gap-3">
                            <i class="bi bi-check-circle-fill text-2xl text-emerald-600"></i>
                            <p class="text-sm text-emerald-800 font-semibold">
                                {{ session('success') }}
                            </p>
                        </div>
                    </div>
                @endif

                <!-- Report Type Selection -->
                <div class="bg-white rounded-2xl border border-slate-200 p-8 mb-8 shadow-xl slide-in-up">
                    <div class="text-center mb-8">
                        <div class="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-emerald-100 to-emerald-200 rounded-2xl mb-4 float-animation">
                            <i class="bi bi-question-circle text-3xl text-emerald-600"></i>
                        </div>
                        <h2 class="text-2xl font-bold text-slate-800 mb-2">What would you like to report?</h2>
                        <p class="text-slate-600">Choose the type of report you want to submit</p>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Lost Item Button -->
                        <button 
                            type="button"
                            onclick="selectReportType('lost')"
                            id="lostBtn"
                            class="report-type-btn ripple p-8 border-2 border-slate-200 rounded-2xl hover:border-red-500 hover:shadow-2xl smooth-hover group relative overflow-hidden">
                            <div class="relative z-10">
                                <div class="flex items-center justify-center mb-4">
                                    <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-red-100 to-red-200 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                                        <i class="bi bi-exclamation-triangle text-3xl text-red-600"></i>
                                    </div>
                                </div>
                                <h3 class="text-xl font-bold text-slate-900 mb-2">I Lost Something</h3>
                                <p class="text-sm text-slate-600">Report an item you've lost and need help finding</p>
                                <div class="mt-4 inline-flex items-center text-red-600 font-semibold text-sm group-hover:translate-x-2 transition-transform">
                                    Select <i class="bi bi-arrow-right ml-2"></i>
                                </div>
                            </div>
                        </button>

                        <!-- Found Item Button -->
                        <button 
                            type="button"
                            onclick="selectReportType('found')"
                            id="foundBtn"
                            class="report-type-btn ripple p-8 border-2 border-slate-200 rounded-2xl hover:border-blue-500 hover:shadow-2xl smooth-hover group relative overflow-hidden">
                            <div class="relative z-10">
                                <div class="flex items-center justify-center mb-4">
                                    <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                                        <i class="bi bi-search text-3xl text-blue-600"></i>
                                    </div>
                                </div>
                                <h3 class="text-xl font-bold text-slate-900 mb-2">I Found Something</h3>
                                <p class="text-sm text-slate-600">Report an item you've found to help return it</p>
                                <div class="mt-4 inline-flex items-center text-blue-600 font-semibold text-sm group-hover:translate-x-2 transition-transform">
                                    Select <i class="bi bi-arrow-right ml-2"></i>
                                </div>
                            </div>
                        </button>
                    </div>
                </div>

                <!-- Report Form -->
                <form action="/report/submit" method="POST" enctype="multipart/form-data" id="reportForm" class="hidden">
                    @csrf
                    <input type="hidden" name="report_type" id="reportType" value="">

                    <div class="bg-white rounded-2xl border border-slate-200 p-8 shadow-xl scale-in">
                        
                        <!-- Form Header -->
                        <div class="flex items-center gap-4 pb-6 border-b border-slate-200 mb-8">
                            <div id="reportIcon" class="w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg"></div>
                            <div>
                                <h2 id="reportTitle" class="text-2xl font-bold text-slate-800"></h2>
                                <p class="text-sm text-slate-500">Please fill in all the required details</p>
                            </div>
                        </div>

                        <div class="space-y-6">
                            <!-- Item Category -->
                            <div class="slide-in-up" style="animation-delay: 0.1s">
                                <label class="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3">
                                    <i class="bi bi-tag text-emerald-600"></i>
                                    Item Category *
                                </label>
                                <select name="category" class="w-full px-4 py-3.5 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 input-focus transition-all font-medium" required>
                                    <option value="">Select a category</option>
                                    <option value="electronics"><i class="bi bi-phone"></i> 📱 Electronics & Gadgets</option>
                                    <option value="bags">🎒 Bags & Accessories</option>
                                    <option value="clothing">👕 Clothing & Wearables</option>
                                    <option value="documents">🪪 Documents & IDs</option>
                                    <option value="keys">🔑 Keys & Cards</option>
                                    <option value="personal">🎁 Personal Items</option>
                                    <option value="other">📦 Other</option>
                                </select>
                            </div>

                            <!-- Item Name -->
                            <div class="slide-in-up" style="animation-delay: 0.2s">
                                <label class="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3">
                                    <i class="bi bi-card-heading text-emerald-600"></i>
                                    Item Name *
                                </label>
                                <input 
                                    type="text" 
                                    name="item_name" 
                                    placeholder="e.g., iPhone 13 Pro, Black Wallet, Car Keys"
                                    class="w-full px-4 py-3.5 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 input-focus transition-all font-medium"
                                    required
                                >
                            </div>

                            <!-- Description -->
                            <div class="slide-in-up" style="animation-delay: 0.3s">
                                <label class="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3">
                                    <i class="bi bi-textarea-resize text-emerald-600"></i>
                                    Description *
                                </label>
                                <textarea 
                                    name="description" 
                                    rows="5"
                                    placeholder="Describe the item in detail (color, brand, unique features, condition, etc.)"
                                    class="w-full px-4 py-3.5 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 input-focus transition-all resize-none font-medium"
                                    required
                                ></textarea>
                                <p class="text-xs text-slate-500 mt-2 flex items-center gap-1">
                                    <i class="bi bi-info-circle"></i>
                                    Provide as much detail as possible to help identify the item
                                </p>
                            </div>

                            <!-- Location -->
                            <div class="slide-in-up" style="animation-delay: 0.4s">
                                <label class="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3">
                                    <i class="bi bi-geo-alt text-emerald-600"></i>
                                    Location *
                                </label>
                                <select name="location" class="w-full px-4 py-3.5 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 input-focus transition-all font-medium" required>
                                    <option value="">Select location where item was lost/found</option>
                                    <option value="ground-floor">🏢 Ground Floor</option>
                                    <option value="level-1">1️⃣ Level 1</option>
                                    <option value="level-2">🍽️ Level 2 - Food Court</option>
                                    <option value="level-3">3️⃣ Level 3</option>
                                    <option value="level-4">🎬 Level 4 - Cinema</option>
                                    <option value="parking-a">🅿️ Parking Lot A</option>
                                    <option value="parking-b">🅿️ Parking Lot B</option>
                                    <option value="restroom">🚻 Restroom</option>
                                    <option value="other">📍 Other</option>
                                </select>
                            </div>

                            <!-- Date & Time -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 slide-in-up" style="animation-delay: 0.5s">
                                <div>
                                    <label class="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3">
                                        <i class="bi bi-calendar3 text-emerald-600"></i>
                                        Date *
                                    </label>
                                    <input 
                                        type="date" 
                                        name="date"
                                        max="{{ date('Y-m-d') }}"
                                        class="w-full px-4 py-3.5 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 input-focus transition-all font-medium"
                                        required
                                    >
                                </div>

                                <div>
                                    <label class="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3">
                                        <i class="bi bi-clock text-emerald-600"></i>
                                        Time (Optional)
                                    </label>
                                    <input 
                                        type="time" 
                                        name="time"
                                        class="w-full px-4 py-3.5 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 input-focus transition-all font-medium"
                                    >
                                </div>
                            </div>

                            <!-- Photo Upload -->
                            <div class="slide-in-up" style="animation-delay: 0.6s">
                                <label class="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3">
                                    <i class="bi bi-camera text-emerald-600"></i>
                                    Upload Photo (Optional)
                                </label>
                                <div class="upload-zone border-2 border-dashed border-slate-300 rounded-2xl p-8 text-center transition-all cursor-pointer hover:border-emerald-500">
                                    <input 
                                        type="file" 
                                        name="photo" 
                                        id="photoInput"
                                        accept="image/*"
                                        class="hidden"
                                        onchange="previewImage(event)"
                                    >
                                    <label for="photoInput" class="cursor-pointer">
                                        <div id="uploadArea">
                                            <div class="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-emerald-100 to-emerald-200 rounded-2xl mb-4 float-animation">
                                                <i class="bi bi-cloud-upload text-3xl text-emerald-600"></i>
                                            </div>
                                            <p class="text-base font-bold text-slate-700 mb-1">Click to upload photo</p>
                                            <p class="text-sm text-slate-500">PNG, JPG, JPEG up to 5MB</p>
                                        </div>
                                        <div id="imagePreview" class="hidden">
                                            <img id="preview" class="max-h-64 mx-auto rounded-xl shadow-lg mb-4">
                                            <p class="text-sm text-emerald-600 font-semibold flex items-center justify-center gap-2">
                                                <i class="bi bi-check-circle-fill"></i> Photo uploaded successfully
                                            </p>
                                            <p class="text-xs text-slate-500 mt-2">Click to change photo</p>
                                        </div>
                                    </label>
                                </div>
                            </div>

                            <!-- Contact Information -->
                            <div class="slide-in-up" style="animation-delay: 0.7s">
                                <label class="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3">
                                    <i class="bi bi-telephone text-emerald-600"></i>
                                    Contact Number *
                                </label>
                                <input 
                                    type="tel" 
                                    name="contact" 
                                    placeholder="+60 12-345 6789"
                                    class="w-full px-4 py-3.5 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 input-focus transition-all font-medium"
                                    required
                                >
                                <p class="text-xs text-slate-500 mt-2 flex items-center gap-1">
                                    <i class="bi bi-shield-check"></i>
                                    We'll use this to contact you if there's a match
                                </p>
                            </div>
                        </div>

                        <!-- Submit Buttons -->
                        <div class="flex flex-col sm:flex-row gap-4 mt-8 pt-6 border-t border-slate-200">
                            <button 
                                type="submit"
                                class="flex-1 ripple py-4 px-8 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-bold rounded-xl shadow-xl smooth-hover flex items-center justify-center gap-2 animated-gradient">
                                <i class="bi bi-send-fill"></i>
                                Submit Report
                            </button>
                            <button 
                                type="button"
                                onclick="cancelReport()"
                                class="px-8 py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl smooth-hover flex items-center justify-center gap-2">
                                <i class="bi bi-x-circle"></i>
                                Cancel
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Help Card -->
                <div class="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-2xl p-6 mt-8 shadow-lg fade-in">
                    <div class="flex items-start gap-4">
                        <div class="flex-shrink-0">
                            <div class="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center shadow-lg float-animation">
                                <i class="bi bi-lightbulb text-2xl text-white"></i>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold text-blue-900 mb-3">Tips for Better Results</h3>
                            <ul class="space-y-2">
                                <li class="flex items-start gap-2 text-sm text-blue-800">
                                    <i class="bi bi-check-circle-fill text-blue-600 mt-0.5"></i>
                                    <span>Include as many details as possible about the item</span>
                                </li>
                                <li class="flex items-start gap-2 text-sm text-blue-800">
                                    <i class="bi bi-check-circle-fill text-blue-600 mt-0.5"></i>
                                    <span>Upload a clear photo if available</span>
                                </li>
                                <li class="flex items-start gap-2 text-sm text-blue-800">
                                    <i class="bi bi-check-circle-fill text-blue-600 mt-0.5"></i>
                                    <span>Be specific about the location and time</span>
                                </li>
                                <li class="flex items-start gap-2 text-sm text-blue-800">
                                    <i class="bi bi-check-circle-fill text-blue-600 mt-0.5"></i>
                                    <span>Check back regularly for potential matches</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

<script>
    function selectReportType(type) {
        const form = document.getElementById('reportForm');
        const reportType = document.getElementById('reportType');
        const reportIcon = document.getElementById('reportIcon');
        const reportTitle = document.getElementById('reportTitle');
        const lostBtn = document.getElementById('lostBtn');
        const foundBtn = document.getElementById('foundBtn');
        const step1 = document.getElementById('step1');
        const step2 = document.getElementById('step2');
        
        // Reset button styles
        lostBtn.classList.remove('border-red-500', 'bg-red-50', 'shadow-2xl');
        foundBtn.classList.remove('border-blue-500', 'bg-blue-50', 'shadow-2xl');
        
        // Update progress
        step2.classList.add('step-active');
        step2.classList.remove('bg-slate-200', 'text-slate-500');
        
        // Set report type
        reportType.value = type;
        
        // Update UI based on type
        if (type === 'lost') {
            lostBtn.classList.add('border-red-500', 'bg-red-50', 'shadow-2xl');
            reportIcon.className = 'w-14 h-14 rounded-2xl bg-gradient-to-br from-red-100 to-red-200 flex items-center justify-center shadow-lg';
            reportIcon.innerHTML = '<i class="bi bi-exclamation-triangle text-2xl text-red-600"></i>';
            reportTitle.innerHTML = '<i class="bi bi-exclamation-triangle text-red-600 mr-2"></i>Report Lost Item';
        } else {
            foundBtn.classList.add('border-blue-500', 'bg-blue-50', 'shadow-2xl');
            reportIcon.className = 'w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center shadow-lg';
            reportIcon.innerHTML = '<i class="bi bi-search text-2xl text-blue-600"></i>';
            reportTitle.innerHTML = '<i class="bi bi-search text-blue-600 mr-2"></i>Report Found Item';
        }
        
        // Show form with animation
        form.classList.remove('hidden');
        setTimeout(() => {
            form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
    }
    
    function cancelReport() {
        const form = document.getElementById('reportForm');
        const lostBtn = document.getElementById('lostBtn');
        const foundBtn = document.getElementById('foundBtn');
        const step2 = document.getElementById('step2');
        
        form.classList.add('hidden');
        form.reset();
        lostBtn.classList.remove('border-red-500', 'bg-red-50', 'shadow-2xl');
        foundBtn.classList.remove('border-blue-500', 'bg-blue-50', 'shadow-2xl');
        
        // Reset progress
        step2.classList.remove('step-active');
        step2.classList.add('bg-slate-200', 'text-slate-500');
        
        // Hide image preview
        document.getElementById('uploadArea').classList.remove('hidden');
        document.getElementById('imagePreview').classList.add('hidden');
        
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    function previewImage(event) {
        const uploadArea = document.getElementById('uploadArea');
        const imagePreview = document.getElementById('imagePreview');
        const preview = document.getElementById('preview');
        
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                uploadArea.classList.add('hidden');
                imagePreview.classList.remove('hidden');
            };
            reader.readAsDataURL(file);
        }
    }
    
    // Add ripple effect on click
    document.querySelectorAll('.ripple').forEach(button => {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple-effect');
            
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });
</script>

</body>
</html>