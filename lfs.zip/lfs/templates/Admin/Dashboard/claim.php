<!-- TOP NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm mb-4">
  <div class="container-fluid">

    <a class="navbar-brand fw-bold" href="#">Lost & Found</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topMenu">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="topMenu">
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">

        <li class="nav-item"><a class="nav-link" href="#">User Page</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Profile</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Matching</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Claiming</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Admin</a></li>

      </ul>

      <!-- DARK MODE TOGGLE -->
      <button id="themeToggle" class="btn btn-outline-secondary btn-sm">
        🌙 Dark
      </button>
    </div>
  </div>
</nav>

<div class="container my-5">
  <div class="card shadow-sm">
    <div class="card-body">

      <!-- PAGE TITLE -->
      <h4 class="text-center fw-bold mb-4">Claim Found Item</h4>

      <div class="row g-4">

        <!-- ITEM DETAILS -->
        <div class="col-md-4">
          <div class="card h-100">
            <div class="card-body text-center">

              <img src=""
                   class="img-fluid rounded mb-3"
                   alt="Found Item">

              <h6 class="fw-bold">Item Details</h6>

              <p class="mb-1"><strong>Item:</strong> Black Wallet</p>
              <p class="mb-1"><strong>Found Location:</strong> Library</p>
              <p class="mb-0"><strong>Date Found:</strong> 23-Apr-2024</p>

            </div>
          </div>
        </div>

        <!-- CLAIM FORM -->
        <div class="col-md-8">
          <div class="card h-100">
            <div class="card-body">

              <h6 class="fw-bold mb-3">Your Details</h6>

              <form class="row g-3 needs-validation" novalidate>

                <!-- FULL NAME -->
                <div class="col-md-6">
                  <label class="form-label">Full Name</label>
                  <input type="text" class="form-control" required>
                  <div class="invalid-feedback">
                    Please enter your full name.
                  </div>
                </div>

                <!-- CONTACT NUMBER -->
                <div class="col-md-6">
                  <label class="form-label">Contact Number</label>
                  <input type="tel" class="form-control" required>
                  <div class="invalid-feedback">
                    Please enter a valid phone number.
                  </div>
                </div>

                <!-- CITY -->
                <div class="col-md-6">
                  <label class="form-label">City</label>
                  <input type="text" class="form-control" required>
                  <div class="invalid-feedback">
                    Please provide a valid city.
                  </div>
                </div>

                <!-- STATE -->
                <div class="col-md-6">
                  <label class="form-label">State</label>
                  <select class="form-select" required>
                    <option selected disabled value="">Choose...</option>
                    <option>Johor</option>
                    <option>Kedah</option>
                    <option>Kelantan</option>
                    <option>Melaka</option>
                    <option>Negeri Sembilan</option>
                    <option>Pahang</option>
                    <option>Perak</option>
                    <option>Perlis</option>
                    <option>Pulau Pinang</option>
                    <option>Sabah</option>
                    <option>Sarawak</option>
                    <option>Selangor</option>
                    <option>Terengganu</option>
                    <option>Kuala Lumpur</option>
                    <option>Putrajaya</option>
                    <option>Labuan</option>
                    <option>Others</option>
                  </select>
                  <div class="invalid-feedback">
                    Please select a state.
                  </div>
                </div>

                <!-- ZIP -->
                <div class="col-md-6">
                  <label class="form-label">Postcode</label>
                  <input type="text" class="form-control" required>
                  <div class="invalid-feedback">
                    Please provide a valid postcode.
                  </div>
                </div>

                <!-- ADDITIONAL INFO -->
                <div class="col-12">
                  <label class="form-label">Additional Information</label>
                  <textarea class="form-control" rows="4" required
                    placeholder="Describe proof of ownership (colour, brand, contents, etc.)"></textarea>
                  <div class="invalid-feedback">
                    Please provide additional information.
                  </div>
                </div>

                <!-- SUBMIT -->
                <div class="col-12">
                  <button class="btn btn-primary w-100" type="submit">
                    Submit Claim
                  </button>
                </div>

              </form>

            </div>
          </div>
        </div>

      </div>

    </div>
  </div>
</div>

<style>
/* ===== DARK MODE ===== */
    body.dark-mode {
      background: #121212;
      color: #eaeaea;
    }

    body.dark-mode .navbar,
    body.dark-mode .card,
    body.dark-mode .item-row {
      background-color: #1e1e1e !important;
      color: #eaeaea;
    }

    body.dark-mode .page-header {
      background: #1f3a6d;
    }

    body.dark-mode .nav-link,
    body.dark-mode .navbar-brand {
      color: #eaeaea !important;
    }

    body.dark-mode .text-muted {
      color: #b5b5b5 !important;
    }

    body.dark-mode .form-control,
    body.dark-mode .form-select {
      background-color: #2a2a2a;
      color: #ffffff;
      border-color: #444;
    }

    body.dark-mode .btn-outline-secondary {
      color: #fff;
      border-color: #666;
    }
</style>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
(() => {
  'use strict';

  const forms = document.querySelectorAll('.needs-validation');

  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
</script>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("themeToggle");

  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");

      toggleBtn.innerText =
        document.body.classList.contains("dark-mode")
          ? "☀️ Light"
          : "🌙 Dark";
    });
  }
});
</script>