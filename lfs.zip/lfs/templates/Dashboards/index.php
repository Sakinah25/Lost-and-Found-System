<?php
use Cake\Routing\Router;
echo $this->Html->script('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js');

$c_name = $this->request->getParam('controller');
echo $this->Html->script('bootstrapModal', ['block' => 'scriptBottom']);

$identity = $this->request->getAttribute('identity');
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
    * {
        font-family: 'Inter', 'Segoe UI', sans-serif;
    }

    :root {
        --primary-color: #0ea5e9;
        --primary-dark: #0284c7;
        --primary-light: #bae6fd;
        --lost-color: #ef4444;
        --found-color: #3b82f6;
        --text-dark: #111827;
        --text-muted: #64748b;
        --border-color: #e2e8f0;
        --bg-light: #f8fafc;
    }

    body {
        background: var(--bg-light);
    }


    .dashboard-header {
        background: #fff;
        padding: 1.5rem 0;
        margin-bottom: 1.5rem;
        border-bottom: 1px solid var(--border-color);
        position: sticky;
        top: 0;
        z-index: 100;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
    }

    .greeting-text h1 {
        font-size: 1.75rem;
        font-weight: 900;
        color: var(--text-dark);
        margin-bottom: 0.25rem;
        letter-spacing: -0.02em;
    }

    .greeting-text p {
        font-size: 0.9rem;
        color: var(--text-muted);
        margin: 0;
        font-weight: 500;
    }

    .header-actions {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .user-avatar-header {
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: linear-gradient(135deg, #10b981, #059669);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 900;
        font-size: 1.3rem;
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        transition: all 0.3s ease;
    }

    .user-avatar-header:hover {
        transform: scale(1.05);
        box-shadow: 0 6px 16px rgba(16, 185, 129, 0.4);
    }

    .hero-banner {
        background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
        border-radius: 24px;
        padding: 3rem 2.5rem;
        color: #fff;
        margin-bottom: 2rem;
        position: relative;
        overflow: hidden;
        box-shadow: 0 20px 60px rgba(14, 165, 233, 0.3);
        animation: slideUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .hero-banner::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -10%;
        width: 500px;
        height: 500px;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.2) 0%, transparent 70%);
        animation: pulse 8s ease-in-out infinite;
    }

    @keyframes pulse {
        0%, 100% {
            transform: scale(1) rotate(0deg);
            opacity: 0.5;
        }
        50% {
            transform: scale(1.15) rotate(10deg);
            opacity: 0.8;
        }
    }

    .hero-banner::after {
        content: '';
        position: absolute;
        bottom: -40%;
        left: -10%;
        width: 400px;
        height: 400px;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.15) 0%, transparent 70%);
        animation: float 10s ease-in-out infinite;
    }

    @keyframes float {
        0%, 100% { transform: translate(0, 0); }
        50% { transform: translate(30px, -30px); }
    }

    .hero-icon {
        width: 90px;
        height: 90px;
        background: rgba(255, 255, 255, 0.98);
        backdrop-filter: blur(10px);
        border-radius: 22px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.5rem;
        color: var(--primary-color);
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.2);
        animation: floatIcon 4s ease-in-out infinite;
        position: relative;
    }

    @keyframes floatIcon {
        0%, 100% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-15px) rotate(5deg); }
    }

    .hero-icon::after {
        content: '';
        position: absolute;
        inset: -3px;
        border-radius: 22px;
        background: linear-gradient(45deg, transparent, rgba(14, 165, 233, 0.3), transparent);
        opacity: 0;
        animation: shine 4s ease-in-out infinite;
    }

    @keyframes shine {
        0%, 100% { opacity: 0; transform: rotate(0deg); }
        50% { opacity: 1; transform: rotate(180deg); }
    }

    .hero-banner h2 {
        font-size: 1.9rem;
        font-weight: 900;
        text-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        letter-spacing: -0.02em;
    }

    .hero-banner p {
        font-size: 1.05rem;
        font-weight: 500;
    }

    .hero-banner .btn {
        backdrop-filter: blur(10px);
        border: 2px solid rgba(255, 255, 255, 0.3);
        transition: all 0.3s ease;
        font-weight: 700;
        padding: 0.75rem 1.75rem;
    }

    .hero-banner .btn:hover {
        background: rgba(255, 255, 255, 0.25) !important;
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        border-color: rgba(255, 255, 255, 0.5);
    }

    .stats-card {
        background: #fff;
        border-radius: 18px;
        border: 1px solid var(--border-color);
        padding: 2.5rem; 
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        height: 100%;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        position: relative;
        overflow: hidden;
    }

    .stats-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 5px;
        background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
        transform: scaleX(0);
        transform-origin: left;
        transition: transform 0.5s ease;
    }

    .stats-card:hover::before {
        transform: scaleX(1);
    }

    .stats-card::after {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(14, 165, 233, 0.05) 0%, transparent 70%);
        opacity: 0;
        transition: opacity 0.4s ease;
    }

    .stats-card:hover::after {
        opacity: 1;
    }

    .stats-card:hover {
        transform: translateY(-12px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        border-color: var(--primary-light);
    }

    .stat-icon {
        width: 88px;  
        height: 88px; 
        border-radius: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.4rem; 
        transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .stats-card:hover .stat-icon {
        transform: scale(1.15) rotate(-8deg);
    }

    .stat-value {
        font-size: 3.2rem; 
        font-weight: 900;
        line-height: 1;
        color: var(--text-dark);
        margin: 1.25rem 0 0.75rem 0;
        letter-spacing: -0.03em;
        background: linear-gradient(135deg, var(--text-dark) 0%, var(--text-muted) 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .stat-label {
        color: var(--text-muted);
        font-weight: 700;
        font-size: 0.95rem;
        margin-bottom: 0.75rem;
        letter-spacing: -0.01em;
    }

    .stat-info {
        color: var(--text-muted);
        font-size: 0.85rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 0.4rem;
    }

    .stat-badge {
        position: absolute;
        top: 1.25rem;
        right: 1.25rem;
        padding: 0.4rem 0.9rem;
        border-radius: 999px;
        font-size: 0.75rem;
        font-weight: 800;
        color: #fff;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .progress-thin {
        height: 10px;
        border-radius: 999px;
        background: var(--bg-light);
        margin-top: 1rem;
        overflow: hidden;
        box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.06);
    }

    .progress-thin .progress-bar {
        border-radius: 999px;
        transition: width 1.5s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    }

    .section-header {
        margin-bottom: 1.75rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .section-header h5 {
        font-weight: 900;
        font-size: 1.25rem;
        color: var(--text-dark);
        margin: 0;
        letter-spacing: -0.02em;
    }

    .section-header i {
        font-size: 1.75rem;
        color: var(--primary-color);
        animation: bounce 2s ease-in-out infinite;
    }

    @keyframes bounce {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-5px); }
    }

    .quick-action-card {
        background: #fff;
        border-radius: 18px;
        border: 2px solid var(--border-color);
        padding: 2.25rem 1.75rem;
        text-align: center;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
        height: 100%;
        text-decoration: none;
        display: block;
        position: relative;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .quick-action-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, rgba(14, 165, 233, 0.08) 0%, transparent 100%);
        opacity: 0;
        transition: opacity 0.4s ease;
    }

    .quick-action-card:hover::before {
        opacity: 1;
    }

    .quick-action-card:hover {
        border-color: var(--primary-color);
        transform: translateY(-12px) scale(1.02);
        box-shadow: 0 20px 40px rgba(14, 165, 233, 0.25);
    }

    .quick-action-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 1.5rem;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.25rem;
        transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        position: relative;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
    }

    .quick-action-card:hover .quick-action-icon {
        transform: scale(1.2) rotate(10deg);
    }

    .quick-action-title {
        font-weight: 800;
        font-size: 1.1rem;
        color: var(--text-dark);
        margin-bottom: 0.75rem;
        letter-spacing: -0.02em;
    }

    .quick-action-desc {
        color: var(--text-muted);
        font-size: 0.9rem;
        margin: 0;
        font-weight: 600;
    }

    .content-card {
        background: #fff;
        border-radius: 18px;
        border: 1px solid var(--border-color);
        padding: 2rem;
        height: 100%;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
    }

    .content-card:hover {
        box-shadow: 0 12px 28px rgba(0, 0, 0, 0.12);
        transform: translateY(-4px);
    }

    .section-title {
        font-size: 1.2rem;
        font-weight: 800;
        color: var(--text-dark);
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 1.75rem;
        letter-spacing: -0.02em;
        padding-bottom: 1rem;
        border-bottom: 2px solid var(--border-color);
    }

    .section-title i {
        color: var(--primary-color);
        font-size: 1.5rem;
    }

    .recent-item {
        padding: 1.25rem;
        border-radius: 14px;
        border: 1px solid transparent;
        transition: all 0.3s ease;
        margin-bottom: 0.9rem;
        background: var(--bg-light);
    }

    .recent-item:last-child {
        margin-bottom: 0;
    }

    .recent-item:hover {
        background: #fff;
        border-color: var(--primary-color);
        transform: translateX(8px);
        box-shadow: 0 8px 20px rgba(14, 165, 233, 0.15);
        cursor: pointer;
    }

    .item-icon-box {
        width: 52px;
        height: 52px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.35rem;
        transition: all 0.3s ease;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .recent-item:hover .item-icon-box {
        transform: scale(1.15) rotate(-8deg);
    }

    .item-badge {
        padding: 0.4rem 1rem;
        border-radius: 999px;
        font-size: 0.7rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .badge-lost {
        background: linear-gradient(135deg, #fee2e2, #fecaca);
        color: #991b1b;
    }

    .badge-found {
        background: linear-gradient(135deg, #dbeafe, #bfdbfe);
        color: #1e40af;
    }

    .badge-claimed {
        background: linear-gradient(135deg, #d1fae5, #a7f3d0);
        color: #065f46;
    }

    .badge-pending {
        background: linear-gradient(135deg, #fef3c7, #fde68a);
        color: #92400e;
    }

    .empty-state {
        text-align: center;
        padding: 4rem 2rem;
        color: var(--text-muted);
    }

    .empty-state i {
        font-size: 5rem;
        color: var(--border-color);
        margin-bottom: 1.5rem;
        display: block;
        animation: float 3s ease-in-out infinite;
    }

    .empty-state p {
        font-weight: 700;
        margin-bottom: 0.5rem;
        font-size: 1.1rem;
        color: var(--text-dark);
    }

    .empty-state small {
        font-size: 0.9rem;
    }

    .btn {
        font-weight: 700;
        border-radius: 12px;
        transition: all 0.3s ease;
        letter-spacing: -0.01em;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }

    .btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    }

    .btn-sm {
        font-size: 0.85rem;
        padding: 0.6rem 1.25rem;
    }

    .rounded-pill {
        border-radius: 999px !important;
    }

    .system-info-card {
        background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
        border: 1px solid var(--border-color);
    }

    .stats-card {
        animation: fadeInUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
        opacity: 0;
    }

    .stats-card:nth-child(1) { animation-delay: 0.1s; }
    .stats-card:nth-child(2) { animation-delay: 0.2s; }

    .quick-action-card {
        animation: fadeInUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
        opacity: 0;
    }

    .quick-action-card:nth-child(1) { animation-delay: 0.1s; }
    .quick-action-card:nth-child(2) { animation-delay: 0.2s; }
    .quick-action-card:nth-child(3) { animation-delay: 0.3s; }
    .quick-action-card:nth-child(4) { animation-delay: 0.4s; }

    .content-card {
        animation: fadeInUp 0.6s ease forwards;
        opacity: 0;
    }

    .content-card:nth-of-type(1) { animation-delay: 0.2s; }
    .content-card:nth-of-type(2) { animation-delay: 0.3s; }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media (max-width: 768px) {
        .hero-banner {
            padding: 2.5rem 1.75rem;
        }

        .stats-card {
            margin-bottom: 1rem;
        }

        .greeting-text h1 {
            font-size: 1.5rem;
        }
    }

	.recent-item small.text-muted{
    color: #4B5563 !important;   
}

.system-info-card p.text-muted{
    color: #4B5563 !important;   
}

/* System Overview title darker */
.system-info-card h6 {
    color: #111827 !important;   /* dark text */
}

</style>

<div class="dashboard-header">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-8">
                <div class="greeting-text">
                    <h1>
                        <?php
                        $hour = date('H');
                        if ($hour < 12) {
                            echo '<i class="bi bi-sun-fill me-2"></i>Good Morning';
                        } elseif ($hour < 18) {
                            echo '<i class="bi bi-cloud-sun-fill me-2"></i>Good Afternoon';
                        } else {
                            echo '<i class="bi bi-moon-stars-fill me-2"></i>Good Evening';
                        }
                        ?>, <?= h($identity->name ?? 'User') ?>!
                    </h1>
                    <p>Welcome back to your Lost & Found dashboard</p>
                </div>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <div class="header-actions justify-content-md-end">
                    <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'add']) ?>" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>Report Item
                    </a>
                    <div class="user-avatar-header">
                        <?= strtoupper(substr($identity->name ?? 'U', 0, 1)) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="hero-banner">
    <div class="row align-items-center position-relative" style="z-index: 1;">
        <div class="col-md-8">
            <h2 class="mb-3">Lost & Found Management System</h2>
            <p class="mb-4" style="font-size: 1.05rem; opacity: 0.95;">
                Track, manage, and reunite lost items with their owners efficiently. Your central hub for all lost and found operations.
            </p>
            <div class="d-flex gap-3 flex-wrap">
                <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'index']) ?>" class="btn btn-light">
                    <i class="bi bi-search me-2"></i>Browse Items
                </a>
                <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'add']) ?>" class="btn btn-outline-light">
                    <i class="bi bi-plus-circle me-2"></i>Report Item
                </a>
            </div>
        </div>
        <div class="col-md-4 text-center mt-4 mt-md-0">
            <div class="hero-icon mx-auto">
                <i class="bi bi-box-seam"></i>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-6 col-md-6">
        <div class="stats-card">
            <div class="stat-badge bg-danger"><?= number_format((float)($lostItemsPercent ?? 0), 0) ?>%</div>
            <div class="stat-icon" style="background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);">
                <i class="bi bi-exclamation-triangle-fill" style="color: #dc2626;"></i>
            </div>
            <div class="stat-value"><?= number_format((int)($totalLostItems ?? 0)) ?></div>
            <div class="stat-label">Lost Items</div>
            <div class="stat-info">
                <i class="bi bi-hourglass-split"></i>
                <span>Waiting to be found</span>
            </div>
            <div class="progress-thin">
                <div class="progress-bar bg-danger" style="width: <?= (float)($lostItemsPercent ?? 0) ?>%"></div>
            </div>
        </div>
    </div>

    <div class="col-lg-6 col-md-6">
        <div class="stats-card">
            <div class="stat-badge bg-primary"><?= number_format((float)($foundItemsPercent ?? 0), 0) ?>%</div>
            <div class="stat-icon" style="background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);">
                <i class="bi bi-search" style="color: #2563eb;"></i>
            </div>
            <div class="stat-value"><?= number_format((int)($totalFoundItems ?? 0)) ?></div>
            <div class="stat-label">Found Items</div>
            <div class="stat-info">
                <i class="bi bi-clock-history"></i>
                <span>Waiting for owners</span>
            </div>
            <div class="progress-thin">
                <div class="progress-bar bg-primary" style="width: <?= (float)($foundItemsPercent ?? 0) ?>%"></div>
            </div>
        </div>
    </div>
</div> 

<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="section-header">
            <i class="bi bi-lightning-charge-fill"></i>
            <h5>Quick Actions</h5>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6">
        <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'add', '?' => ['status' => 'Lost']]) ?>" class="quick-action-card">
            <div class="quick-action-icon" style="background: linear-gradient(135deg, #fee2e2, #fecaca);">
                <i class="bi bi-exclamation-triangle-fill" style="color: #dc2626;"></i>
            </div>
            <div class="quick-action-title">Report Lost Item</div>
            <p class="quick-action-desc">Submit a lost item report</p>
        </a>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6">
        <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'add', '?' => ['status' => 'Found']]) ?>" class="quick-action-card">
            <div class="quick-action-icon" style="background: linear-gradient(135deg, #dbeafe, #bfdbfe);">
                <i class="bi bi-search" style="color: #2563eb;"></i>
            </div>
            <div class="quick-action-title">Report Found Item</div>
            <p class="quick-action-desc">Register a found item</p>
        </a>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6">
        <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'index']) ?>" class="quick-action-card">
            <div class="quick-action-icon" style="background: linear-gradient(135deg, #d1fae5, #a7f3d0);">
                <i class="bi bi-grid-fill" style="color: #059669;"></i>
            </div>
            <div class="quick-action-title">Browse Items</div>
            <p class="quick-action-desc">View all lost & found items</p>
        </a>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6">
        <a href="<?= $this->Url->build(['controller' => 'Contacts', 'action' => 'index']) ?>" class="quick-action-card">
            <div class="quick-action-icon" style="background: linear-gradient(135deg, #fef3c7, #fde68a);">
                <i class="bi bi-chat-dots-fill" style="color: #92400e;"></i>
            </div>
            <div class="quick-action-title">Contacts</div>
            <p class="quick-action-desc">View contact messages</p>
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-6">
        <div class="content-card">
            <h5 class="section-title">
                <i class="bi bi-exclamation-circle-fill"></i>
                Recent Lost Items
            </h5>

            <?php if (!empty($recentLostItems) && method_exists($recentLostItems, 'isEmpty') && !$recentLostItems->isEmpty()): ?>
                <?php foreach ($recentLostItems as $item): ?>
                    <div class="recent-item">
                        <div class="d-flex align-items-center gap-3">
                            <div class="item-icon-box flex-shrink-0" style="background: linear-gradient(135deg, #fee2e2, #fecaca);">
                                <i class="bi bi-box-seam" style="color: #dc2626;"></i>
                            </div>
                            <div class="flex-grow-1 min-w-0">
                                <div class="fw-bold text-truncate" style="font-size: 0.95rem; color: var(--text-dark);">
                                    <?= h($item->name ?? $item->title ?? 'Lost Item') ?>
                                </div>
                                <small class="text-muted" style="font-size: 0.8rem;">
                                    <i class="bi bi-clock me-1"></i>
                                    <?= !empty($item->created) ? $item->created->timeAgoInWords() : '-' ?>
                                    <?php if (!empty($item->location)): ?>
                                        <span class="mx-1">•</span>
                                        <i class="bi bi-geo-alt me-1"></i><?= h($item->location) ?>
                                    <?php endif; ?>
                                </small>
                            </div>
                            <span class="item-badge badge-lost flex-shrink-0">Lost</span>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="text-center mt-4">
                    <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'index', '?' => ['status' => 'Lost']]) ?>" class="btn btn-sm btn-outline-danger rounded-pill">
                        View All Lost Items<i class="bi bi-arrow-right ms-2"></i>
                    </a>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="bi bi-inbox"></i>
                    <p>No lost items reported</p>
                    <small>Lost item reports will appear here</small>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="content-card">
            <h5 class="section-title">
                <i class="bi bi-search"></i>
                Recent Found Items
            </h5>

            <?php if (!empty($recentFoundItems) && method_exists($recentFoundItems, 'isEmpty') && !$recentFoundItems->isEmpty()): ?>
                <?php foreach ($recentFoundItems as $item): ?>
                    <div class="recent-item">
                        <div class="d-flex align-items-center gap-3">
                            <div class="item-icon-box flex-shrink-0" style="background: linear-gradient(135deg, #dbeafe, #bfdbfe);">
                                <i class="bi bi-box-seam" style="color: #2563eb;"></i>
                            </div>
                            <div class="flex-grow-1 min-w-0">
                                <div class="fw-bold text-truncate" style="font-size: 0.95rem; color: var(--text-dark);">
                                    <?= h($item->name ?? $item->title ?? 'Found Item') ?>
                                </div>
                                <small class="text-muted" style="font-size: 0.8rem;">
                                    <i class="bi bi-clock me-1"></i>
                                    <?= !empty($item->created) ? $item->created->timeAgoInWords() : '-' ?>
                                    <?php if (!empty($item->location)): ?>
                                        <span class="mx-1">•</span>
                                        <i class="bi bi-geo-alt me-1"></i><?= h($item->location) ?>
                                    <?php endif; ?>
                                </small>
                            </div>
                            <span class="item-badge badge-found flex-shrink-0">Found</span>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="text-center mt-4">
                    <a href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'index', '?' => ['status' => 'Found']]) ?>" class="btn btn-sm btn-outline-primary rounded-pill">
                        View All Found Items<i class="bi bi-arrow-right ms-2"></i>
                    </a>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="bi bi-inbox"></i>
                    <p>No found items</p>
                    <small>Found item reports will appear here</small>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-6">
        <div class="content-card">
            <h5 class="section-title">
                <i class="bi bi-pie-chart-fill"></i>
                Items by Category
            </h5>
            <canvas id="categoryChart" style="max-height: 320px;"></canvas>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="content-card">
            <h5 class="section-title">
                <i class="bi bi-bar-chart-fill"></i>
                Lost vs Found Trends
            </h5>
            <canvas id="trendsChart" style="max-height: 320px;"></canvas>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-12">
        <div class="content-card system-info-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h6 class="fw-bold mb-2" style="font-size: 1rem;">
                        <i class="bi bi-info-circle-fill me-2" style="color: var(--primary-color);"></i>
                        System Overview
                    </h6>
                    <p class="mb-0 text-muted" style="font-size: 0.9rem;">
                        <strong style="color: var(--text-dark);"><?= number_format((int)($totalItems ?? 0)) ?></strong> total items
                        <span class="mx-2">•</span>
                        <strong style="color: var(--text-dark);"><?= number_format((int)($activeUser ?? 0)) ?></strong> active users
                        <span class="mx-2">•</span>
                        <strong style="color: var(--text-dark);"><?= number_format((int)($totalAuditlog ?? 0)) ?></strong> audit entries
                    </p>
                </div>
                <div class="col-md-4 text-md-end mt-3 mt-md-0">
                    <button class="btn btn-outline-primary btn-sm rounded-pill px-4" type="button">
                        <i class="bi bi-download me-2"></i>Export Data
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->start('scriptBottom'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {

    const categoryCtx = document.getElementById('categoryChart');
    if (categoryCtx && typeof Chart !== 'undefined') {

        const categoryData = <?= json_encode($categoryData ?? [], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;

        const labels = Array.isArray(categoryData) ? categoryData.map(x => x.category) : [];
        const values = Array.isArray(categoryData) ? categoryData.map(x => x.count) : [];

        const safeLabels = labels.length ? labels : ['No Data'];
        const safeValues = values.length ? values : [1];

        const palette = ['#0ea5e9','#10b981','#f59e0b','#8b5cf6','#ec4899','#14b8a6','#f97316','#6366f1','#84cc16','#ef4444'];
        const colors = safeLabels.map((_, i) => palette[i % palette.length]);

        new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: safeLabels,
                datasets: [{
                    data: safeValues,
                    backgroundColor: colors,
                    borderWidth: 4,
                    borderColor: '#fff',
                    hoverBorderWidth: 6,
                    hoverBorderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            font: {
                                size: 13,
                                family: "'Inter', sans-serif",
                                weight: 600
                            },
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(17, 24, 39, 0.98)',
                        padding: 14,
                        titleFont: {
                            size: 14,
                            family: "'Inter', sans-serif",
                            weight: 700
                        },
                        bodyFont: {
                            size: 13,
                            family: "'Inter', sans-serif",
                            weight: 500
                        },
                        borderColor: '#e2e8f0',
                        borderWidth: 1,
                        cornerRadius: 8
                    }
                }
            }
        });
    }

    const trendsCtx = document.getElementById('trendsChart');
    if (trendsCtx && typeof Chart !== 'undefined') {

        const months = <?= json_encode($months ?? [], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
        const lostData = <?= json_encode(array_values($lostByMonth ?? []), JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
        const foundData = <?= json_encode(array_values($foundByMonth ?? []), JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;

        const safeMonths = Array.isArray(months) && months.length ? months : ['No Data'];
        const safeLost = Array.isArray(lostData) && lostData.length ? lostData : [0];
        const safeFound = Array.isArray(foundData) && foundData.length ? foundData : [0];

        new Chart(trendsCtx, {
            type: 'line',
            data: {
                labels: safeMonths,
                datasets: [{
                    label: 'Lost Items',
                    data: safeLost,
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    borderWidth: 4,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 6,
                    pointHoverRadius: 9,
                    pointBackgroundColor: '#ef4444',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 3
                }, {
                    label: 'Found Items',
                    data: safeFound,
                    borderColor: '#0ea5e9',
                    backgroundColor: 'rgba(14, 165, 233, 0.1)',
                    borderWidth: 4,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 6,
                    pointHoverRadius: 9,
                    pointBackgroundColor: '#0ea5e9',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            font: {
                                size: 13,
                                family: "'Inter', sans-serif",
                                weight: 600
                            },
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(17, 24, 39, 0.98)',
                        padding: 14,
                        titleFont: {
                            size: 14,
                            family: "'Inter', sans-serif",
                            weight: 700
                        },
                        bodyFont: {
                            size: 13,
                            family: "'Inter', sans-serif",
                            weight: 500
                        },
                        borderColor: '#e2e8f0',
                        borderWidth: 1,
                        cornerRadius: 8
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#f1f5f9',
                            drawBorder: false
                        },
                        ticks: {
                            font: {
                                size: 12,
                                family: "'Inter', sans-serif",
                                weight: 500
                            },
                            color: '#64748b',
                            padding: 10
                        }
                    },
                    x: {
                        grid: {
                            display: false,
                            drawBorder: false
                        },
                        ticks: {
                            font: {
                                size: 12,
                                family: "'Inter', sans-serif",
                                weight: 500
                            },
                            color: '#64748b',
                            padding: 10
                        }
                    }
                }
            }
        });
    }
});
</script>
<?php $this->end(); ?>