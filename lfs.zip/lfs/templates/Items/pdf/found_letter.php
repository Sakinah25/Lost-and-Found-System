<?php
use Cake\Routing\Router;

// Avoid "Undefined variable" warnings
$item = $item ?? null;
$user = $item ? ($item->user ?? null) : null;

// Change these to your real mall details
$mallName    = "Shopping Mall Lost & Found";
$mallAddress = "Your Mall Address, City, Postcode";
$mallPhone   = "Tel: 03-64428597";
$today       = date('d M Y');

// ✅ IMPORTANT: Use URL (not WWW_ROOT path) for PDF images
$headerUrl = Router::url('/img/top.png', true);
$footerUrl = Router::url('/img/bottom.png', true);

// Optional: check existence using server path (ONLY for condition)
$headerExists = file_exists(WWW_ROOT . 'img' . DS . 'top.png');
$footerExists = file_exists(WWW_ROOT . 'img' . DS . 'bottom.png');
?>

<style>
/* reserve space so footer image doesn't cover content */
body{
  font-family: DejaVu Sans, Arial, sans-serif;
  font-size: 12px;
  color:#111;
  padding-bottom: 170px; /* 143px footer + some gap */
  margin: 0;
}

.header{
  text-align:center;
  margin-bottom: 12px;
}
.header img{
  width: 100%;
  height: 143px;          /* ✅ your image height */
  object-fit: contain;
}

.mall-name{ font-size: 16px; font-weight: 800; margin: 0; }
.mall-meta{ margin: 3px 0; color:#444; font-size: 11px; }

.hr{ border-top: 1px solid #ddd; margin: 10px 0 14px; }

.title{ font-size: 14px; font-weight: 800; margin: 0 0 10px; }
.small{ color:#444; font-size: 11px; margin: 0 0 10px; }

.table{ width:100%; border-collapse: collapse; margin-top: 8px; }
.table td{ padding: 8px 6px; border-bottom: 1px solid #e5e7eb; vertical-align: top; }
.label{ width: 30%; font-weight: 800; }

.signature{ margin-top: 28px; }
.sig-line{ width: 220px; border-bottom: 1px solid #111; height: 20px; }

/* ✅ footer text line above image */
.footer{
  position: fixed;
  bottom: 150px;
  left: 0;
  right: 0;
  padding: 0 16px;
  font-size: 10px;
  color: #555;
}
.footer .left{ float:left; }
.footer .right{ float:right; }
.clearfix{ clear: both; }

/* ✅ footer image fixed at bottom */
.footer-img{
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  text-align: center;
}
.footer-img img{
  width: 100%;
  height: 143px;          /* ✅ your image height */
  object-fit: contain;
}
</style>

<?php if (!$item): ?>
  <div>Item not found.</div>
<?php else: ?>

  <!-- ✅ HEADER -->
  <div class="header">
    <?php if ($headerExists): ?>
      <img src="<?= h($headerUrl) ?>" alt="Header">
    <?php else: ?>
      <div class="mall-name"><?= h($mallName) ?></div>
      <div class="mall-meta"><?= h($mallAddress) ?></div>
      <div class="mall-meta"><?= h($mallPhone) ?></div>
    <?php endif; ?>
  </div>

  <div class="hr"></div>

  <div class="title">Found Item Confirmation Letter</div>
  <div class="small">Date: <?= h($today) ?></div>

  <table class="table">
    <tr><td class="label">Item ID</td><td><?= h($item->id) ?></td></tr>
    <tr><td class="label">Item Name</td><td><?= h($item->name) ?></td></tr>
    <tr><td class="label">Category</td><td><?= h($item->item_category) ?></td></tr>
    <tr><td class="label">Found Location</td><td><?= h($item->location) ?></td></tr>
    <tr><td class="label">Date Found</td><td><?= h($item->lost_found_date) ?></td></tr>
    <tr><td class="label">Status</td><td><?= h($item->status) ?></td></tr>
  </table>

  <div style="margin-top: 14px;">
    This letter confirms that the found item stated above has been recorded in the <?= h($mallName) ?> system.
  </div>

  <?php if ($user): ?>
    <div style="margin-top: 16px; font-weight:800;">Finder / Staff Details</div>
    <table class="table">
      <tr><td class="label">User ID</td><td><?= h($user->id) ?></td></tr>
      <tr><td class="label">Name</td><td><?= h($user->full_name ?? $user->name ?? '-') ?></td></tr>
      <tr><td class="label">Email</td><td><?= h($user->email ?? '-') ?></td></tr>
      <tr><td class="label">Phone</td><td><?= h($user->phone ?? '-') ?></td></tr>
    </table>
  <?php endif; ?>

  <div class="signature">
    <div class="sig-line"></div>
    <div>Lost &amp; Found Officer</div>
  </div>

  <!-- ✅ FOOTER TEXT -->
  <div class="footer">
    <div class="left"><?= h($mallName) ?> • <?= h($mallPhone) ?></div>
    <div class="right">Page 1</div>
    <div class="clearfix"></div>
  </div>

  <!-- ✅ FOOTER IMAGE -->
  <?php if ($footerExists): ?>
    <div class="footer-img">
      <img src="<?= h($footerUrl) ?>" alt="Footer">
    </div>
  <?php endif; ?>

<?php endif; ?>
