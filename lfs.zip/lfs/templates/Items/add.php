<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Item $item
 * @var \Cake\Collection\CollectionInterface|string[] $users
 */
?>
<style>
body{
    background:#f8fafc;
}

.page_title{
    color:#111827 !important;
    font-weight:800;
}

.sub_title{
    color:#64748b !important;
}

.card.bg-body-tertiary{
    background:#ffffff !important;
    border:1px solid #e5e7eb !important;
}

.card.bg-body-tertiary .card-body,
.card.bg-body-tertiary .card-title{
    color:#111827 !important;
}

.table_transparent,
.table_transparent thead,
.table_transparent tbody,
.table_transparent th,
.table_transparent td{
    background:#ffffff !important;
    color:#111827 !important;
}

.table_transparent thead th{
    font-weight:800;
    border-bottom:2px solid #e5e7eb !important;
}

.table_transparent td,
.table_transparent th{
    border-color:#e5e7eb !important;
}

.table_transparent.table-hover tbody tr:hover{
    background:#f8fafc !important;
}

.table_transparent a{
    color:#111827 !important;
    text-decoration:none;
}
.table_transparent a:hover{
    text-decoration:underline;
}

.nav-tabs .nav-link{
    color:#111827 !important;
    font-weight:700;
}
.nav-tabs .nav-link.active{
    color:#0ea5e9 !important;
}

.pagination .page-link{
    color:#ffffff !important;              
    background:#111827 !important;         
    border-color:#111827 !important;
    font-weight:700;
}

.pagination .page-item.active .page-link{
    background:#0ea5e9 !important;
    border-color:#0ea5e9 !important;
    color:#ffffff !important;
}

.pagination .page-item.disabled .page-link{
    opacity:.45;
    cursor:not-allowed;
}

.card .card-title{
    color:#111827 !important;
    font-weight:800;
}
.card label{
    color:#111827 !important;
    font-weight:700;
}
.card input,
.card select,
.card textarea{
    background:#ffffff !important;
    color:#111827 !important;
    border:1px solid #cbd5e1 !important;
}
</style>

<div class="row text-body-secondary">
	<div class="col-10">
		<h1 class="my-0 page_title"><?php echo $title; ?></h1>
		<h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
	</div>
	<div class="col-2 text-end">
		<div class="dropdown mx-3 mt-2">
			<button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<i class="fa-solid fa-bars text-primary"></i>
			</button>
				<div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
            <?= $this->Html->link(__('List Items'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?>
				</div>
		</div>
    </div>
</div>
<div class="line mb-4"></div>

<div class="card rounded-0 mb-3 bg-body-tertiary border-0 shadow">
    <div class="card-body text-body-secondary">
            <?= $this->Form->create($item, ['type'=> 'file']) ?>
            <fieldset>
                <legend><?= __('Add Item') ?></legend>
                
                    <?php echo $this->Form->control('user_id', ['options' => $users]); ?>
                    <?php echo $this->Form->control('name'); ?>
                    <?php echo $this->Form->control('item_category'); ?>
                    <?php echo $this->Form->control('status'); ?>
                    <?php echo $this->Form->control('image',['type'=> 'file']); ?>
                    <?php echo $this->Form->hidden('image_dir'); ?>
                    <?php echo $this->Form->control('brand'); ?>
                    <?php echo $this->Form->control('color'); ?>
                    <?php echo $this->Form->control('lost_found_category'); ?>
                    <?php echo $this->Form->control('lost_found_date'); ?>
                    <?php echo $this->Form->control('description'); ?>
                    <?php echo $this->Form->control('location'); ?>
                    <?php echo $this->Form->control('unique_mark'); ?>
               
            </fieldset>
				<div class="text-end">
				  <?= $this->Form->button('Reset', ['type' => 'reset', 'class' => 'btn btn-outline-warning']); ?>
				  <?= $this->Form->button(__('Submit'),['type' => 'submit', 'class' => 'btn btn-outline-primary']) ?>
                </div>
        <?= $this->Form->end() ?>
    </div>
</div>