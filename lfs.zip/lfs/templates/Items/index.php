<?php
use Cake\Routing\Router;

echo $this->Html->css('select2/css/select2.css');
echo $this->Html->script('select2/js/select2.full.min.js');
echo $this->Html->css('jquery.datetimepicker.min.css');
echo $this->Html->script('jquery.datetimepicker.full.js');
echo $this->Html->script('https://cdn.jsdelivr.net/npm/apexcharts');
echo $this->Html->script('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js');

echo $this->Html->script('bootstrapModal', ['block' => 'scriptBottom']);

$type = $type ?? $this->request->getQuery('type') ?? 'lost';
$type = strtolower((string)$type);
if (!in_array($type, ['lost', 'found'], true)) {
    $type = 'lost';
}

if (!isset($_isSearch)) {
    $q = $this->request->getQueryParams();
    $qWithoutType = $q;
    unset($qWithoutType['type']);
    $_isSearch = !empty(array_filter($qWithoutType, function ($v) {
        return $v !== null && $v !== '';
    }));
}
?>

<style>
body{ background:#f8fafc; }
.page_title{ color:#111827 !important; font-weight:800; }
.sub_title{ color:#64748b !important; }
.card.bg-body-tertiary{ background:#ffffff !important; border:1px solid #e5e7eb !important; }
.card.bg-body-tertiary .card-body, .card.bg-body-tertiary .card-title{ color:#111827 !important; }

.table_transparent, .table_transparent thead, .table_transparent tbody,
.table_transparent th, .table_transparent td{
    background:#ffffff !important;
    color:#111827 !important;
}
.table_transparent thead th{
    font-weight:800;
    border-bottom:2px solid #e5e7eb !important;
    vertical-align:middle;
    white-space:nowrap;
}
.table_transparent td, .table_transparent th{ border-color:#e5e7eb !important; }
.table_transparent.table-hover tbody tr:hover{ background:#f8fafc !important; }
.table_transparent a{ color:#111827 !important; text-decoration:none; }
.table_transparent a:hover{ text-decoration:underline; }

.table-responsive{
    overflow-x:auto;
    -webkit-overflow-scrolling:touch;
}
.table_transparent td{
    vertical-align:top;
    padding:10px 12px;
    white-space:normal;
    word-break:break-word;
}
.table_transparent th{
    padding:10px 12px;
}

td.actions { white-space:nowrap; }

.nav-tabs .nav-link{ color:#111827 !important; font-weight:700; }
.nav-tabs .nav-link.active{ color:#0ea5e9 !important; }

.pagination .page-link{
    color:#ffffff !important;
    background:#111827 !important;
    border-color:#111827 !important;
    font-weight:700;
}
.pagination .page-item.active .page-link{
    background:#0ea5e9 !important;
    border-color:#0ea5e9 !important;
    color:#ffffff !important;
}
.pagination .page-item.disabled .page-link{ opacity:.45; cursor:not-allowed; }

.card .card-title{ color:#111827 !important; font-weight:800; }
.card label{ color:#111827 !important; font-weight:700; }
.card input, .card select, .card textarea{
    background:#ffffff !important;
    color:#111827 !important;
    border:1px solid #cbd5e1 !important;
}

.row.mb-5 .card {
    background: linear-gradient(135deg, #ffe4e6 0%, #fbcfe8 100%) !important;
    border: 1px solid #f9a8d4 !important;
    box-shadow: 0 10px 20px rgba(249,168,212,0.3);
    color: #111827;
    height: 100%;
}

.row.mb-5 .card-body {
    flex-grow: 1;
    font-size: 14px;
    line-height: 1.4;
}

.row.mb-5 .btn-group {
    margin-top: auto;
}

.dropdown-menu { z-index: 99999 !important; }
</style>

<div class="row text-body-secondary">
    <div class="col-10">
        <h1 class="my-0 page_title"><?= h($title ?? 'Items List') ?></h1>
        <h6 class="sub_title text-body-secondary"><?= h($system_name ?? '') ?></h6>
    </div>

    <div class="col-2 text-end">
        <div class="dropdown mx-3 mt-2">
            <button class="btn p-0 border-0" type="button" id="lostAddMenu" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa-solid fa-bars text-primary"></i>
            </button>

            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="lostAddMenu">
                <?= $this->Html->link(
                    __('<i class="fa-solid fa-plus"></i> New Item'),
                    ['controller' => 'Items', 'action' => 'add', '?' => ['type' => $type]],
                    ['class' => 'dropdown-item', 'escapeTitle' => false]
                ) ?>
            </div>
        </div>
    </div>
</div>

<div class="line mb-3"></div>

<div class="mb-3">
    <ul class="nav nav-pills align-items-center">
        <li class="nav-item">
            <a class="nav-link <?= ($type === 'lost') ? 'active' : '' ?>"
               href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'index', '?' => ['type' => 'lost']]) ?>">
                Lost
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?= ($type === 'found') ? 'active' : '' ?>"
               href="<?= $this->Url->build(['controller' => 'Items', 'action' => 'index', '?' => ['type' => 'found']]) ?>">
                Found
            </a>
        </li>
    </ul>
</div>

<div class="row mb-5">

    <?php foreach ($items as $item): ?>
        <?php
            $isItemFound = (strtolower((string)$item->lost_found_category) === 'found');

            // ✅ Use the correct PDF action depending on item type
            // Found -> foundLetter (already exists in your old code)
            // Lost  -> lostLetter (YOU NEED TO CREATE this action if you want Lost PDF)
            $pdfAction = $isItemFound ? 'foundLetter' : 'lostLetter';
        ?>

        <div class="col-md-3 mb-4">
            <div class="card h-100 d-flex flex-column">
                <?= $this->Html->image('../files/Items/image/' . $item->image, [
                    'class' => 'card-img-top',
                    'style' => 'height:400px; object-fit:cover;'
                ]); ?>

                <div class="card-body">
                    <div class="card_title"><strong>Item Name: </strong><?= h($item->name) ?></div><br/>
                    <strong>Item Category: </strong><?= h($item->item_category) ?><br/>
                    <strong>Brand: </strong><?= h($item->brand) ?><br/>
                    <strong>Color: </strong><?= h($item->color) ?><br/>
                    <strong>Lost Found Category: </strong><?= h($item->lost_found_category) ?><br/>
                    <strong>Lost Found Date: </strong><?= h($item->lost_found_date) ?><br/>
                    <strong>Description: </strong><?= h($item->description) ?><br/>
                    <strong>Unique Marks: </strong><?= h($item->unique_mark) ?><br/>
                    <strong>Location: </strong><?= h($item->location) ?><br/>
                    <strong>Status: </strong><?= h($item->status) ?><br/>
                </div>

                <div class="mt-2 d-flex justify-content-center mb-3">
                    <div class="btn-group shadow-sm" role="group">

                        <!-- VIEW -->
                        <?= $this->Html->link(
                            __('<i class="far fa-folder-open"></i>'),
                            ['action' => 'view', $item->id],
                            ['class' => 'btn btn-outline-primary btn-sm', 'escapeTitle' => false, 'title' => 'View']
                        ) ?>

                        <!-- EDIT -->
                        <?= $this->Html->link(
                            __('<i class="fa-regular fa-pen-to-square"></i>'),
                            ['action' => 'edit', $item->id, '?' => ['type' => $type]],
                            ['class' => 'btn btn-outline-warning btn-sm', 'escapeTitle' => false, 'title' => 'Edit']
                        ) ?>

                        <!-- DELETE -->
                        <?= $this->Form->postLink(
                            __('<i class="fa-regular fa-trash-can"></i>'),
                            ['action' => 'delete', $item->id],
                            [
                                'confirm' => __('Are you sure you want to delete this item?'),
                                'class' => 'btn btn-outline-danger btn-sm',
                                'escapeTitle' => false,
                                'title' => 'Delete'
                            ]
                        ) ?>

                        <!-- ✅ PDF (for BOTH lost and found items) -->
                        <?= $this->Html->link(
                            __('<i class="fa-solid fa-file-pdf"></i>'),
                            ['controller' => 'Items', 'action' => $pdfAction, $item->id],
                            [
                                'class' => 'btn btn-outline-secondary btn-sm',
                                'escapeTitle' => false,
                                'title' => $isItemFound ? 'Download Found Letter PDF' : 'Download Lost Letter PDF'
                            ]
                        ) ?>

                    </div>
                </div>

            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="modal" id="bootstrapModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <i class="fa-regular fa-circle-xmark fa-6x text-danger mb-3"></i>
                <p id="confirmMessage"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="ok">OK</button>
            </div>
        </div>
    </div>
</div>

<?php
echo $this->Html->script('https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', ['block' => 'scriptBottom']);
$this->Html->scriptStart(['block' => 'scriptBottom']);
?>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof bootstrap !== 'undefined' && bootstrap.Dropdown) {
        const btn = document.getElementById('lostAddMenu');
        if (btn) new bootstrap.Dropdown(btn);
    }
});
<?php $this->Html->scriptEnd(); ?>
