<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Item $item
 */

if ($item->lost_found_category === 'Found Item') {
    echo $this->Html->link(
        'Print / Download Letter (PDF)',
        ['controller' => 'Items', 'action' => 'foundPdf', $item->id],
        ['class' => 'btn btn-primary mb-3', 'target' => '_blank']
    );
}

$c_name = $this->request->getParam('controller');
echo $this->Html->script('bootstrapModal', ['block' => 'scriptBottom']);
?>

<style>
body{
    background:#f8fafc;
}

.page_title{
    color:#111827 !important;
    font-weight:800;
}

.sub_title{
    color:#64748b !important;
}

.card.bg-body-tertiary{
    background:#ffffff !important;
    border:1px solid #e5e7eb !important;
}

.card.bg-body-tertiary .card-body,
.card.bg-body-tertiary .card-title{
    color:#111827 !important;
}

.table_transparent,
.table_transparent thead,
.table_transparent tbody,
.table_transparent th,
.table_transparent td{
    background:#ffffff !important;
    color:#111827 !important;
}

.table_transparent thead th{
    font-weight:800;
    border-bottom:2px solid #e5e7eb !important;
}

.table_transparent td,
.table_transparent th{
    border-color:#e5e7eb !important;
}

.table_transparent.table-hover tbody tr:hover{
    background:#f8fafc !important;
}

.table_transparent a{
    color:#111827 !important;
    text-decoration:none;
}
.table_transparent a:hover{
    text-decoration:underline;
}

.nav-tabs .nav-link{
    color:#111827 !important;
    font-weight:700;
}
.nav-tabs .nav-link.active{
    color:#0ea5e9 !important;
}

.pagination .page-link{
    color:#ffffff !important;              
    background:#111827 !important;         
    border-color:#111827 !important;
    font-weight:700;
}

.pagination .page-item.active .page-link{
    background:#0ea5e9 !important;
    border-color:#0ea5e9 !important;
    color:#ffffff !important;
}

.pagination .page-item.disabled .page-link{
    opacity:.45;
    cursor:not-allowed;
}

.card .card-title{
    color:#111827 !important;
    font-weight:800;
}
.card label{
    color:#111827 !important;
    font-weight:700;
}
.card input,
.card select,
.card textarea{
    background:#ffffff !important;
    color:#111827 !important;
    border:1px solid #cbd5e1 !important;
}
</style>

<div class="row text-body-secondary">
	<div class="col-10">
		<h1 class="my-0 page_title"><?php echo $title; ?></h1>
		<h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
	</div>
	<div class="col-2 text-end">
		<div class="dropdown mx-3 mt-2">
			<button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<i class="fa-solid fa-bars text-primary"></i>
			</button>
				<div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
							<li><?= $this->Html->link(__('Edit Item'), ['action' => 'edit', $item->id], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><?= $this->Form->postLink(__('Delete Item'), ['action' => 'delete', $item->id], ['confirm' => __('Are you sure you want to delete # {0}?', $item->id), 'class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><hr class="dropdown-divider"></li>
				<li><?= $this->Html->link(__('List Items'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><?= $this->Html->link(__('New Item'), ['action' => 'add'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
							</div>
		</div>
    </div>
</div>
<div class="line mb-4"></div>

<div class="row">
	<div class="col-md-9">
		<div class="card rounded-0 mb-3 bg-body-tertiary border-0 shadow">
			<div class="card-body text-body-secondary">
                <?php echo $this->Html->image('top.png'); ?>
            <h3><?= h($item->name) ?></h3>
    <div class="table-responsive">
        <table class="table">
                <tr>
                    <th><?= __('User') ?></th>
                    <td><?= $item->hasValue('user') ? $this->Html->link($item->user->id, ['controller' => 'Users', 'action' => 'view', $item->user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($item->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Item Category') ?></th>
                    <td><?= h($item->item_category) ?></td>
                </tr>
                <tr>
                    <th><?= __('Status') ?></th>
                    <td><?= h($item->status) ?></td>
                </tr>
                <tr>
                    <th><?= __('Image') ?></th>
                    <td><?= h($item->image) ?></td>
                </tr>
                <tr>
                    <th><?= __('Image Dir') ?></th>
                    <td><?= h($item->image_dir) ?></td>
                </tr>
                <tr>
                    <th><?= __('Brand') ?></th>
                    <td><?= h($item->brand) ?></td>
                </tr>
                <tr>
                    <th><?= __('Color') ?></th>
                    <td><?= h($item->color) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lost Found Category') ?></th>
                    <td><?= h($item->lost_found_category) ?></td>
                </tr>
                <tr>
                    <th><?= __('Location') ?></th>
                    <td><?= h($item->location) ?></td>
                </tr>
                <tr>
                    <th><?= __('Unique Mark') ?></th>
                    <td><?= h($item->unique_mark) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($item->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lost Found Date') ?></th>
                    <td><?= h($item->lost_found_date) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($item->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($item->modified) ?></td>
                </tr>
            </table>
            </div>
            <div class="text">
                <strong><?= __('Description') ?></strong>
                <blockquote>
                    <?= $this->Text->autoParagraph(h($item->description)); ?>
                </blockquote>
            </div>

			</div>
		</div>
	
	</div>
	<div class="col-md-3">
	  Column
	</div>
</div>




