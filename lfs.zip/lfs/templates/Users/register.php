<?php
/**
 * User Registration Page
 * templates/Users/register.php
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($title ?? 'Register') ?> - <?= h($system_name ?? 'Lost & Found') ?></title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        *{margin:0;padding:0;box-sizing:border-box}

        body{
            font-family:'Inter',sans-serif;
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:20px;

            /* Same background as login */
            background:
                radial-gradient(circle at 20% 20%, rgba(236,72,153,.65), transparent 40%),
                radial-gradient(circle at 80% 30%, rgba(59,130,246,.65), transparent 40%),
                radial-gradient(circle at 40% 85%, rgba(168,85,247,.55), transparent 45%),
                radial-gradient(circle at 60% 50%, rgba(245,158,11,.35), transparent 50%),
                linear-gradient(135deg, #0ea5e9 0%, #ec4899 50%, #6366f1 100%);
            background-attachment: fixed;
            overflow-x:hidden;
            position:relative;
            animation: gradientShift 15s ease infinite;
        }

        @keyframes gradientShift{
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        /* Glow blobs */
        body:before, body:after{
            content:"";
            position:absolute;
            width:450px;height:450px;
            border-radius:50%;
            filter: blur(90px);
            opacity:.6;
            z-index:0;
            pointer-events:none;
            animation: float 20s ease-in-out infinite;
        }
        body:before{
            background: radial-gradient(circle, #ec4899, #f97316);
            top:-120px;
            left:-120px;
            animation-delay:0s;
        }
        body:after{
            background: radial-gradient(circle, #3b82f6, #8b5cf6);
            bottom:-140px;
            right:-140px;
            animation-delay:-10s;
        }

        @keyframes float{
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(30px, -30px) scale(1.1); }
            50% { transform: translate(-20px, 20px) scale(0.9); }
            75% { transform: translate(20px, 30px) scale(1.05); }
        }

        /* Floating particles */
        .particle{
            position:absolute;
            width:4px;
            height:4px;
            background:rgba(255,255,255,0.6);
            border-radius:50%;
            pointer-events:none;
            z-index:0;
            animation: particleFloat linear infinite;
        }
        @keyframes particleFloat{
            0%{ transform: translateY(100vh) translateX(0) scale(0); opacity:0; }
            10%{ opacity:1; }
            90%{ opacity:1; }
            100%{ transform: translateY(-100px) translateX(100px) scale(1); opacity:0; }
        }

        /* ✅ SAME SIZING FEEL AS LOGIN */
        .wrap{width:100%;max-width:420px;position:relative;z-index:1}

        /* Glass card (same as login) */
        .cardx{
            border-radius:24px;
            overflow:hidden;
            animation:slideUp .7s ease;
            position: relative;

            background: rgba(255, 255, 255, 0.12);
            border: 2px solid rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(28px) saturate(180%);
            -webkit-backdrop-filter: blur(28px) saturate(180%);
            box-shadow:
                0 8px 32px rgba(0,0,0,.25),
                0 30px 80px rgba(0,0,0,.3),
                inset 0 1px 1px rgba(255,255,255,.5),
                inset 0 -1px 1px rgba(0,0,0,.1);
        }

        /* Shimmer */
        .cardx:before{
            content:"";
            position:absolute;
            top:0;
            left:-100%;
            width:100%;
            height:100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            animation: shimmer 3s infinite;
            z-index:1;
            pointer-events:none;
        }
        @keyframes shimmer{
            0%{ left:-100%; }
            100%{ left:100%; }
        }

        @keyframes slideUp{
            from{opacity:0;transform:translateY(40px) scale(0.95)}
            to{opacity:1;transform:translateY(0) scale(1)}
        }

        /* Header sizing EXACT like login */
        .head{
            padding:28px 24px;
            text-align:center;
            position:relative;
            z-index:2;

            background: rgba(255,255,255,0.18);
            border-bottom: 1px solid rgba(255,255,255,0.25);
        }

        .icon{
            width:70px;height:70px;
            border-radius:20px;
            display:flex;align-items:center;justify-content:center;
            margin:0 auto 14px;
            font-size:2.2rem;
            position:relative;

            background: rgba(255,255,255,.22);
            border: 2px solid rgba(255,255,255,.4);
            color:#0f172a;
            box-shadow:
                0 15px 35px rgba(0,0,0,.2),
                inset 0 2px 4px rgba(255,255,255,.5);
            animation: iconPulse 3s ease-in-out infinite;
        }
        @keyframes iconPulse{
            0%, 100% { transform: scale(1); box-shadow: 0 15px 35px rgba(0,0,0,.2); }
            50% { transform: scale(1.05); box-shadow: 0 20px 45px rgba(0,0,0,.25); }
        }

        .head h1{
            font-size:1.5rem;
            font-weight:900;
            margin-bottom:6px;
            color:#0f172a;
            text-shadow: 0 2px 4px rgba(255,255,255,.5);
        }
        .head p{
            font-size:.88rem;
            margin:0;
            color:rgba(15,23,42,.75);
        }

        /* Body sizing EXACT like login + white inner panel */
        .body{
            padding:24px 24px;
            position:relative;
            z-index:2;

            background: rgba(255,255,255,0.92);
            border-top: 1px solid rgba(255,255,255,0.35);
        }

        /* Form styles matching login */
        .form-label{
            font-weight:800;
            color:#0f172a;
            margin-bottom:8px;
            font-size:.875rem;
        }

        .form-control{
            border: 1px solid #e5e7eb;
            background:#f8fafc;
            border-radius:15px;
            padding:11px 16px;
            font-size:.95rem;
            transition:all .25s ease;
            color:#0f172a;
            box-shadow:none;
        }
        .form-control::placeholder{ color:rgba(15,23,42,.5); }
        .form-control:focus{
            border-color: rgba(59,130,246,.55);
            box-shadow: 0 0 0 4px rgba(59,130,246,.12);
            background:#ffffff;
            transform: translateY(-1px);
        }

        .input-group{ position:relative; }

        .input-icon{
            position:absolute;
            left:16px;
            top:50%;
            transform:translateY(-50%);
            color:rgba(15,23,42,.55);
            font-size:1.1rem;
            z-index:5;
        }

        .input-with-icon{ padding-left:44px; }

        .password-toggle{
            position:absolute;
            right:16px;
            top:50%;
            transform:translateY(-50%);
            background:none;
            border:none;
            color:rgba(15,23,42,.6);
            cursor:pointer;
            font-size:1.1rem;
            padding:0;
            transition:all .3s ease;
            z-index:6;
        }
        .password-toggle:hover{
            color:#0f172a;
            transform:translateY(-50%) scale(1.12);
        }

        /* Buttons same height + feel as login */
        .btn-main{
            width:100%;
            border:none;
            border-radius:15px;
            font-weight:900;
            font-size:1rem;
            color:#1e293b;
            transition:all .3s ease;
            position:relative;
            overflow:hidden;

            background: linear-gradient(135deg, #a8daff 0%, #ffb3d9 50%, #d4a5ff 100%);
            box-shadow:
                0 8px 24px rgba(0,0,0,.15),
                0 16px 40px rgba(255,179,217,.25);
        }
        .btn-main:before{
            content:"";
            position:absolute;
            top:0;
            left:-100%;
            width:100%;
            height:100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,.3), transparent);
            transition:left .5s ease;
        }
        .btn-main:hover:before{ left:100%; }
        .btn-main:hover{
            transform:translateY(-2px);
            box-shadow:
                0 12px 32px rgba(0,0,0,.18),
                0 20px 50px rgba(255,179,217,.35);
        }

        .btn-outline{
            width:100%;
            border-radius:15px;
            font-weight:900;
            font-size:1rem;
            transition:all .3s ease;

            background:#f1f5f9;
            border: 1px solid #e5e7eb;
            color: rgba(15,23,42,.75);
        }
        .btn-outline:hover{
            background:#e5e7eb;
            color:#0f172a;
            transform:translateY(-1px);
        }

        /* ✅ Perfect same height */
        .btn-main,
        .btn-outline{
            height:44px;
            padding:0 16px;
            display:flex;
            align-items:center;
            justify-content:center;
            line-height:1;
        }

        /* Make register fit screen (extra content vs login) */
        .mb-3{ margin-bottom:12px !important; }

        small{
            display:block;
            margin-top:4px;
            font-size:.75rem !important;
            line-height:1.2;
            color:rgba(15,23,42,.70);
            font-weight:700;
        }

        .terms-box{
            background:#f8fafc;
            border:1px solid #e5e7eb;
            border-radius:15px;
            padding:10px 12px; /* tighter to fit */
        }

        .form-check-input{
            border-color:#cbd5e1;
            background-color:#ffffff;
            width:1.2em;height:1.2em;
            cursor:pointer;
        }
        .form-check-input:checked{
            background-color:#ffb3d9;
            border-color:#ffb3d9;
            box-shadow: 0 0 0 3px rgba(255,179,217,.25);
        }

        .links{
            text-align:center;
            margin-top:16px;
            color:rgba(15,23,42,.75);
        }
        .links a{
            color:#0f172a;
            text-decoration:none;
            font-weight:900;
            font-size:.9rem;
            position:relative;
        }
        .links a:after{
            content:"";
            position:absolute;
            bottom:-2px;
            left:0;
            width:0;
            height:2px;
            background: linear-gradient(90deg, #3b82f6, #ec4899);
            transition: width .3s ease;
        }
        .links a:hover:after{ width:100%; }

        .alert{
            border-radius:15px !important;
            border:1px solid #e5e7eb !important;
            background:#ffffff !important;
            color:#0f172a !important;
            box-shadow: 0 6px 18px rgba(0,0,0,.08) !important;
        }

        @media (max-width:576px){
            .body{ padding:20px 18px; }
            .head{ padding:24px 18px; }
            .icon{ width:64px; height:64px; font-size:2rem; }
        }
    </style>
</head>
<body>
<!-- Floating particles -->
<div class="particle" style="left: 10%; animation-duration: 15s; animation-delay: 0s;"></div>
<div class="particle" style="left: 20%; animation-duration: 18s; animation-delay: 2s;"></div>
<div class="particle" style="left: 30%; animation-duration: 20s; animation-delay: 4s;"></div>
<div class="particle" style="left: 40%; animation-duration: 16s; animation-delay: 1s;"></div>
<div class="particle" style="left: 50%; animation-duration: 19s; animation-delay: 3s;"></div>
<div class="particle" style="left: 60%; animation-duration: 17s; animation-delay: 5s;"></div>
<div class="particle" style="left: 70%; animation-duration: 21s; animation-delay: 2s;"></div>
<div class="particle" style="left: 80%; animation-duration: 16s; animation-delay: 4s;"></div>
<div class="particle" style="left: 90%; animation-duration: 18s; animation-delay: 1s;"></div>

<div class="wrap">
    <div class="cardx">

        <div class="head">
            <div class="icon">
                <i class="bi bi-person-plus"></i>
            </div>
            <h1>Create Account</h1>
            <p>Register to report and track lost items</p>
        </div>

        <div class="body">
            <?= $this->Flash->render() ?>

            <?= $this->Form->create($user, ['url' => ['controller' => 'Users', 'action' => 'register'], 'id' => 'registerForm']) ?>

                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <div class="input-group">
                        <i class="bi bi-person input-icon"></i>
                        <?= $this->Form->text('fullname', [
                            'class' => 'form-control input-with-icon',
                            'placeholder' => 'Enter your full name',
                            'required' => true,
                            'autocomplete' => 'name'
                        ]) ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <i class="bi bi-envelope input-icon"></i>
                        <?= $this->Form->text('email', [
                            'class' => 'form-control input-with-icon',
                            'placeholder' => 'Enter your email',
                            'required' => true,
                            'type' => 'email',
                            'autocomplete' => 'email'
                        ]) ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <i class="bi bi-lock input-icon"></i>
                        <?= $this->Form->password('password', [
                            'class' => 'form-control input-with-icon',
                            'placeholder' => 'Create a password',
                            'required' => true,
                            'id' => 'passwordField',
                            'autocomplete' => 'new-password'
                        ]) ?>
                        <button type="button" class="password-toggle" onclick="togglePassword('passwordField','toggleIcon1')">
                            <i class="bi bi-eye" id="toggleIcon1"></i>
                        </button>
                    </div>
                    <small>Use at least 6–8 characters.</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <div class="input-group">
                        <i class="bi bi-shield-lock input-icon"></i>
                        <?= $this->Form->password('confirm_password', [
                            'class' => 'form-control input-with-icon',
                            'placeholder' => 'Re-enter your password',
                            'required' => true,
                            'id' => 'confirmField',
                            'autocomplete' => 'new-password'
                        ]) ?>
                        <button type="button" class="password-toggle" onclick="togglePassword('confirmField','toggleIcon2')">
                            <i class="bi bi-eye" id="toggleIcon2"></i>
                        </button>
                    </div>
                </div>

                <div class="terms-box mb-3">
                    <div class="form-check">
                        <?= $this->Form->checkbox('terms', [
                            'class' => 'form-check-input',
                            'id' => 'termsCheck',
                            'value' => 1
                        ]) ?>
                        <label class="form-check-label" for="termsCheck" style="font-size:0.9rem;color:rgba(15,23,42,.75);font-weight:700;">
                            I agree to the Terms &amp; Conditions and Privacy Policy.
                        </label>
                    </div>
                </div>

                <div class="row g-2">
                    <div class="col-4">
                        <?= $this->Form->button('Reset', ['type' => 'reset', 'class' => 'btn-outline']) ?>
                    </div>
                    <div class="col-8">
                        <?= $this->Form->button('Create Account', ['type' => 'submit', 'class' => 'btn-main']) ?>
                    </div>
                </div>

            <?= $this->Form->end() ?>

            <div class="links">
                Already have an account?
                <a href="<?= $this->Url->build(['controller' => 'Users', 'action' => 'login']) ?>">Sign In</a>
            </div>

        </div>
    </div>

    <div class="text-center mt-4" style="color: rgba(255,255,255,.9); font-size: 0.85rem; position:relative; z-index:1;">
        <p class="mb-2">Lost &amp; Found System</p>
    </div>
</div>

<script>
function togglePassword(fieldId, iconId) {
    const field = document.getElementById(fieldId);
    const icon = document.getElementById(iconId);

    if (!field || !icon) return;

    if (field.type === 'password') {
        field.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
    } else {
        field.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
    }
}
</script>
</body>
</html>