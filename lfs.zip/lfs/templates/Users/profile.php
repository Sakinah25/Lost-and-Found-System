<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 * @var string $title
 * @var string $system_name
 */

use Cake\I18n\FrozenTime;

// CSS (load into layout head)
$this->Html->css('select2/css/select2.css', ['block' => true]);

// JS (load into layout bottom)
$this->Html->script('select2/js/select2.full.min.js', ['block' => 'scriptBottom']);
$this->Html->script('qr-code-styling-1-5-0.min.js', ['block' => 'scriptBottom']);
$this->Html->script('bootstrapModal', ['block' => 'scriptBottom']);

// Helpers
$fullname = h($user->fullname);
$email    = h($user->email);
$group    = isset($user->user_group) ? h($user->user_group->name) : '-';

$createdOn = !empty($user->created) ? date('M d, Y (h:i A)', strtotime((string)$user->created)) : '-';
$archivedOn = !empty($user->modified) ? date('M d, Y (h:i A)', strtotime((string)$user->modified)) : '-';

$avatarUrl = 'blank_profile.png';
if (!empty($user->avatar)) {
    $avatarUrl = '../files/Users/avatar/' . h($user->slug) . '/' . h($user->avatar);
}

$statusBadge = '<span class="badge bg-secondary">Archived</span>';
if ((int)$user->status === 1) {
    $statusBadge = '<span class="badge bg-success">Active</span>';
} elseif ((int)$user->status === 0) {
    $statusBadge = '<span class="badge bg-danger">Disabled</span>';
}

$verifiedBadge = ((int)$user->is_email_verified === 1)
    ? '<span class="badge bg-success">Verified</span>'
    : '<span class="badge bg-danger">Not verified</span>';

// Current page URL for QR
$currentUrl = (string)$this->request->getUri();
?>

<!-- Header -->
<div class="row text-body-secondary">
    <div class="col-10">
        <h1 class="my-0 page_title"><?= h($title) ?></h1>
        <h6 class="sub_title text-body-secondary"><?= h($system_name) ?></h6>
    </div>

    <div class="col-2 text-end">
        <div class="btn-group bg-transparent">
            <?= $this->Form->button(
                '<i class="fa-solid fa-arrow-left text-primary"></i>',
                [
                    'type' => 'button',
                    'onclick' => 'history.back()',
                    'escapeTitle' => false,
                    'class' => 'btn border-0'
                ]
            ) ?>

            <button type="button" class="btn border-0" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa-solid fa-bars text-primary"></i>
            </button>

            <ul class="dropdown-menu">
                <li>
                    <?= $this->Html->link(
                        __('<i class="fa-solid fa-plus"></i> Register New User'),
                        ['action' => 'registration'],
                        ['class' => 'dropdown-item', 'escapeTitle' => false]
                    ) ?>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="line mb-4"></div>
<!-- /Header -->

<div class="row mt-3">
    <!-- Left Column -->
    <div class="col-md-8">
        <ul class="nav nav-pills flex-column flex-md-row mb-3">
            <li class="nav-item">
                <?= $this->Html->link(
                    __('<i class="fa-solid fa-user-astronaut"></i> Account'),
                    ['action' => 'profile', $user->slug],
                    ['class' => 'nav-link active', 'escapeTitle' => false]
                ) ?>
            </li>
            <li class="nav-item">
                <?= $this->Html->link(
                    __('<i class="fa-regular fa-pen-to-square"></i> Update'),
                    ['action' => 'update', $user->slug],
                    ['class' => 'nav-link', 'escapeTitle' => false]
                ) ?>
            </li>
            <li class="nav-item">
                <?= $this->Html->link(
                    __('<i class="fa-solid fa-unlock"></i> Password'),
                    ['action' => 'change_password', $user->slug],
                    ['class' => 'nav-link', 'escapeTitle' => false]
                ) ?>
            </li>
            <li class="nav-item">
                <?= $this->Html->link(
                    __('<i class="fa-solid fa-cubes-stacked"></i> Activities'),
                    ['action' => 'activity', $user->slug],
                    ['class' => 'nav-link', 'escapeTitle' => false]
                ) ?>
            </li>
            <li class="nav-item">
                <?= $this->Html->link(
                    __('<i class="fa-solid fa-timeline"></i> Audit Trail'),
                    ['action' => 'audit_trail', $user->slug],
                    ['class' => 'nav-link', 'escapeTitle' => false]
                ) ?>
            </li>
            <li class="nav-item">
                <?= $this->Html->link(
                    __('<i class="fa-regular fa-file-pdf"></i> PDF'),
                    ['action' => 'pdf_profile', $user->slug],
                    ['class' => 'nav-link', 'escapeTitle' => false]
                ) ?>
            </li>
        </ul>

        <div class="card bg-body-tertiary border-0 shadow mb-4">
            <div class="card bg-gold">
                <div class="p-3">
                    <?= $this->Html->image($avatarUrl, [
                        'class' => 'd-block rounded shadow',
                        'width' => '130',
                        'height' => '130',
                        'alt' => 'User Avatar'
                    ]) ?>
                </div>
            </div>

            <div class="row px-3 py-3">
                <div class="col-md-9">
                    <div class="table-responsive">
                        <table class="table table-sm table-borderless mb-0 table_transparent table-hover">
                            <tr>
                                <th width="20%">Name</th>
                                <td><?= $fullname ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?= $email ?></td>
                            </tr>
                            <tr>
                                <th>Group</th>
                                <td><?= $group ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?= $statusBadge ?></td>
                            </tr>
                            <tr>
                                <th>Verified</th>
                                <td><?= $verifiedBadge ?></td>
                            </tr>
                            <tr>
                                <th>Created on</th>
                                <td><?= h($createdOn) ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="col-md-3 ms-0 text-center">
                    <div id="qr" class="d-flex justify-content-center"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Column -->
    <div class="col-md-4">
        <div class="card bg-body-tertiary border-0 shadow mb-4">
            <div class="card-body">
                <div class="card-title mb-0">Account Management</div>
                <div class="tricolor_line mb-3"></div>

                <?php
                // Use modal confirm template
                $this->Form->setTemplates([
                    'confirmJs' => 'addToModal("{{formName}}"); return false;'
                ]);
                ?>

                <?php if ((int)$user->status === 0 || (int)$user->status === 1) : ?>
                    <div class="mb-3 col-12 mb-0">
                        <div class="alert alert-warning">
                            <div class="fw-semibold">Delete Account</div>
                            <p class="mb-0">Once you deactivate <?= $fullname ?> account, there is no going back. Please be certain.</p>

                            <div class="text-end">
                                <?= $this->Form->postLink(
                                    __('<i class="fa-regular fa-trash-can"></i> Delete'),
                                    ['action' => 'delete', $user->id],
                                    [
                                        'confirm' => __('Are you sure you want to delete user: "{0}"?', $user->fullname),
                                        'title' => __('Delete'),
                                        // If you truly want it disabled, keep this line. Otherwise remove it.
                                        'disabled' => 'disabled',
                                        'class' => 'btn btn-danger btn-xs',
                                        'escapeTitle' => false,
                                        'data-bs-toggle' => 'modal',
                                        'data-bs-target' => '#bootstrapModal'
                                    ]
                                ) ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ((int)$user->status === 0) : ?>
                    <div class="mb-3 col-12 mb-0">
                        <div class="alert alert-warning">
                            <div class="fw-semibold">Activate Account</div>
                            <p class="mb-0">Are you sure you want to activate <?= $fullname ?> account?</p>

                            <div class="text-end mb-2">
                                <?= $this->Form->postLink(
                                    __('Activate'),
                                    ['action' => 'activate', $user->slug],
                                    [
                                        'confirm' => __('Are you sure you want to activate user: "{0}"?', $user->fullname),
                                        'title' => __('Activate'),
                                        'class' => 'btn btn-success btn-xs',
                                        'escapeTitle' => false,
                                        'data-bs-toggle' => 'modal',
                                        'data-bs-target' => '#bootstrapModal'
                                    ]
                                ) ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ((int)$user->status === 1) : ?>
                    <div class="mb-3 col-12 mb-0">
                        <div class="alert alert-warning">
                            <div class="fw-semibold">Disable Account</div>
                            <p class="mb-0">Are you sure you want to disable <?= $fullname ?> account?</p>

                            <div class="text-end">
                                <?= $this->Form->postLink(
                                    __('Disable'),
                                    ['action' => 'disable', $user->slug],
                                    [
                                        'confirm' => __('Are you sure you want to Disable user: "{0}"?', $user->fullname),
                                        'title' => __('Disable'),
                                        'class' => 'btn btn-danger btn-xs',
                                        'escapeTitle' => false,
                                        'data-bs-toggle' => 'modal',
                                        'data-bs-target' => '#bootstrapModal'
                                    ]
                                ) ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ((int)$user->is_email_verified === 0) : ?>
                    <div class="mb-3 col-12 mb-0">
                        <div class="alert alert-warning">
                            <div class="fw-semibold">Verify Account</div>
                            <p class="mb-0">This step will manually verify the registered account without validating the email address. Please be certain.</p>

                            <div class="text-end">
                                <?= $this->Form->postLink(
                                    __('Verify'),
                                    ['action' => 'admin_verify', $user->slug],
                                    [
                                        'confirm' => __('Are you sure you want to verify user: "{0}"?', $user->fullname),
                                        'title' => __('Verify'),
                                        'class' => 'btn btn-success btn-xs',
                                        'escapeTitle' => false,
                                        'data-bs-toggle' => 'modal',
                                        'data-bs-target' => '#bootstrapModal'
                                    ]
                                ) ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ((int)$user->status === 0 || (int)$user->status === 1) : ?>
                    <div class="mb-3 col-12 mb-0">
                        <div class="alert alert-warning">
                            <div class="fw-semibold">Archived Account</div>
                            <p class="mb-0">This step will transfer the account to archived. Once archived, it will remain and cannot be reverted. Please be certain.</p>

                            <div class="text-end">
                                <?= $this->Form->postLink(
                                    __('Archived'),
                                    ['action' => 'archived', $user->slug],
                                    [
                                        'confirm' => __('Are you sure you want to archived user: "{0}"?', $user->fullname),
                                        'title' => __('Archived'),
                                        'class' => 'btn btn-success btn-xs',
                                        'escapeTitle' => false,
                                        'data-bs-toggle' => 'modal',
                                        'data-bs-target' => '#bootstrapModal'
                                    ]
                                ) ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ((int)$user->status === 2) : ?>
                    <div class="text-body-secondary">
                        This account has been archived on <?= h($archivedOn) ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal" id="bootstrapModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <i class="fa-regular fa-circle-xmark fa-6x text-danger mb-3"></i>
                <p id="confirmMessage" class="mb-0"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="ok">OK</button>
            </div>
        </div>
    </div>
</div>

<?php $this->Html->scriptStart(['block' => 'scriptBottom']); ?>
$(document).ready(function () {
    // Select2
    $(".input select").select2();

    // QR
    const qrEl = document.getElementById("qr");
    if (qrEl) {
        const qrCode = new QRCodeStyling({
            width: 130,
            height: 130,
            margin: 0,
            data: <?= json_encode($currentUrl) ?>,
            dotsOptions: { type: "dots" },
            cornersSquareOptions: { type: "dots", color: "#007bff" },
            cornersDotOptions: { type: "dots" },
            imageOptions: { crossOrigin: "anonymous", margin: 20 }
        });

        qrCode.append(qrEl);
    }
});
<?php $this->Html->scriptEnd(); ?>