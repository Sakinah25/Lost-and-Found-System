<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($title ?? 'Login') ?> - <?= h($system_name ?? 'Lost & Found') ?></title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{
            font-family:'Inter',sans-serif;
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:20px;

            /* Enhanced gradient background */
            background:
                radial-gradient(circle at 20% 20%, rgba(236,72,153,.65), transparent 40%),
                radial-gradient(circle at 80% 30%, rgba(59,130,246,.65), transparent 40%),
                radial-gradient(circle at 40% 85%, rgba(168,85,247,.55), transparent 45%),
                radial-gradient(circle at 60% 50%, rgba(245,158,11,.35), transparent 50%),
                linear-gradient(135deg, #0ea5e9 0%, #ec4899 50%, #6366f1 100%);
            background-attachment: fixed;
            overflow-x:hidden;
            position:relative;
            animation: gradientShift 15s ease infinite;
        }

        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        /* Enhanced glow blobs with animation */
        body:before, body:after{
            content:"";
            position:absolute;
            width:450px;height:450px;
            border-radius:50%;
            filter: blur(90px);
            opacity:.6;
            z-index:0;
            pointer-events:none;
            animation: float 20s ease-in-out infinite;
        }
        body:before{ 
            background: radial-gradient(circle, #ec4899, #f97316); 
            top:-120px; 
            left:-120px;
            animation-delay: 0s;
        }
        body:after { 
            background: radial-gradient(circle, #3b82f6, #8b5cf6); 
            bottom:-140px; 
            right:-140px;
            animation-delay: -10s;
        }

        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(30px, -30px) scale(1.1); }
            50% { transform: translate(-20px, 20px) scale(0.9); }
            75% { transform: translate(20px, 30px) scale(1.05); }
        }

        /* Floating particles */
        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(255,255,255,0.6);
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
            animation: particleFloat linear infinite;
        }

        @keyframes particleFloat {
            0% {
                transform: translateY(100vh) translateX(0) scale(0);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100px) translateX(100px) scale(1);
                opacity: 0;
            }
        }

        .login-container{width:100%;max-width:420px;position:relative;z-index:1}

        /* Enhanced Glass / mirror card */
        .login-card{
            border-radius:24px;
            overflow:hidden;
            animation:slideUp .7s ease;
            position: relative;

            background: rgba(255, 255, 255, 0.12);
            border: 2px solid rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(28px) saturate(180%);
            -webkit-backdrop-filter: blur(28px) saturate(180%);
            box-shadow: 
                0 8px 32px rgba(0,0,0,.25),
                0 30px 80px rgba(0,0,0,.3),
                inset 0 1px 1px rgba(255,255,255,.5),
                inset 0 -1px 1px rgba(0,0,0,.1);
        }

        /* Shimmer effect on card */
        .login-card:before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            animation: shimmer 3s infinite;
            z-index: 1;
            pointer-events: none;
        }

        @keyframes shimmer {
            0% { left: -100%; }
            100% { left: 100%; }
        }

        @keyframes slideUp{
            from{opacity:0;transform:translateY(40px) scale(0.95)}
            to{opacity:1;transform:translateY(0) scale(1)}
        }

        .login-header{
            padding:28px 24px;
            text-align:center;
            position: relative;
            z-index: 2;

            background: rgba(255,255,255,0.18);
            border-bottom: 1px solid rgba(255,255,255,0.25);
        }
        
        .logo-icon{
            width:70px;height:70px;
            border-radius:20px;
            display:flex;align-items:center;justify-content:center;
            margin:0 auto 14px;
            font-size:2.2rem;
            position: relative;

            background: rgba(255,255,255,.22);
            border: 2px solid rgba(255,255,255,.4);
            color:#0f172a;
            box-shadow: 
                0 15px 35px rgba(0,0,0,.2),
                inset 0 2px 4px rgba(255,255,255,.5);
            animation: iconPulse 3s ease-in-out infinite;
        }

        @keyframes iconPulse {
            0%, 100% { transform: scale(1); box-shadow: 0 15px 35px rgba(0,0,0,.2); }
            50% { transform: scale(1.05); box-shadow: 0 20px 45px rgba(0,0,0,.25); }
        }

        .logo-icon i {
            animation: iconRotate 4s ease-in-out infinite;
        }

        @keyframes iconRotate {
            0%, 100% { transform: rotate(0deg); }
            50% { transform: rotate(5deg); }
        }

        .login-header h1{
            font-size:1.5rem;
            font-weight:900;
            margin-bottom:6px;
            color:#0f172a;
            text-shadow: 0 2px 4px rgba(255,255,255,.5);
            animation: fadeInDown 0.8s ease 0.2s both;
        }
        
        .login-header p{
            font-size:.88rem;
            margin:0;
            color:rgba(15,23,42,.75);
            animation: fadeInDown 0.8s ease 0.3s both;
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .login-body{
            padding:24px 24px;
            position: relative;
            z-index: 2;

            background: rgba(255,255,255,0.92);
            border-top: 1px solid rgba(255,255,255,0.35);
        }

        /* Enhanced Switch */
        .switch-wrap{
            background:#f8fafc;
            border: 1px solid #e5e7eb;
            border-radius:16px;
            padding:7px;
            display:flex;
            gap:7px;
            position:relative;
            margin-bottom:18px;
            box-shadow: 0 2px 6px rgba(0,0,0,.05);
        }
        
        .switch-btn{
            flex:1;
            border:none;
            background:transparent;
            padding:11px 14px;
            font-weight:900;
            font-size:.9rem;
            color:rgba(15,23,42,.65);
            border-radius:13px;
            z-index:2;
            transition:all .3s ease;
            display:flex;align-items:center;justify-content:center;gap:8px;
            cursor: pointer;
        }

        .switch-btn:hover {
            color:rgba(15,23,42,.85);
        }

        .switch-indicator{
            position:absolute;
            top:7px; bottom:7px;
            width:calc(50% - 7px);
            left:7px;
            border-radius:13px;

            background:#ffffff;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 8px rgba(0,0,0,.1);
            transition:all .35s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .switch-wrap[data-mode="admin"] .switch-indicator{ 
            left: calc(50% + 0px);
        }
        
        .switch-wrap[data-mode="user"]  #btnUser,
        .switch-wrap[data-mode="admin"] #btnAdmin{
            color:#0f172a;
        }

        /* Enhanced Form */
        .form-label{
            font-weight:800;
            color:#0f172a;
            margin-bottom:8px;
            font-size:.875rem;
        }

        .form-control{
            border: 1px solid #e5e7eb;
            background:#f8fafc;
            border-radius:15px;
            padding:11px 16px;
            font-size:.95rem;
            transition:all .25s ease;
            color:#0f172a;
            box-shadow: none;
        }
        
        .form-control::placeholder{
            color:rgba(15,23,42,.5);
        }
        
        .form-control:focus{
            border-color: rgba(59,130,246,.55);
            box-shadow: 0 0 0 4px rgba(59,130,246,.12);
            background:#ffffff;
            transform: translateY(-1px);
        }

        .input-group{
            position:relative;
            animation: fadeInUp 0.6s ease both;
        }

        .mb-3:nth-child(1) .input-group { animation-delay: 0.1s; }
        .mb-3:nth-child(2) .input-group { animation-delay: 0.2s; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .input-icon{
            position:absolute;
            left:16px;
            top:50%;
            transform:translateY(-50%);
            color:rgba(15,23,42,.55);
            font-size:1.1rem;
            z-index:5;
            transition: all .3s ease;
        }

        .form-control:focus ~ .input-icon {
            color:rgba(15,23,42,.85);
            transform: translateY(-50%) scale(1.1);
        }

        .input-with-icon{padding-left:44px}

        .password-toggle{
            position:absolute;
            right:16px;
            top:50%;
            transform:translateY(-50%);
            background:none;
            border:none;
            color:rgba(15,23,42,.6);
            cursor:pointer;
            font-size:1.1rem;
            padding:0;
            transition:all .3s ease;
            z-index:6;
        }
        
        .password-toggle:hover{
            color:#0f172a;
            transform:translateY(-50%) scale(1.12);
        }

        /* Enhanced Buttons */
        .btn-login{
            width:100%;
            border:none;
            border-radius:15px;
            padding:13px;
            font-weight:900;
            font-size:1rem;
            color:#1e293b;
            transition:all .3s ease;
            position: relative;
            overflow: hidden;

            background: linear-gradient(135deg, #a8daff 0%, #ffb3d9 50%, #d4a5ff 100%);
            box-shadow: 
                0 8px 24px rgba(0,0,0,.15),
                0 16px 40px rgba(255,179,217,.25);
        }

        .btn-login:before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,.3), transparent);
            transition: left .5s ease;
        }

        .btn-login:hover:before {
            left: 100%;
        }

        .btn-login:hover{
            transform:translateY(-2px);
            box-shadow:
                0 12px 32px rgba(0,0,0,.18),
                0 20px 50px rgba(255,179,217,.35);
        }

        .btn-login:active {
            transform:translateY(0);
        }

        .btn-reset{
            width:100%;
            border-radius:15px;
            padding:13px;
            font-weight:900;
            font-size:1rem;
            transition:all .3s ease;

            background:#f1f5f9;
            border: 1px solid #e5e7eb;
            color: rgba(15,23,42,.75);
        }
        
        .btn-reset:hover{
            background:#e5e7eb;
            color:#0f172a;
            transform:translateY(-1px);
        }

        /* Button height consistency */
        .btn-login,
        .btn-reset{
            height:44px;
            padding:0 16px;
            display:flex;
            align-items:center;
            justify-content:center;
            line-height:1;
        }

        .links{
            text-align:center;
            margin-top:16px;
            color:rgba(15,23,42,.75);
            animation: fadeIn 1s ease 0.5s both;
        }
        
        .links a{
            color:#0f172a;
            text-decoration:none;
            font-weight:900;
            font-size:.9rem;
            transition: all .3s ease;
            position: relative;
        }

        .links a:after {
            content: "";
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(90deg, #3b82f6, #ec4899);
            transition: width .3s ease;
        }

        .links a:hover:after {
            width: 100%;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Panels with transition */
        .panel{
            display:none;
            animation: panelFadeIn 0.4s ease;
        }
        
        .panel.active{display:block}

        @keyframes panelFadeIn {
            from { opacity: 0; transform: scale(0.98); }
            to { opacity: 1; transform: scale(1); }
        }

        /* Enhanced Flash message */
        .alert{
            border-radius:15px !important;
            border:1px solid #e5e7eb !important;
            background: #ffffff !important;
            color:#0f172a !important;
            box-shadow: 0 6px 18px rgba(0,0,0,.08) !important;
            animation: alertSlideIn 0.5s ease;
        }

        @keyframes alertSlideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width:576px){
            .login-body{padding:20px 18px}
            .login-header{padding:24px 18px}
            .logo-icon{width:64px;height:64px;font-size:2rem}
        }
    </style>
</head>
<body>
<!-- Floating particles -->
<div class="particle" style="left: 10%; animation-duration: 15s; animation-delay: 0s;"></div>
<div class="particle" style="left: 20%; animation-duration: 18s; animation-delay: 2s;"></div>
<div class="particle" style="left: 30%; animation-duration: 20s; animation-delay: 4s;"></div>
<div class="particle" style="left: 40%; animation-duration: 16s; animation-delay: 1s;"></div>
<div class="particle" style="left: 50%; animation-duration: 19s; animation-delay: 3s;"></div>
<div class="particle" style="left: 60%; animation-duration: 17s; animation-delay: 5s;"></div>
<div class="particle" style="left: 70%; animation-duration: 21s; animation-delay: 2s;"></div>
<div class="particle" style="left: 80%; animation-duration: 16s; animation-delay: 4s;"></div>
<div class="particle" style="left: 90%; animation-duration: 18s; animation-delay: 1s;"></div>

<div class="login-container">
    <div class="login-card">

        <div class="login-header">
            <div class="logo-icon">
                <i class="bi bi-box-seam"></i>
            </div>
            <h1>Sign In</h1>
            <p>Choose your account type to continue</p>
        </div>

        <div class="login-body">
            <?= $this->Flash->render() ?>

            <!-- Slide Switch -->
            <div class="switch-wrap" id="switchWrap" data-mode="user">
                <div class="switch-indicator"></div>
                <button type="button" class="switch-btn" id="btnUser" onclick="setMode('user')">
                    <i class="bi bi-person-circle"></i> User
                </button>
                <button type="button" class="switch-btn" id="btnAdmin" onclick="setMode('admin')">
                    <i class="bi bi-shield-lock-fill"></i> Admin
                </button>
            </div>

            <!-- USER FORM -->
            <div class="panel active" id="panelUser">
                <?= $this->Form->create(null, ['url' => ['controller' => 'Users', 'action' => 'login'], 'id' => 'userLoginForm']) ?>

                    <div class="mb-3">
                        <label class="form-label">User Email</label>
                        <div class="input-group">
                            <i class="bi bi-envelope input-icon"></i>
                            <?= $this->Form->text('email', [
                                'class' => 'form-control input-with-icon',
                                'placeholder' => 'Enter your email',
                                'required' => true,
                                'type' => 'email',
                                'autocomplete' => 'username'
                            ]) ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">User Password</label>
                        <div class="input-group">
                            <i class="bi bi-lock input-icon"></i>
                            <?= $this->Form->password('password', [
                                'class' => 'form-control input-with-icon',
                                'placeholder' => 'Enter your password',
                                'required' => true,
                                'id' => 'passwordUser',
                                'autocomplete' => 'current-password'
                            ]) ?>
                            <button type="button" class="password-toggle" onclick="togglePassword('passwordUser','iconUser')">
                                <i class="bi bi-eye" id="iconUser"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span style="font-size: 0.85rem; color:rgba(15,23,42,.65); font-weight:800;">User Portal</span>
                    </div>

                    <div class="row g-2">
                        <div class="col-4">
                            <?= $this->Form->button('Reset', ['type' => 'reset', 'class' => 'btn-reset']) ?>
                        </div>
                        <div class="col-8">
                            <?= $this->Form->button('Sign In', ['type' => 'submit', 'class' => 'btn-login']) ?>
                        </div>
                    </div>

                <?= $this->Form->end() ?>

                <div class="links">
                    Don't have an account?
                    <a href="<?= $this->Url->build(['controller' => 'Users', 'action' => 'register']) ?>">Register Now</a>
                </div>
            </div>

            <!-- ADMIN FORM -->
            <div class="panel" id="panelAdmin">
                <?= $this->Form->create(null, ['url' => ['controller' => 'Users', 'action' => 'adminLogin'], 'id' => 'adminLoginForm']) ?>

                    <div class="mb-3">
                        <label class="form-label">Admin Email</label>
                        <div class="input-group">
                            <i class="bi bi-envelope input-icon"></i>
                            <?= $this->Form->text('email', [
                                'class' => 'form-control input-with-icon',
                                'placeholder' => 'Enter admin email',
                                'required' => true,
                                'type' => 'email',
                                'autocomplete' => 'username'
                            ]) ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Admin Password</label>
                        <div class="input-group">
                            <i class="bi bi-lock input-icon"></i>
                            <?= $this->Form->password('password', [
                                'class' => 'form-control input-with-icon',
                                'placeholder' => 'Enter admin password',
                                'required' => true,
                                'id' => 'passwordAdmin',
                                'autocomplete' => 'current-password'
                            ]) ?>
                            <button type="button" class="password-toggle" onclick="togglePassword('passwordAdmin','iconAdmin')">
                                <i class="bi bi-eye" id="iconAdmin"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span style="font-size: 0.85rem; color:rgba(15,23,42,.65); font-weight:800;">Admin Portal</span>
                    </div>

                    <div class="row g-2">
                        <div class="col-4">
                            <?= $this->Form->button('Reset', ['type' => 'reset', 'class' => 'btn-reset']) ?>
                        </div>
                        <div class="col-8">
                            <?= $this->Form->button('Admin Sign In', ['type' => 'submit', 'class' => 'btn-login']) ?>
                        </div>
                    </div>

                <?= $this->Form->end() ?>

                <div class="links">
                    Go back to
                    <a href="javascript:void(0)" onclick="setMode('user')">User Login</a>
                </div>
            </div>

        </div>
    </div>

    <div class="text-center mt-4" style="color: rgba(255,255,255,.9); font-size: 0.85rem; position:relative; z-index:1;">
    </div>
</div>

<script>
function setMode(mode) {
    const wrap = document.getElementById('switchWrap');
    const userPanel = document.getElementById('panelUser');
    const adminPanel = document.getElementById('panelAdmin');

    wrap.setAttribute('data-mode', mode);

    if (mode === 'admin') {
        userPanel.classList.remove('active');
        adminPanel.classList.add('active');
    } else {
        adminPanel.classList.remove('active');
        userPanel.classList.add('active');
    }
}

function togglePassword(fieldId, iconId) {
    const field = document.getElementById(fieldId);
    const icon = document.getElementById(iconId);

    if (!field || !icon) return;

    if (field.type === 'password') {
        field.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
    } else {
        field.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
    }
}
</script>
</body>
</html>
