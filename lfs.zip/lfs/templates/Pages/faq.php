<?php
// templates/Pages/faq.php
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
    :root{
        --primary:#0ea5e9;
        --primary-dark:#0284c7;
        --primary-light:#38bdf8;
        --text:#111827;
        --muted:#64748b;
        --border:#e2e8f0;
        --bg:#f8fafc;
        --success:#10b981;
        --warning:#f59e0b;
    }

    .faq-wrap{
        max-width: 1100px;
        margin: auto;
    }

    .faq-hero{
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        border-radius: 24px;
        padding: 48px 36px;
        color: #fff;
        box-shadow: 0 20px 60px rgba(14,165,233,.3);
        position: relative;
        overflow: hidden;
        margin-bottom: 32px;
    }
    .faq-hero::before{
        content:'';
        position:absolute;
        top:-60%;
        right:-25%;
        width:520px;
        height:520px;
        background: radial-gradient(circle, rgba(255,255,255,0.22) 0%, transparent 70%);
        animation: pulse 8s ease-in-out infinite;
    }
    @keyframes pulse {
        0%, 100% { transform: scale(1); opacity: 0.22; }
        50% { transform: scale(1.1); opacity: 0.28; }
    }
    .faq-hero h3{
        font-size: 2.2rem;
        font-weight: 900;
        letter-spacing: -0.02em;
        margin: 0 0 12px 0;
    }
    .faq-hero p{
        margin: 0;
        opacity: .95;
        font-weight: 500;
        font-size: 1.1rem;
    }
    .faq-hero .faq-hero-icon{
        width: 80px;
        height: 80px;
        border-radius: 20px;
        background: rgba(255,255,255,.95);
        display:flex;
        align-items:center;
        justify-content:center;
        color: var(--primary);
        font-size: 2.2rem;
        box-shadow: 0 12px 32px rgba(0,0,0,.2);
        animation: float 3s ease-in-out infinite;
    }
    @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }

    .faq-stats{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 32px;
    }
    .faq-stat-card{
        background: #fff;
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,.05);
        transition: transform .3s ease, box-shadow .3s ease;
    }
    .faq-stat-card:hover{
        transform: translateY(-4px);
        box-shadow: 0 12px 28px rgba(0,0,0,.12);
    }
    .faq-stat-card .stat-icon{
        width: 48px;
        height: 48px;
        margin: 0 auto 12px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }
    .faq-stat-card.stat-lost .stat-icon{
        background: rgba(239,68,68,.1);
        color: #dc2626;
    }
    .faq-stat-card.stat-found .stat-icon{
        background: rgba(16,185,129,.1);
        color: var(--success);
    }
    .faq-stat-card.stat-claimed .stat-icon{
        background: rgba(14,165,233,.1);
        color: var(--primary);
    }
    .faq-stat-card h4{
        font-size: 2rem;
        font-weight: 900;
        margin: 0;
        color: var(--text);
    }
    .faq-stat-card p{
        margin: 4px 0 0;
        font-weight: 700;
        color: var(--muted);
        font-size: 0.9rem;
    }

    .faq-tools{
        display:flex;
        gap: 12px;
        flex-wrap: wrap;
        margin: 0 0 24px;
    }

    .faq-search{
        flex: 1;
        min-width: 280px;
        background: #fff;
        border: 2px solid var(--border);
        border-radius: 16px;
        padding: 14px 18px;
        display:flex;
        align-items:center;
        gap: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,.06);
        transition: all .3s ease;
    }
    .faq-search:focus-within{
        border-color: var(--primary);
        box-shadow: 0 8px 24px rgba(14,165,233,.18);
        transform: translateY(-2px);
    }
    .faq-search i{ 
        color: var(--muted);
        font-size: 1.2rem;
        transition: color .3s;
    }
    .faq-search:focus-within i{
        color: var(--primary);
    }
    .faq-search input{
        border: none;
        outline: none;
        width: 100%;
        font-weight: 600;
        color: var(--text);
        background: transparent;
        font-size: 1rem;
    }
    .faq-search input::placeholder{
        color: #94a3b8;
        font-weight: 600;
    }
    .faq-search-clear{
        cursor: pointer;
        color: var(--muted);
        display: none;
        transition: color .2s;
    }
    .faq-search-clear:hover{
        color: #ef4444;
    }
    .faq-search-clear.show{
        display: block;
    }

    .faq-chip{
        border: 2px solid var(--border);
        background:#fff;
        border-radius: 999px;
        padding: 11px 18px;
        font-weight: 700;
        font-size: 0.9rem;
        color: var(--muted);
        cursor: pointer;
        transition: all .25s ease;
        box-shadow: 0 4px 12px rgba(0,0,0,.05);
        user-select: none;
        position: relative;
    }
    .faq-chip:hover{
        transform: translateY(-3px);
        border-color: rgba(14,165,233,.4);
        color: var(--primary-dark);
        box-shadow: 0 12px 28px rgba(14,165,233,.16);
    }
    .faq-chip.active{
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        color:#fff;
        border-color: transparent;
        box-shadow: 0 8px 20px rgba(14,165,233,.3);
    }
    .faq-chip .badge{
        position: absolute;
        top: -8px;
        right: -8px;
        background: #ef4444;
        color: #fff;
        border-radius: 999px;
        padding: 2px 6px;
        font-size: 0.7rem;
        font-weight: 800;
        min-width: 20px;
    }

    .faq-content{
        display: grid;
        gap: 24px;
    }

    .faq-card{
        background:#fff;
        border:1px solid var(--border);
        border-radius: 20px;
        padding: 24px;
        box-shadow: 0 4px 16px rgba(0,0,0,.06);
    }
    .faq-card h4{
        font-weight: 900;
        margin: 0 0 20px;
        color: var(--text);
        font-size: 1.3rem;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .faq-card h4 i{
        color: var(--primary);
    }

    .accordion-item{
        border: 1px solid var(--border);
        border-radius: 16px;
        overflow: hidden;
        margin-bottom: 12px;
        transition: all .3s ease;
    }
    .accordion-item:hover{
        box-shadow: 0 4px 16px rgba(0,0,0,.08);
        transform: translateX(4px);
    }
    .accordion-button{
        font-weight: 800;
        color: var(--text);
        padding: 20px 20px;
        font-size: 1.05rem;
        transition: all .3s ease;
    }
    .accordion-button::after{
        transition: transform .3s ease;
    }
    .accordion-button:not(.collapsed){
        background: linear-gradient(135deg, rgba(14,165,233,.12) 0%, rgba(14,165,233,.06) 100%);
        color: var(--primary-dark);
        box-shadow: none;
    }
    .accordion-button:focus{
        box-shadow: none;
        border-color: var(--primary);
    }
    .accordion-body{
        color: var(--muted);
        font-weight: 600;
        line-height: 1.65;
        padding: 20px;
    }
    .accordion-body strong{
        color: var(--primary-dark);
    }

    .no-results{
        text-align: center;
        padding: 60px 20px;
        display: none;
    }
    .no-results.show{
        display: block;
    }
    .no-results i{
        font-size: 4rem;
        color: var(--border);
        margin-bottom: 16px;
    }
    .no-results h5{
        font-weight: 800;
        color: var(--text);
        margin-bottom: 8px;
    }
    .no-results p{
        color: var(--muted);
        margin: 0;
    }

    .faq-footer{
        margin-top: 24px;
        padding: 24px 24px;
        border: 2px dashed #cbd5e1;
        border-radius: 18px;
        background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
        display:flex;
        align-items:center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
    }
    .faq-footer .footer-content{
        display: flex;
        align-items: center;
        gap: 16px;
    }
    .faq-footer .footer-icon{
        width: 56px;
        height: 56px;
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 1.5rem;
        box-shadow: 0 8px 20px rgba(14,165,233,.25);
    }
    .faq-footer p{
        margin: 0;
        color: var(--text);
        font-weight: 700;
        font-size: 1.05rem;
    }
    .faq-footer .btn-primary{
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        border: none;
        padding: 12px 28px;
        font-weight: 800;
        border-radius: 12px;
        transition: all .3s ease;
        box-shadow: 0 4px 16px rgba(14,165,233,.2);
    }
    .faq-footer .btn-primary:hover{
        transform: translateY(-3px);
        box-shadow: 0 12px 28px rgba(14,165,233,.3);
    }

    .quick-links{
        background:#fff;
        border:1px solid var(--border);
        border-radius: 20px;
        padding: 24px;
        box-shadow: 0 4px 16px rgba(0,0,0,.06);
    }
    .quick-links h4{
        font-weight: 900;
        margin: 0 0 20px;
        color: var(--text);
        font-size: 1.3rem;
    }
    .quick-link-item{
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 16px;
        border: 1px solid var(--border);
        border-radius: 14px;
        margin-bottom: 12px;
        text-decoration: none;
        transition: all .3s ease;
        background: #fff;
    }
    .quick-link-item:hover{
        transform: translateX(8px);
        border-color: var(--primary);
        box-shadow: 0 8px 20px rgba(14,165,233,.15);
    }
    .quick-link-item .link-icon{
        width: 48px;
        height: 48px;
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 1.3rem;
        flex-shrink: 0;
    }
    .quick-link-item .link-text{
        flex: 1;
    }
    .quick-link-item .link-text h5{
        margin: 0 0 4px;
        font-weight: 800;
        color: var(--text);
        font-size: 1rem;
    }
    .quick-link-item .link-text p{
        margin: 0;
        color: var(--muted);
        font-size: 0.85rem;
        font-weight: 600;
    }
    .quick-link-item i.arrow{
        color: var(--muted);
        transition: transform .3s;
    }
    .quick-link-item:hover i.arrow{
        transform: translateX(4px);
        color: var(--primary);
    }

    @media (max-width: 768px){
        .faq-hero{
            padding: 32px 24px;
        }
        .faq-hero h3{
            font-size: 1.6rem;
        }
        .faq-hero .faq-hero-icon{
            width: 64px;
            height: 64px;
            font-size: 1.8rem;
        }
        .faq-footer{
            flex-direction: column;
            text-align: center;
        }
        .faq-footer .footer-content{
            flex-direction: column;
        }
    }

    .fade-in{
        animation: fadeIn 0.5s ease-in;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="container-fluid py-4">
    <div class="faq-wrap">

        <!-- Hero -->
        <div class="faq-hero fade-in">
            <div class="d-flex align-items-center justify-content-between gap-3" style="position:relative; z-index:1;">
                <div>
                    <h3><?= h($title ?? 'Frequently Asked Questions') ?></h3>
                    <p>Everything you need to know about Mall Lost &amp; Found.</p>
                </div>
                <div class="faq-hero-icon">
                    <i class="bi bi-question-circle-fill"></i>
                </div>
            </div>
        </div>

        <!-- Stats -->
        <div class="faq-stats fade-in">
            <div class="faq-stat-card stat-lost">
                <div class="stat-icon">
                    <i class="bi bi-exclamation-circle-fill"></i>
                </div>
                <h4 id="lostCount">0</h4>
                <p>Lost Items</p>
            </div>
            <div class="faq-stat-card stat-found">
                <div class="stat-icon">
                    <i class="bi bi-check-circle-fill"></i>
                </div>
                <h4 id="foundCount">0</h4>
                <p>Found Items</p>
            </div>
            <div class="faq-stat-card stat-claimed">
                <div class="stat-icon">
                    <i class="bi bi-hand-thumbs-up-fill"></i>
                </div>
                <h4 id="claimedCount">0</h4>
                <p>Items Claimed</p>
            </div>
        </div>

        <!-- Tools -->
        <div class="faq-tools fade-in">
            <div class="faq-search">
                <i class="bi bi-search"></i>
                <input id="faqSearch" type="text" placeholder="Search questions, keywords..." />
                <i class="bi bi-x-circle-fill faq-search-clear" id="clearSearch"></i>
            </div>

            <div class="faq-chip active" data-filter="all">
                All Topics
            </div>
            <div class="faq-chip" data-filter="lost">
                Lost Items
            </div>
            <div class="faq-chip" data-filter="found">
                Found Items
            </div>
            <div class="faq-chip" data-filter="claim">
                Claims
            </div>
            <div class="faq-chip" data-filter="contact">
                Contact
            </div>
            <div class="faq-chip" data-filter="security">
                Security
            </div>
        </div>

        <!-- Content -->
        <div class="faq-content fade-in">
            <div class="faq-card">
                <h4><i class="bi bi-patch-question-fill"></i> General Questions</h4>
                <div class="accordion" id="faqAccordion">

                    <!-- LOST -->
                    <div class="accordion-item faq-item" data-tags="lost report contact submit">
                        <h2 class="accordion-header" id="h1">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#c1" aria-expanded="true" aria-controls="c1">
                                How do I report a lost item?
                            </button>
                        </h2>
                        <div id="c1" class="accordion-collapse collapse show" aria-labelledby="h1" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Navigate to <strong>Report Item</strong> and select <strong>Lost</strong>. Provide detailed information including the item name, last seen location, date, and any distinguishing features such as color, brand, or unique markings. Adding a photo greatly increases the chances of recovery. You'll receive a tracking number to monitor your report.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="lost multiple items report">
                        <h2 class="accordion-header" id="h10">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c10" aria-expanded="false" aria-controls="c10">
                                Can I report multiple lost items at once?
                            </button>
                        </h2>
                        <div id="c10" class="accordion-collapse collapse" aria-labelledby="h10" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes! If you lost multiple items in the same location or time period, you can submit separate reports for each item, or mention all items in one comprehensive report. For better tracking, we recommend <strong>separate reports</strong> for each significant item.
                            </div>
                        </div>
                    </div>

                    <!-- FOUND -->
                    <div class="accordion-item faq-item" data-tags="found hand submit turn in">
                        <h2 class="accordion-header" id="h2">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c2" aria-expanded="false" aria-controls="c2">
                                I found an item at the mall. What should I do?
                            </button>
                        </h2>
                        <div id="c2" class="accordion-collapse collapse" aria-labelledby="h2" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Thank you for your honesty! Submit a <strong>Found</strong> report in our system with item details and location. For valuable items like wallets, phones, or jewelry, please hand them to the <strong>Mall Management Counter</strong> or Security immediately. Your good deed helps reunite items with their owners!
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="found reward finder">
                        <h2 class="accordion-header" id="h11">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c11" aria-expanded="false" aria-controls="c11">
                                Is there a reward for finding and returning items?
                            </button>
                        </h2>
                        <div id="c11" class="accordion-collapse collapse" aria-labelledby="h11" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                While we don't offer official rewards, many grateful owners choose to thank finders personally. The best reward is knowing you've helped someone recover something important to them! Some valuable items may come with owner-offered rewards mentioned in lost reports.
                            </div>
                        </div>
                    </div>

                    <!-- CLAIM -->
                    <div class="accordion-item faq-item" data-tags="claim retrieve proof identification">
                        <h2 class="accordion-header" id="h3">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c3" aria-expanded="false" aria-controls="c3">
                                How can I claim my item?
                            </button>
                        </h2>
                        <div id="c3" class="accordion-collapse collapse" aria-labelledby="h3" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Browse <strong>All Items</strong> to find your lost item. When you locate it, follow the claiming process which typically requires <strong>proof of ownership</strong> such as purchase receipts, photos showing the item with you, or ability to describe unique features. Valid ID is required for pickup at the Management Counter.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="claim deadline time limit period">
                        <h2 class="accordion-header" id="h12">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c12" aria-expanded="false" aria-controls="c12">
                                How long are items held before disposal?
                            </button>
                        </h2>
                        <div id="c12" class="accordion-collapse collapse" aria-labelledby="h12" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Found items are typically held for <strong>90 days</strong> from the date they were turned in. High-value items (electronics, jewelry) may be held longer. After this period, unclaimed items are donated to charity or disposed of according to mall policy. Always check as soon as possible!
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="claim someone else proxy representative">
                        <h2 class="accordion-header" id="h13">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c13" aria-expanded="false" aria-controls="c13">
                                Can someone else claim my item for me?
                            </button>
                        </h2>
                        <div id="c13" class="accordion-collapse collapse" aria-labelledby="h13" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes, but they'll need a <strong>written authorization letter</strong> from you, a copy of your ID, their own valid ID, and proof of ownership for the item. Contact us beforehand to confirm requirements to ensure smooth pickup.
                            </div>
                        </div>
                    </div>

                    <!-- CONTACT -->
                    <div class="accordion-item faq-item" data-tags="contact reach support help email">
                        <h2 class="accordion-header" id="h4">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c4" aria-expanded="false" aria-controls="c4">
                                How do I contact the Lost &amp; Found team?
                            </button>
                        </h2>
                        <div id="c4" class="accordion-collapse collapse" aria-labelledby="h4" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Visit our <strong>Contact Us</strong> page to submit an inquiry. You'll receive a unique ticket number instantly. Use <strong>Check Response</strong> to track replies and updates. You can also visit the Mall Management Counter during business hours (10 AM - 10 PM daily).
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="contact response time reply answer">
                        <h2 class="accordion-header" id="h5">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c5" aria-expanded="false" aria-controls="c5">
                                How long until I get a response?
                            </button>
                        </h2>
                        <div id="c5" class="accordion-collapse collapse" aria-labelledby="h5" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Most inquiries are answered within <strong>24-48 hours</strong> during business days. Peak shopping periods (weekends, holidays) may extend response times to 72 hours. Keep your ticket ID handy to check status anytime. Urgent matters can be addressed immediately at the Management Counter.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="contact hours location counter office">
                        <h2 class="accordion-header" id="h14">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c14" aria-expanded="false" aria-controls="c14">
                                Where is the Lost &amp; Found office located?
                            </button>
                        </h2>
                        <div id="c14" class="accordion-collapse collapse" aria-labelledby="h14" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Our Lost &amp; Found office is at the <strong>Mall Management Counter</strong> on Level 1, near the main entrance. Look for the Information Desk signage. Operating hours are <strong>10:00 AM - 10:00 PM daily</strong>. Call ahead during peak hours to reduce wait times.
                            </div>
                        </div>
                    </div>

                    <!-- SECURITY -->
                    <div class="accordion-item faq-item" data-tags="security privacy data protection personal information">
                        <h2 class="accordion-header" id="h6">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c6" aria-expanded="false" aria-controls="c6">
                                Is my personal information secure?
                            </button>
                        </h2>
                        <div id="c6" class="accordion-collapse collapse" aria-labelledby="h6" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Absolutely. We take privacy seriously. All personal information is <strong>encrypted</strong> and stored securely. Your data is only used to facilitate item returns and is never shared with third parties. Contact details are visible only to authorized mall staff managing claims.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="security verification fake scam fraud">
                        <h2 class="accordion-header" id="h15">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c15" aria-expanded="false" aria-controls="c15">
                                How do you prevent fraudulent claims?
                            </button>
                        </h2>
                        <div id="c15" class="accordion-collapse collapse" aria-labelledby="h15" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                We verify all claims through <strong>multiple checkpoints</strong>: proof of ownership documentation, detailed item descriptions that match found items, valid government-issued ID verification, and in some cases, security footage review. This ensures items go to rightful owners only.
                            </div>
                        </div>
                    </div>

                    <!-- GENERAL -->
                    <div class="accordion-item faq-item" data-tags="notification alert update email sms">
                        <h2 class="accordion-header" id="h7">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c7" aria-expanded="false" aria-controls="c7">
                                Will I be notified if my item is found?
                            </button>
                        </h2>
                        <div id="c7" class="accordion-collapse collapse" aria-labelledby="h7" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes! When a found item matches your lost report, we'll send you a <strong>notification via email</strong> with claim instructions. Make sure to provide accurate contact information when reporting. You can also check <strong>All Items</strong> regularly for matches.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="categories types items accepted">
                        <h2 class="accordion-header" id="h8">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c8" aria-expanded="false" aria-controls="c8">
                                What types of items do you handle?
                            </button>
                        </h2>
                        <div id="c8" class="accordion-collapse collapse" aria-labelledby="h8" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                We handle all types of lost property including: electronics (phones, laptops, tablets), accessories (bags, wallets, keys), clothing, jewelry, documents (IDs, passports), children's items, and more. <strong>Perishable items</strong> are not stored for safety reasons.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="cost fee charge payment claim">
                        <h2 class="accordion-header" id="h9">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c9" aria-expanded="false" aria-controls="c9">
                                Is there a fee to claim my item?
                            </button>
                        </h2>
                        <div id="c9" class="accordion-collapse collapse" aria-labelledby="h9" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                No, our Lost &amp; Found service is completely <strong>free of charge</strong>! There are no fees for reporting, claiming, or storing items. We're here to help reunite you with your belongings at no cost. Valid identification is all you need.
                            </div>
                        </div>
                    </div>

                </div>

                <div class="no-results" id="noResults">
                    <i class="bi bi-search"></i>
                    <h5>No Results Found</h5>
                    <p>Try different keywords or browse all categories</p>
                </div>

                <div class="faq-footer">
                    <div class="footer-content">
                        <div class="footer-icon">
                            <i class="bi bi-headset"></i>
                        </div>
                        <div>
                            <p>Still need help? Our support team is ready to assist you.</p>
                        </div>
                    </div>
                    <a href="<?= $this->Url->build(['controller'=>'Contacts','action'=>'add']) ?>" class="btn btn-primary">
                        <i class="bi bi-chat-dots-fill me-2"></i>Contact Us
                    </a>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="quick-links">
                <h4>Quick Actions</h4>
                <a href="<?= $this->Url->build(['controller'=>'Items','action'=>'add']) ?>?type=lost" class="quick-link-item">
                    <div class="link-icon">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                    </div>
                    <div class="link-text">
                        <h5>Report Lost Item</h5>
                        <p>Submit details of items you've lost</p>
                    </div>
                    <i class="bi bi-arrow-right arrow"></i>
                </a>
                <a href="<?= $this->Url->build(['controller'=>'Items','action'=>'add']) ?>?type=found" class="quick-link-item">
                    <div class="link-icon">
                        <i class="bi bi-check-circle-fill"></i>
                    </div>
                    <div class="link-text">
                        <h5>Report Found Item</h5>
                        <p>Help others by reporting found items</p>
                    </div>
                    <i class="bi bi-arrow-right arrow"></i>
                </a>
                <a href="<?= $this->Url->build(['controller'=>'Items','action'=>'index']) ?>" class="quick-link-item">
                    <div class="link-icon">
                        <i class="bi bi-grid-3x3-gap-fill"></i>
                    </div>
                    <div class="link-text">
                        <h5>Browse All Items</h5>
                        <p>Search through lost and found items</p>
                    </div>
                    <i class="bi bi-arrow-right arrow"></i>
                </a>
            </div>
        </div>

    </div>
</div>

<script>
(function(){
    // Elements
    const chips = document.querySelectorAll('.faq-chip');
    const items = document.querySelectorAll('.faq-item');
    const input = document.getElementById('faqSearch');
    const clearBtn = document.getElementById('clearSearch');
    const noResults = document.getElementById('noResults');
    const accordion = document.getElementById('faqAccordion');

    // Stats counter animation
    function animateCounter(element, target) {
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                element.textContent = target;
                clearInterval(timer);
            } else {
                element.textContent = Math.floor(current);
            }
        }, 30);
    }

    // Simulate stats (replace with actual data from backend)
    setTimeout(() => {
        <h4><?= $lostCount ?></h4>
<h4><?= $foundCount ?></h4>A
<h4><?= $claimedCount ?></h4>A

    // Check if any items are visible
    function checkVisibility() {
        const visibleItems = Array.from(items).filter(item => item.style.display !== 'none');
        if (visibleItems.length === 0) {
            noResults.classList.add('show');
            accordion.style.display = 'none';
        } else {
            noResults.classList.remove('show');
            accordion.style.display = 'block';
        }
    }

    // Filter by category
    function applyFilter(tag) {
        items.forEach(item => {
            const tags = (item.getAttribute('data-tags') || '').toLowerCase();
            const ok = (tag === 'all') ? true : tags.includes(tag);
            item.style.display = ok ? '' : 'none';
        });
        checkVisibility();
    }

    // Search function
    function applySearch(q) {
        const query = (q || '').toLowerCase().trim();
        
        if (query === '') {
            clearBtn.classList.remove('show');
        } else {
            clearBtn.classList.add('show');
        }

        items.forEach(item => {
            const text = item.innerText.toLowerCase();
            const tags = (item.getAttribute('data-tags') || '').toLowerCase();
            const ok = text.includes(query) || tags.includes(query);
            item.style.display = ok ? '' : 'none';
        });
        checkVisibility();
    }

    // Chip click handlers
    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            chips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');

            const tag = chip.getAttribute('data-filter') || 'all';
            input.value = '';
            clearBtn.classList.remove('show');
            applyFilter(tag);
        });
    });

    // Search input handler
    input.addEventListener('input', () => {
        chips.forEach(c => c.classList.remove('active'));
        document.querySelector('.faq-chip[data-filter="all"]').classList.add('active');
        applySearch(input.value);
    });

    // Clear search button
    clearBtn.addEventListener('click', () => {
        input.value = '';
        clearBtn.classList.remove('show');
        chips.forEach(c => c.classList.remove('active'));
        document.querySelector('.faq-chip[data-filter="all"]').classList.add('active');
        items.forEach(item => item.style.display = '');
        checkVisibility();
    });

    // Keyboard shortcut (Ctrl/Cmd + K to focus search)
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            input.focus();
        }
    });

    // Auto-expand first item
    setTimeout(() => {
        const firstCollapse = document.getElementById('c1');
        if (firstCollapse && !firstCollapse.classList.contains('show')) {
            new bootstrap.Collapse(firstCollapse, { toggle: true });
        }
    }, 300);

})();
</script>