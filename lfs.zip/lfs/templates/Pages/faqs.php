<?php
// templates/Pages/faq.php
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
    :root{
        --primary:#0ea5e9;
        --primary-dark:#0284c7;
        --text:#111827;
        --muted:#64748b;
        --border:#e2e8f0;
        --bg:#f8fafc;
        --success:#10b981;
    }

    .faq-wrap{ max-width: 1100px; margin: auto; }

    .faq-hero{
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        border-radius: 24px;
        padding: 48px 36px;
        color: #fff;
        box-shadow: 0 20px 60px rgba(14,165,233,.3);
        position: relative;
        overflow: hidden;
        margin-bottom: 32px;
    }
    .faq-hero::before{
        content:'';
        position:absolute;
        top:-60%;
        right:-25%;
        width:520px;
        height:520px;
        background: radial-gradient(circle, rgba(255,255,255,0.22) 0%, transparent 70%);
        animation: pulse 8s ease-in-out infinite;
    }
    @keyframes pulse {
        0%, 100% { transform: scale(1); opacity: 0.22; }
        50% { transform: scale(1.1); opacity: 0.28; }
    }
    .faq-hero h3{
        font-size: 2.2rem;
        font-weight: 900;
        letter-spacing: -0.02em;
        margin: 0 0 12px 0;
    }
    .faq-hero p{
        margin: 0;
        opacity: .95;
        font-weight: 500;
        font-size: 1.1rem;
    }
    .faq-hero .faq-hero-icon{
        width: 80px;
        height: 80px;
        border-radius: 20px;
        background: rgba(255,255,255,.95);
        display:flex;
        align-items:center;
        justify-content:center;
        color: var(--primary);
        font-size: 2.2rem;
        box-shadow: 0 12px 32px rgba(0,0,0,.2);
        animation: float 3s ease-in-out infinite;
    }
    @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }

    .faq-stats{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 32px;
    }
    .faq-stat-card{
        background: #fff;
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,.05);
        transition: transform .3s ease, box-shadow .3s ease;
    }
    .faq-stat-card:hover{
        transform: translateY(-4px);
        box-shadow: 0 12px 28px rgba(0,0,0,.12);
    }
    .faq-stat-card .stat-icon{
        width: 48px;
        height: 48px;
        margin: 0 auto 12px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }
    .faq-stat-card.stat-lost .stat-icon{ background: rgba(239,68,68,.1); color: #dc2626; }
    .faq-stat-card.stat-found .stat-icon{ background: rgba(16,185,129,.1); color: var(--success); }
    .faq-stat-card.stat-claimed .stat-icon{ background: rgba(14,165,233,.1); color: var(--primary); }

    .faq-stat-card h4{ font-size: 2rem; font-weight: 900; margin: 0; color: var(--text); }
    .faq-stat-card p{ margin: 4px 0 0; font-weight: 700; color: var(--muted); font-size: 0.9rem; }

    .faq-tools{
        display:flex;
        gap: 12px;
        flex-wrap: wrap;
        margin: 0 0 24px;
    }

    .faq-search{
        flex: 1;
        min-width: 280px;
        background: #fff;
        border: 2px solid var(--border);
        border-radius: 16px;
        padding: 14px 18px;
        display:flex;
        align-items:center;
        gap: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,.06);
        transition: all .3s ease;
    }
    .faq-search:focus-within{
        border-color: var(--primary);
        box-shadow: 0 8px 24px rgba(14,165,233,.18);
        transform: translateY(-2px);
    }
    .faq-search i{ color: var(--muted); font-size: 1.2rem; transition: color .3s; }
    .faq-search:focus-within i{ color: var(--primary); }
    .faq-search input{
        border: none;
        outline: none;
        width: 100%;
        font-weight: 600;
        color: var(--text);
        background: transparent;
        font-size: 1rem;
    }
    .faq-search input::placeholder{ color: #94a3b8; font-weight: 600; }
    .faq-search-clear{ cursor: pointer; color: var(--muted); display: none; transition: color .2s; }
    .faq-search-clear:hover{ color: #ef4444; }
    .faq-search-clear.show{ display: block; }

    .faq-chip{
        border: 2px solid var(--border);
        background:#fff;
        border-radius: 999px;
        padding: 11px 18px;
        font-weight: 700;
        font-size: 0.9rem;
        color: var(--muted);
        cursor: pointer;
        transition: all .25s ease;
        box-shadow: 0 4px 12px rgba(0,0,0,.05);
        user-select: none;
    }
    .faq-chip:hover{
        transform: translateY(-3px);
        border-color: rgba(14,165,233,.4);
        color: var(--primary-dark);
        box-shadow: 0 12px 28px rgba(14,165,233,.16);
    }
    .faq-chip.active{
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        color:#fff;
        border-color: transparent;
        box-shadow: 0 8px 20px rgba(14,165,233,.3);
    }

    .faq-content{ display: grid; gap: 24px; }

    /* Outer card */
    .faq-card{
        background:#fff !important;
        border:1px solid var(--border);
        border-radius: 20px;
        padding: 24px;
        box-shadow: 0 4px 16px rgba(0,0,0,.06);
    }
    .faq-card h4{
        font-weight: 900;
        margin: 0 0 20px;
        color: var(--text);
        font-size: 1.3rem;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .faq-card h4 i{ color: var(--primary); }

    /* ✅ MAIN FIX: Make accordion boxes white */
    .accordion-item{
        background: #ffffff !important;
        border: 1px solid var(--border);
        border-radius: 16px;
        overflow: hidden;
        margin-bottom: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,.06);
        transition: all .3s ease;
    }
    .accordion-item:hover{
        transform: translateX(4px);
        box-shadow: 0 10px 26px rgba(0,0,0,.10);
    }

    .accordion-button{
        background: #ffffff !important;
        color: var(--text) !important;
        font-weight: 800;
        padding: 20px;
        font-size: 1.05rem;
        box-shadow: none !important;
    }

    .accordion-button:not(.collapsed){
        background: #f8fafc !important;
        color: var(--primary-dark) !important;
    }

    .accordion-button:focus{
        box-shadow: none !important;
        border-color: var(--primary);
        outline: none !important;
    }

    .accordion-body{
        background: #ffffff !important;
        color: var(--muted);
        font-weight: 600;
        line-height: 1.65;
        padding: 20px;
    }
    .accordion-body strong{ color: var(--primary-dark); }

    .no-results{
        text-align: center;
        padding: 60px 20px;
        display: none;
    }
    .no-results.show{ display: block; }
    .no-results i{ font-size: 4rem; color: var(--border); margin-bottom: 16px; }
    .no-results h5{ font-weight: 800; color: var(--text); margin-bottom: 8px; }
    .no-results p{ color: var(--muted); margin: 0; }

    .faq-footer{
        margin-top: 24px;
        padding: 24px 24px;
        border: 2px dashed #cbd5e1;
        border-radius: 18px;
        background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
        display:flex;
        align-items:center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
    }
    .faq-footer .btn-primary{
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        border: none;
        padding: 12px 28px;
        font-weight: 800;
        border-radius: 12px;
        transition: all .3s ease;
        box-shadow: 0 4px 16px rgba(14,165,233,.2);
    }
    .faq-footer .btn-primary:hover{
        transform: translateY(-3px);
        box-shadow: 0 12px 28px rgba(14,165,233,.3);
    }

    .fade-in{ animation: fadeIn 0.5s ease-in; }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="container-fluid py-4">
    <div class="faq-wrap">

        <!-- Hero -->
        <div class="faq-hero fade-in">
            <div class="d-flex align-items-center justify-content-between gap-3" style="position:relative; z-index:1;">
                <div>
                    <h3><?= h($title ?? 'Frequently Asked Questions') ?></h3>
                    <p>Everything you need to know about Mall Lost &amp; Found.</p>
                </div>
                <div class="faq-hero-icon">
                    <i class="bi bi-question-circle-fill"></i>
                </div>
            </div>
        </div>

        <!-- Tools -->
        <div class="faq-tools fade-in">
            <div class="faq-search">
                <i class="bi bi-search"></i>
                <input id="faqSearch" type="text" placeholder="Search questions, keywords..." />
                <i class="bi bi-x-circle-fill faq-search-clear" id="clearSearch"></i>
            </div>

            <div class="faq-chip active" data-filter="all">All Topics</div>
            <div class="faq-chip" data-filter="lost">Lost Items</div>
            <div class="faq-chip" data-filter="found">Found Items</div>
            <div class="faq-chip" data-filter="claim">Claims</div>
            <div class="faq-chip" data-filter="contact">Contact</div>
            <div class="faq-chip" data-filter="security">Security</div>
        </div>

        <!-- Content -->
        <div class="faq-content fade-in">
            <div class="faq-card">
                <h4><i class="bi bi-patch-question-fill"></i> General Questions</h4>

                <div class="accordion" id="faqAccordion">

                    <!-- LOST -->
                    <div class="accordion-item faq-item" data-tags="lost report contact submit">
                        <h2 class="accordion-header" id="h1">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#c1" aria-expanded="true" aria-controls="c1">
                                How do I report a lost item?
                            </button>
                        </h2>
                        <div id="c1" class="accordion-collapse collapse show" aria-labelledby="h1" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Navigate to <strong>Report Item</strong> and select <strong>Lost</strong>. Provide detailed information including the item name, last seen location, date, and any distinguishing features such as color, brand, or unique markings. Adding a photo greatly increases the chances of recovery.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item faq-item" data-tags="lost multiple items report">
                        <h2 class="accordion-header" id="h10">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c10" aria-expanded="false" aria-controls="c10">
                                Can I report multiple lost items at once?
                            </button>
                        </h2>
                        <div id="c10" class="accordion-collapse collapse" aria-labelledby="h10" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes! If you lost multiple items in the same location or time period, you can submit separate reports for each item. For better tracking, we recommend <strong>separate reports</strong> for each significant item.
                            </div>
                        </div>
                    </div>

                    <!-- FOUND -->
                    <div class="accordion-item faq-item" data-tags="found hand submit turn in">
                        <h2 class="accordion-header" id="h2">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c2" aria-expanded="false" aria-controls="c2">
                                I found an item at the mall. What should I do?
                            </button>
                        </h2>
                        <div id="c2" class="accordion-collapse collapse" aria-labelledby="h2" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Submit a <strong>Found</strong> report with item details and location. For valuable items like wallets, phones, or jewelry, please hand them to the <strong>Mall Management Counter</strong> or Security immediately.
                            </div>
                        </div>
                    </div>

                    <!-- CLAIM -->
                    <div class="accordion-item faq-item" data-tags="claim retrieve proof identification">
                        <h2 class="accordion-header" id="h3">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c3" aria-expanded="false" aria-controls="c3">
                                How can I claim my item?
                            </button>
                        </h2>
                        <div id="c3" class="accordion-collapse collapse" aria-labelledby="h3" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                When you locate your item, prepare <strong>proof of ownership</strong> (receipts/photos/unique description). Valid ID is required for pickup at the Management Counter.
                            </div>
                        </div>
                    </div>

                    <!-- CONTACT -->
                    <div class="accordion-item faq-item" data-tags="contact reach support help email">
                        <h2 class="accordion-header" id="h4">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c4" aria-expanded="false" aria-controls="c4">
                                How do I contact the Lost &amp; Found team?
                            </button>
                        </h2>
                        <div id="c4" class="accordion-collapse collapse" aria-labelledby="h4" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Visit our <strong>Contact Us</strong> page to submit an inquiry, or visit the Management Counter during business hours.
                            </div>
                        </div>
                    </div>

                    <!-- SECURITY -->
                    <div class="accordion-item faq-item" data-tags="security privacy data protection personal information">
                        <h2 class="accordion-header" id="h6">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c6" aria-expanded="false" aria-controls="c6">
                                Is my personal information secure?
                            </button>
                        </h2>
                        <div id="c6" class="accordion-collapse collapse" aria-labelledby="h6" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes. Personal information is stored securely and used only for the Lost &amp; Found process.
                            </div>
                        </div>
                    </div>

                </div>

                <div class="no-results" id="noResults">
                    <i class="bi bi-search"></i>
                    <h5>No Results Found</h5>
                    <p>Try different keywords or browse all categories</p>
                </div>

                <div class="faq-footer">
                    <div class="footer-content d-flex align-items-center gap-3">
                        <div class="footer-icon d-flex align-items-center justify-content-center" style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;">
                            <i class="bi bi-headset"></i>
                        </div>
                        <div>
                            <p style="margin:0;color:var(--text);font-weight:700;font-size:1.05rem;">Still need help? Our support team is ready to assist you.</p>
                        </div>
                    </div>
                    <a href="<?= $this->Url->build(['controller'=>'Contacts','action'=>'add']) ?>" class="btn btn-primary">
                        <i class="bi bi-chat-dots-fill me-2"></i>Contact Us
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
(function(){
    const chips = document.querySelectorAll('.faq-chip');
    const items = document.querySelectorAll('.faq-item');
    const input = document.getElementById('faqSearch');
    const clearBtn = document.getElementById('clearSearch');
    const noResults = document.getElementById('noResults');
    const accordion = document.getElementById('faqAccordion');

    function animateCounter(element, target) {
        target = Number(target) || 0;
        let current = 0;
        const steps = 50;
        const increment = target / steps;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                element.textContent = target;
                clearInterval(timer);
            } else {
                element.textContent = Math.floor(current);
            }
        }, 20);
    }

    // ✅ Real values from controller
    const LOST = <?= (int)($lostCount ?? 0) ?>;
    const FOUND = <?= (int)($foundCount ?? 0) ?>;
    const CLAIMED = <?= (int)($claimedCount ?? 0) ?>;

    animateCounter(document.getElementById('lostCount'), LOST);
    animateCounter(document.getElementById('foundCount'), FOUND);
    animateCounter(document.getElementById('claimedCount'), CLAIMED);

    function checkVisibility() {
        const visibleItems = Array.from(items).filter(item => item.style.display !== 'none');
        if (visibleItems.length === 0) {
            noResults.classList.add('show');
            accordion.style.display = 'none';
        } else {
            noResults.classList.remove('show');
            accordion.style.display = 'block';
        }
    }

    function applyFilter(tag) {
        items.forEach(item => {
            const tags = (item.getAttribute('data-tags') || '').toLowerCase();
            const ok = (tag === 'all') ? true : tags.includes(tag);
            item.style.display = ok ? '' : 'none';
        });
        checkVisibility();
    }

    function applySearch(q) {
        const query = (q || '').toLowerCase().trim();

        if (query === '') clearBtn.classList.remove('show');
        else clearBtn.classList.add('show');

        items.forEach(item => {
            const text = item.innerText.toLowerCase();
            const tags = (item.getAttribute('data-tags') || '').toLowerCase();
            const ok = text.includes(query) || tags.includes(query);
            item.style.display = ok ? '' : 'none';
        });
        checkVisibility();
    }

    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            chips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');

            const tag = chip.getAttribute('data-filter') || 'all';
            input.value = '';
            clearBtn.classList.remove('show');
            applyFilter(tag);
        });
    });

    input.addEventListener('input', () => {
        chips.forEach(c => c.classList.remove('active'));
        document.querySelector('.faq-chip[data-filter="all"]')?.classList.add('active');
        applySearch(input.value);
    });

    clearBtn.addEventListener('click', () => {
        input.value = '';
        clearBtn.classList.remove('show');
        chips.forEach(c => c.classList.remove('active'));
        document.querySelector('.faq-chip[data-filter="all"]')?.classList.add('active');
        items.forEach(item => item.style.display = '');
        checkVisibility();
    });

})();
</script>
