<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<?php
$c_name   = (string)$this->request->getParam('controller');
$a_name   = (string)$this->request->getParam('action');
$prefix   = $this->request->getParam('prefix');
$identity = $this->request->getAttribute('identity');

function activeMenu($cond) { return $cond ? 'active' : ''; }

$isLoggedIn = !empty($identity);
$isAdmin    = $isLoggedIn && (int)($identity->user_group_id ?? 0) === 1;

$type = (string)$this->request->getQuery('type');

$isLogin     = !$isLoggedIn && $c_name === 'Users' && $a_name === 'login' && empty($prefix);
$isDashboard = $isLoggedIn && $c_name === 'Dashboards' && $a_name === 'index' && empty($prefix);

$isReport    = $isLoggedIn && empty($prefix) && $c_name === 'Items' && $a_name === 'index';
$isLost      = $isReport && ($type === 'lost' || $type === '');
$isFound     = $isReport && ($type === 'found');

$isGallery   = $isLoggedIn && empty($prefix) && $c_name === 'Items' && $a_name === 'gallery';
$isProfile   = $isLoggedIn && empty($prefix) && $c_name === 'Users' && $a_name === 'profile';

// ✅ FIX: FAQs uses PagesController::faq()
$isFaqs      = empty($prefix) && $c_name === 'Pages' && $a_name === 'faq';

// Admin
$isAdminSettings = ($prefix === 'Admin') && $c_name === 'Settings' && $a_name === 'update';
$isAdminUsers    = ($prefix === 'Admin') && $c_name === 'Users' && $a_name === 'index';
$isAdminAudit    = ($prefix === 'Admin') && strtolower($c_name) === 'auditlogs' && $a_name === 'index';
?>

<style>
* { font-family: 'Inter',  'Segoe UI', sans-serif; }
.lf-sidebar{
    width: 280px;
    height: 100vh;
    position: fixed;
    left: 0; top: 0;
    z-index: 1000;
    background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
    border-right: 1px solid #e2e8f0;
    display: flex;
    flex-direction: column;
    box-shadow: 2px 0 16px rgba(0,0,0,0.06);
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
.lf-sidebar-header{
    padding: 22px 20px;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    gap: 14px;
    background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
    position: relative;
    overflow: hidden;
}
.lf-sidebar-header::before{
    content:'';
    position:absolute;
    top:-50%; right:-50%;
    width:200%; height:200%;
    background: radial-gradient(circle, rgba(255,255,255,0.15) 0%, transparent 70%);
    animation: pulse 4s ease-in-out infinite;
}
@keyframes pulse{
    0%,100%{ transform:scale(1); opacity:0.5; }
    50%{ transform:scale(1.1); opacity:0.8; }
}
.lf-logo{
    width:48px; height:48px;
    border-radius:12px;
    background: rgba(255,255,255,0.95);
    display:flex;
    align-items:center;
    justify-content:center;
    color:#0ea5e9;
    font-size:1.5rem;
    box-shadow:0 4px 12px rgba(0,0,0,0.1);
    position:relative;
    z-index:1;
    animation: logoFloat 3s ease-in-out infinite;
}

.lf-logo img {
    border-radius: 12px;  /* adjust px value as needed for roundness */
    display: block;       /* prevent inline gap */
    max-width: 100%;
    height: auto;
}

@keyframes logoFloat{
    0%,100%{ transform:translateY(0px); }
    50%{ transform:translateY(-4px); }
}
.lf-brand{
    position:relative;
    z-index:1;
    color:#fff;
    font-weight:800;
    letter-spacing:-0.01em;
    line-height:1.1;
}
.lf-brand small{
    display:block;
    font-weight:600;
    opacity:.85;
    font-size:.75rem;
    margin-top:2px;
}

.lf-profile{
    padding:18px 20px;
    border-bottom:1px solid #e2e8f0;
    display:flex;
    align-items:center;
    gap:14px;
    background:#ffffff;
    transition: all 0.3s ease;
    cursor:pointer;
    position:relative;
}
.lf-profile::before{
    content:'';
    position:absolute;
    left:0; top:0;
    width:3px; height:100%;
    background:#0ea5e9;
    transform:scaleY(0);
    transition:transform 0.3s ease;
}
.lf-profile:hover::before{ transform:scaleY(1); }
.lf-profile:hover{ background:#f8fafc; }

.lf-avatar{
    width:44px; height:44px;
    border-radius:50%;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    display:flex;
    align-items:center;
    justify-content:center;
    color:#fff;
    font-weight:800;
    font-size:1.1rem;
    box-shadow:0 4px 12px rgba(16,185,129,0.3);
    transition: all 0.3s ease;
}
.lf-profile:hover .lf-avatar{
    transform:scale(1.05);
    box-shadow:0 6px 16px rgba(16,185,129,0.4);
}
.lf-profile-name{
    font-weight:700;
    font-size:0.9rem;
    margin:0;
    color:#111827;
    letter-spacing:-0.01em;
}
.lf-profile-email{
    font-size:0.75rem;
    margin:0;
    color:#64748b;
    font-weight:500;
}

.lf-menu{
    padding:16px 12px;
    overflow-y: auto;
    flex: 1 1 auto;
    min-height: 0;
}
.lf-menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:13px 14px;
    border-radius:12px;
    color:#475569;
    text-decoration:none;
    font-weight:600;
    font-size:0.9rem;
    transition: all 0.25s cubic-bezier(0.4,0,0.2,1);
    position:relative;
    overflow:hidden;
    margin-bottom:4px;
}
.lf-menu a::before{
    content:'';
    position:absolute;
    left:0; top:0;
    width:4px; height:100%;
    background:#0ea5e9;
    transform:scaleY(0);
    transition:transform 0.3s ease;
    border-radius:0 4px 4px 0;
}
.lf-menu a i{
    font-size:1.15rem;
    width:24px;
    text-align:center;
    color:#64748b;
    transition: all 0.25s ease;
}
.lf-menu a:hover{
    background:#f1f5f9;
    transform:translateX(4px);
    color:#0ea5e9;
}
.lf-menu a:hover i{
    color:#0ea5e9;
    transform:scale(1.1);
}
.lf-menu a.active{
    background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
    color:#fff;
    box-shadow:0 4px 12px rgba(14,165,233,0.3);
}
.lf-menu a.active::before{
    transform:scaleY(1);
    background:#fff;
}
.lf-menu a.active i{
    color:#fff;
    transform:scale(1.05);
}

.lf-section{
    padding:20px 14px 8px;
    font-size:0.7rem;
    font-weight:800;
    color:#94a3b8;
    text-transform:uppercase;
    letter-spacing:1px;
    display:flex;
    align-items:center;
    gap:8px;
}
.lf-section::after{
    content:'';
    flex:1;
    height:1px;
    background: linear-gradient(90deg, #e2e8f0, transparent);
}

.lf-footer{
    border-top:1px solid #e2e8f0;
    padding:16px 20px;
    font-size:0.7rem;
    color:#94a3b8;
    text-align:center;
    background:#ffffff;
    font-weight:500;
}
.lf-footer strong{
    color:#64748b;
    font-weight:700;
}

.lf-menu::-webkit-scrollbar{ width:6px; }
.lf-menu::-webkit-scrollbar-track{ background:transparent; }
.lf-menu::-webkit-scrollbar-thumb{ background:#cbd5e1; border-radius:3px; }
.lf-menu::-webkit-scrollbar-thumb:hover{ background:#94a3b8; }

body{ margin-left:280px; background:#f8fafc; }
@media(max-width:768px){
    body{ margin-left:0; }
    .lf-sidebar{ transform:translateX(-100%); }
    .lf-sidebar.show{ transform:translateX(0); box-shadow:4px 0 24px rgba(0,0,0,0.15); }
}

.lf-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #ffa6c9; 
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

</style>

<aside class="lf-sidebar" id="lfSidebar">

    <div class="lf-sidebar-header">
        <div class="lf-logo">
            <img src="webroot/img/scm.jpeg" alt="SETIAA City Mall Logo" style="max-width: 100%; height: auto;">
        </div>
        <div class="lf-brand">
            SETIAA CITY MALL
            <small>SCM LOST & FOUND</small>
        </div>
    </div>

    <?php if ($isLoggedIn): ?>
        <div class="lf-profile">
            <div class="lf-avatar"><?= strtoupper(substr((string)($identity->name ?? 'U'), 0, 1)) ?></div>
            <div class="flex-grow-1 overflow-hidden">
                <p class="lf-profile-name text-truncate"><?= h($identity->name ?? 'User') ?></p>
                <p class="lf-profile-email text-truncate"><?= h($identity->email ?? '') ?></p>
            </div>
        </div>
    <?php endif; ?>

    <div class="lf-menu">

        <?php if (!$isLoggedIn): ?>

            <?= $this->Html->link(
                '<i class="bi bi-box-arrow-in-right"></i> <span>Sign-in</span>',
                ['controller' => 'Users', 'action' => 'login', 'prefix' => false],
                ['escape' => false, 'class' => activeMenu($isLogin)]
            ) ?>

        <?php else: ?>

            <div class="lf-section"><span>Main</span></div>

            <?= $this->Html->link(
                '<i class="bi bi-speedometer2"></i> <span>Dashboard</span>',
                ['controller' => 'Dashboards', 'action' => 'index', 'prefix' => false],
                ['escape' => false, 'class' => activeMenu($isDashboard)]
            ) ?>

            <?= $this->Html->link(
                '<i class="bi bi-exclamation-circle"></i> <span>Report</span>',
                ['controller' => 'Items', 'action' => 'index', '?' => ['type' => 'lost'], 'prefix' => false],
                ['escape' => false, 'class' => activeMenu($isReport)]
            ) ?>


            <!-- ✅ FAQs -->
            <?= $this->Html->link(
                '<i class="bi bi-question-circle"></i> <span>FAQs</span>',
                '/pages/faqs',
                ['escape' => false, 'class' => activeMenu($isFaqs)]
            ) ?>

            <div class="lf-section"><span>Account</span></div>

            <?= $this->Html->link(
                '<i class="bi bi-person-circle"></i> <span>Profile</span>',
                ['controller' => 'Users', 'action' => 'profile', 'prefix' => false, $this->Identity->get('slug')],
                ['escape' => false, 'class' => activeMenu($isProfile)]
            ) ?>

            <?= $this->Html->link(
                '<i class="bi bi-box-arrow-right"></i> <span>Logout</span>',
                ['controller' => 'Users', 'action' => 'logout', 'prefix' => false],
                ['escape' => false]
            ) ?>

            <?php if ($isAdmin): ?>
                <div class="lf-section"><span>Admin</span></div>

                <?= $this->Html->link(
                    '<i class="bi bi-gear"></i> <span>Settings</span>',
                    ['prefix' => 'Admin', 'controller' => 'Settings', 'action' => 'update', 'recrud'],
                    ['escape' => false, 'class' => activeMenu($isAdminSettings)]
                ) ?>

                <?= $this->Html->link(
                    '<i class="bi bi-chat-dots"></i> <span>Contact</span>',
                    ['prefix' => false, 'controller' => 'Contacts', 'action' => 'add'],
                    ['escape' => false]
                ) ?>

                <?= $this->Html->link(
                    '<i class="bi bi-clock-history"></i> <span>Audit Trail</span>',
                    ['prefix' => 'Admin', 'controller' => 'auditLogs', 'action' => 'index'],
                    ['escape' => false, 'class' => activeMenu($isAdminAudit)]
                ) ?>

            <?php endif; ?>

        <?php endif; ?>

    </div>

    <div class="lf-footer">
        <strong>Lost & Found</strong><br>
        © <?= date('Y') ?> · Version 1.0
    </div>

</aside>
